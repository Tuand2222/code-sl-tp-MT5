﻿
//+------------------------------------------------------------------+
//| EA PRO v8.5: Account-Safe Risk Guard |




//+------------------------------------------------------------------+
#property copyright "EA Pro v8.5 - Account-Safe Risk Guard"
#property version "8.50"
#property strict

#include <Trade\Trade.mqh>
CTrade trade;
void ProcessCoreLogic();
void RebuildCleanPanel(bool clearBeforeBuild);
string AccountScopedGV(string key);
int GetCurrentServerHash();
bool PreparePositionPartialState(long positionId, string partialStateKey);

// ============================================================================

// ============================================================================
enum ENUM_UI_TAB
{
TAB_POSITION = 0, 
TAB_TRAILING = 1, 
TAB_RISKNEWS = 2 
};

enum ENUM_TRADE_SIDE
{
SIDE_LONG = 0, 
SIDE_SHORT = 1 
};

enum ENUM_SL_CALC_MODE
{
SL_MODE_ATR_FIRST = 0, 
SL_MODE_ATR_LINE = 1, 
SL_MODE_POINTS = 2, 
SL_MODE_DRAG = 3 
};

enum ENUM_VOL_SLTP_RULE
{
RULE_KEEP_DIST_CALC_CASH = 0, 
RULE_SCALE_DIST_BY_VOL = 1 
};

enum ENUM_MULTI_ORDER_MODE
{
MULTI_BASKET_VWAP = 0, 
MULTI_INDIVIDUAL = 1 
};

enum ENUM_TRAIL_STYLE
{
TRAIL_STYLE_AUTO_ATR = 0, // 1. AUTO TRAIL (>=R)
TRAIL_STYLE_BE_FLOAT = 1, 
TRAIL_STYLE_MANUAL_SL = 2 // 3. SL TAY 100%
};

enum ENUM_ATR_CALC_SOURCE
{
ATR_SRC_CLOSE_SWING = 0, 
ATR_SRC_HIGH_LOW = 1 
};

enum ENUM_SWEEP_PROTECTION
{
SWEEP_3LAYER_20PCT_1R = 0, 
SWEEP_WAIT_CANDLE_CLOSE = 1, 
SWEEP_HARD_SL_ON_LINE = 2 
};

enum ENUM_ATR_TF_MODE
{
ATR_TF_AUTO_ENTRY = 0, 
ATR_TF_FIXED_H1 = 1, 
ATR_TF_FIXED_M15 = 2, 
ATR_TF_FIXED_M5 = 3, 
ATR_TF_FIXED_H4 = 4, 
ATR_TF_FIXED_D1 = 5, 
ATR_TF_CHART_CUR = 6 
};

enum ENUM_NEWS_TIME_ZONE
{
TZ_LOCAL_PC = 0, 
TZ_MT5_SERVER = 1 
};

enum ENUM_ACTION_SCOPE
{
SCOPE_ACCOUNT = 0,
SCOPE_CHART_SYMBOL = 1
};

// ============================================================================

// ============================================================================
input group "=== 0. TỰ ĐỘNG CẬP NHẬT NGÀY NEO, KHUNG ATR & QUẢN LÝ 3 TẦNG ==="
input ENUM_ATR_TF_MODE InpAtrTfMode = ATR_TF_AUTO_ENTRY; 
input bool InpAutoSyncAnchorDate = true; 
input int InpStandbyLookbackBars = 35; 
input ENUM_TRADE_SIDE InpTradeSide = SIDE_LONG; 
input int InpEntryDateYear = 2026; 
input int InpEntryDateMonth = 10; // Entry Month
input int InpEntryDateDay = 15; // Entry Day
input double InpCustomEntryPrice = 0.0; // Entry Price (0 uses Close)
input int InpAtrLength = 14; // ATR Period (ta.atr RMA)
input double InpAtrMultiplier = 2.8; 
input double InpCustomValueForFirstDay = 2.0; 
input ENUM_ATR_CALC_SOURCE InpAtrCalcSource = ATR_SRC_CLOSE_SWING; 
input ENUM_SWEEP_PROTECTION InpSweepProtection = SWEEP_3LAYER_20PCT_1R; 
input double InpTierBufferPctOf1R = 20.0; 
input int InpSwingLookbackBars = 3; 
input bool InpAutoRestartAtrOnBreak = true; 

input group "=== 1. QUẢN LÝ VỊ THẾ, SL/TP & NHẬT KÝ TÍN HIỆU ==="
input double InpRiskPerTradePct = 1.0; // Tổng ngân sách rủi ro cho Setup (% Equity)
input double InpTargetRR = 2.0; 
input double InpMaxPortfolioRiskPct = 0.0; // 0 = off; optional cap across open positions and pending orders
input double InpEnteredManualLot = 0.0; // Lot đang nhập dự kiến (0 = hiển thị theo Lot gợi ý)
input bool InpLockStandbySetupTfAndBar = true; // Khóa cố định khung & nến cho từng setup lúc chờ lệnh
input bool InpSplitSetupRiskAcrossOrders = true; // Chia tổng ngân sách rủi ro setup cho các lệnh thêm vào (không lặp full %)
input double InpLeg1RiskSharePct = 50.0; // Tỷ trọng rủi ro Lệnh 1 trong Setup (%) - VD: 50% của 0.5% = 0.25%
input double InpLeg2RiskSharePct = 30.0; // Tỷ trọng rủi ro Lệnh 2 trong Setup (%) - VD: 30% của 0.5% = 0.15%
input double InpLeg3RiskSharePct = 20.0; // Tỷ trọng rủi ro Lệnh 3 trong Setup (%) - VD: 20% của 0.5% = 0.10%
input bool InpRecalcSlTpOnFillDeviation = true; // Tự tính lại SL/TP & R theo Giá khớp thực tế khi lệch Entry kế hoạch
input double InpMaxRiskOverrunWarnPct = 5.0; // Cảnh báo & tính lại khi giá khớp lệch làm rủi ro vượt ngân sách (%)
input double InpRejectMaxSlippagePctOf1R = 0.0; // Từ chối (đóng lệnh) nếu trượt giá xấu vượt quá %1R (0 = chỉ cảnh báo & tính lại)
input ENUM_SL_CALC_MODE InpSlCalcMode = SL_MODE_ATR_FIRST; 
input ENUM_VOL_SLTP_RULE InpVolSlTpRule = RULE_KEEP_DIST_CALC_CASH; 
input ENUM_MULTI_ORDER_MODE InpMultiOrderMode = MULTI_BASKET_VWAP; 
input bool InpAutoAttachSlTp = true; 
input bool InpShowJournalSignals = true; 
input int InpJournalHistoryDays = 3; 
input bool InpAutoExportJournalCsv = true; 
input int InpManualSlPoints = 350; 
input int InpBufferPoints = 10; 
input double InpCommissionPerLot = 0.0; // Estimated round-trip commission per 1.00 lot in account currency

input group "=== 2. CHẾ ĐỘ TRAILING / SL THỦ CÔNG, BE & CHỐT TỪNG PHẦN ==="
input ENUM_TRAIL_STYLE InpTrailStyle = TRAIL_STYLE_AUTO_ATR; 
input double InpTrailingStartRR = 2.0; 
input bool InpEnablePartialTP = true; 
input double InpPartialAtRR = 2.0; 
input double InpPartialClosePct = 50.0; 
input bool InpPreventHardTpConflictWithPartial = true; // Chống xung đột: gỡ Hard TP trên server khi trùng mức cắt 50% & bật Trail/BE
input bool InpEnableBe = false; 
input double InpBeTriggerRR = 2.0; 
input int InpBePlusPoints = 10; 
input bool InpEnableLockProfit = false; 
input double InpLockTriggerRR = 2.0; 
input double InpLockLevelRR = 0.20; 

input group "=== 3. KIỂM SOÁT LỖ 3 TẦNG & MÃ PIN MỞ KHÓA (Tuan123) ==="
input bool InpEnableRiskGuard = true; 
input ENUM_ACTION_SCOPE InpRiskControlScope = SCOPE_ACCOUNT; // Phạm vi khóa rủi ro và phục hồi
input double InpMaxDailyLossPct = 5.0; 
input double InpMaxWeeklyLossPct = 10.0; 
input double InpMaxMonthlyLossPct = 15.0; 
input double InpFallbackEquity = 100000.0; 
input double InpCooldownHours = 8.0; 
input bool InpEnableHalfRiskRec = true; 
input double InpRecoveryTargetPct = 1.0; 
input int InpMaxRecoveryOrders = 1; 
input string InpUnlockPinCode = "Tuan123"; 
input double InpPinExtraBufferPct = 1.5; 

input group "=== 4. LỊCH TIN TỨC LINH HOẠT (1 HOẶC NHIỀU TIN) ==="
input bool InpEnableNewsFilter = true; 
input ENUM_ACTION_SCOPE InpNewsFilterScope = SCOPE_ACCOUNT; // Phạm vi hủy lệnh khi có tin
input ENUM_NEWS_TIME_ZONE InpNewsTimeZone = TZ_LOCAL_PC; 
input int InpMinBeforeNews = 2; 
input int InpMinAfterNews = 2; 
input bool InpEnableSlot1 = true; 
input string InpNewsSlot1 = "19:30"; 
input bool InpEnableSlot2 = false; 
input string InpNewsSlot2 = "21:00"; 
input bool InpEnableSlot3 = false; 
input string InpNewsSlot3 = "22:30"; 

input group "=== 5. HIỂN THỊ BIỂU ĐỒ & GIAO DIỆN ==="
input bool InpShowAnchoredAtrLine = true; 
input bool InpShowSizerLines = true; 
input int InpStartPanelX = 14; 
input int InpStartPanelY = 82; 
input int InpFontSize = 9; 

// ============================================================================

// ============================================================================
string PREFIX = "EAP82_UI_";
string VIS_PREFIX = "EAP82_VIS_";
string DRAG_PREFIX = "EAP82_SZ_";
string JRN_PREFIX = "EAP82_JRN_";

ENUM_UI_TAB g_activeTab = TAB_POSITION;

ENUM_ATR_TF_MODE g_atrTfMode;
ENUM_TIMEFRAMES g_resolvedAtrTf = PERIOD_CURRENT;
bool g_autoSyncDate = true;
int g_standbyLookback = 35;

ENUM_TRADE_SIDE g_tradeSide;
int g_entryDateYear, g_entryDateMonth, g_entryDateDay;
double g_entryPriceInput;
int g_atrLength;
double g_atrMultiplier;
double g_customValueForFirstDay;
ENUM_ATR_CALC_SOURCE g_atrSource;
ENUM_SWEEP_PROTECTION g_sweepMode;
double g_tierPctOf1R;
int g_swingLookback;
bool g_autoRestartAtr;

double g_pineLatestAtr = 0.0;
double g_pineEntryLevel = 0.0;
double g_pineTrailingStop = 0.0;
double g_pineFirstBarSlDist = 0.0;
bool g_pineStopPlotting = false;
bool g_pineStartCalc = false;
int g_tier1SavedCount = 0;
int g_tier2HalfCutCount = 0;

bool g_isTrailingArmedNow = false;
bool g_mixedPositionFallback = false;
bool g_mixedModeWarningShown = false;
bool g_pinSizerEntry = false;
bool g_showJournal = true;
ulong g_lastLoggedDealId = 0;

bool g_enRiskGuard;
double g_maxDailyLossPct, g_maxWeeklyLossPct, g_maxMonthlyLossPct;
double g_customEquity;
bool g_useLiveEquity = true;
double g_cooldownHours;
bool g_enHalfRiskRec;
double g_recoveryTargetPct;
int g_maxRecOrders;
string g_enteredPinStr = "****";
datetime g_breachTimestamp = 0;
bool g_inCooldownLock = false;
int g_cooldownRemSec = 0;
bool g_inRecoveryMode = false;
double g_recStartMonthPct = 0.0;
double g_pinExtraDayPct = 0.0;
double g_pinExtraWeekPct = 0.0;
double g_pinExtraMonthPct = 0.0;
int g_lastDayOfYear = -1;
bool g_wasBreachedPrev = false;

bool g_enNewsFilter;
ENUM_NEWS_TIME_ZONE g_newsTz;
int g_minBeforeNews, g_minAfterNews;
bool g_enSlot1, g_enSlot2, g_enSlot3;
string g_newsSlot1, g_newsSlot2, g_newsSlot3;

ENUM_SL_CALC_MODE g_slMode;
ENUM_VOL_SLTP_RULE g_volRule;
ENUM_MULTI_ORDER_MODE g_multiMode;
ENUM_TRAIL_STYLE g_trailStyle;
double g_riskPct;
double g_targetRR;
int g_manualSlPts;
int g_bufferPts;
double g_commPerLot;
bool g_autoSlTp;

bool g_enPartial;
double g_partialRR, g_partialPct;
bool g_enBe;
double g_beRR;
int g_bePoints;
bool g_enLock;
double g_lockTrigRR, g_lockLvlRR;
bool g_enTrail;
double g_trailStartRR;

bool g_showAtrPlot;
bool g_showSizer;

int g_panelX = 14;
int g_panelY = 82;
int g_panelW = 470;
int g_panelH = 310;
int g_headerH = 26;
bool g_isDraggingPanel = false;
int g_dragOffsetX = 0;
int g_dragOffsetY = 0;
bool g_prevMouseLeftDown = false;
int g_cornerPresetIdx = 0;

double g_sizerEntryPrice = 0.0;
double g_sizerSlPrice = 0.0;
double g_sizerTpPrice = 0.0;
double g_pinnedSlDist = 0.0;

// --- Biến quản lý tách bạch Entry kế hoạch vs Giá khớp thực tế, Khóa Setup & Chia lệnh theo tổng Risk ---
double g_plannedEntryPrice = 0.0;
double g_actualFillEntryPrice = 0.0;
double g_standbyLockedEntry = 0.0;
double g_standbyLockedSl = 0.0;
double g_standbyLockedTp = 0.0;
double g_standbyLocked1R = 0.0;
datetime g_standbyLockedAnchorTime = 0;
datetime g_standbyLockedRefBarTime = 0;
ENUM_TIMEFRAMES g_standbyLockedTf = PERIOD_CURRENT;
bool g_standbySetupLocked = false;
int g_prevOpenCountForSetup = 0;
double g_enteredManualLot = 0.0;
double g_leg1SuggestedLot = 0.0;
double g_leg2SuggestedLot = 0.0;
double g_leg3SuggestedLot = 0.0;
double g_nextAddOnSuggestedLot = 0.0;
double g_remainingSetupRiskPct = 0.0;
double g_remainingSetupRiskCash = 0.0;
bool g_hardTpSuppressedForPartial = false;

bool g_isMinimized = false;
bool g_manualForceLock = false;
bool g_accountSwitchHold = false;
bool g_accountHoldRiskDataReady = false;
long g_initAccountLogin = 0;
int g_initServerHash = 0;
bool g_riskBreached = false;
bool g_riskDataAvailable = true;
bool g_riskCloseNoticeShown = false;
datetime g_lastBulkCloseWarning = 0;
string g_breachReason = "";
bool g_newsLockedState = false;
string g_newsStatusText = "Đang kiểm tra lịch tin...";

color C_BG_HEADER = C'15,23,42';
color C_BG_DRAG = C'30,58,138';
color C_BG_BODY = C'22,30,46';
color C_BG_HUD = C'13,38,44';
color C_BG_CARD = C'30,41,59';
color C_BORDER = C'60,75,98';
color C_EDIT_BG = C'248,250,252';
color C_EDIT_MUTED = C'148,163,184';
color C_EDIT_TXT = C'15,23,42';
color C_TAB_ACTIVE = C'37,99,235';
color C_TAB_IDLE = C'45,55,72';
color C_BTN_ON = C'16,185,129';
color C_BTN_OFF = C'71,85,105';
color C_BTN_LOCK = C'185,28,28';
color C_BTN_BUY = C'37,99,235';
color C_BTN_SELL = C'220,38,38';
color C_BTN_ACT = C'217,119,6';
color C_BTN_MODE = C'124,58,237';

color C_ATR_LONG = C'0,255,157';
color C_ATR_SHORT = C'255,64,129';
color C_TIER1_RAY = clrGold;
color C_TIER2_RAY = clrDeepSkyBlue;
color C_TIER3_RAY = clrOrangeRed;

//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
string GetTfShortName(ENUM_TIMEFRAMES tf)
{
ENUM_TIMEFRAMES realTf = (tf == PERIOD_CURRENT) ? _Period : tf;
switch(realTf)
{
case PERIOD_M1: return "M1";
case PERIOD_M5: return "M5";
case PERIOD_M15: return "M15";
case PERIOD_M30: return "M30";
case PERIOD_H1: return "H1";
case PERIOD_H4: return "H4";
case PERIOD_D1: return "D1";
case PERIOD_W1: return "W1";
case PERIOD_MN1: return "MN";
default: return EnumToString(realTf);
}
}

//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
void SyncAnchorDateFields(ENUM_TIMEFRAMES activeTf, datetime openOrderTime)
{
if(!g_autoSyncDate)
return;

datetime latestTfBarTime = iTime(_Symbol, activeTf, 0);
datetime refTime = (latestTfBarTime > 0) ? latestTfBarTime : TimeCurrent();
if(openOrderTime > 0 && openOrderTime > refTime)
refTime = openOrderTime;

if(refTime <= 0)
return;

MqlDateTime dt;
TimeToStruct(refTime, dt);

bool changed = (g_entryDateYear != dt.year || g_entryDateMonth != dt.mon || g_entryDateDay != dt.day);
g_entryDateYear = dt.year;
g_entryDateMonth = dt.mon;
g_entryDateDay = dt.day;

if(changed || g_activeTab == TAB_TRAILING)
{
if(ObjectFind(0, PREFIX + "Ed_Yr") >= 0)
ObjectSetString(0, PREFIX + "Ed_Yr", OBJPROP_TEXT, IntegerToString(g_entryDateYear));
if(ObjectFind(0, PREFIX + "Ed_Mo") >= 0)
ObjectSetString(0, PREFIX + "Ed_Mo", OBJPROP_TEXT, IntegerToString(g_entryDateMonth));
if(ObjectFind(0, PREFIX + "Ed_Dy") >= 0)
ObjectSetString(0, PREFIX + "Ed_Dy", OBJPROP_TEXT, IntegerToString(g_entryDateDay));
}
}

//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
ENUM_TIMEFRAMES DetectBestMatchingTimeframeForSlDist(double actualSlDist)
{
if(actualSlDist <= 0.0)
return _Period;

ENUM_TIMEFRAMES candidates[6] = {PERIOD_M1, PERIOD_M5, PERIOD_M15, PERIOD_H1, PERIOD_H4, PERIOD_D1};
ENUM_TIMEFRAMES bestTf = PERIOD_H1;
double minDiff = 1e18;

for(int idx = 0; idx < 6; idx++)
{
MqlRates r[];
ArraySetAsSeries(r, false);
int copied = CopyRates(_Symbol, candidates[idx], 0, g_atrLength * 3 + 10, r);
if(copied <= 2)
continue;

double sumTR = 0.0;
double atr = 0.0;
int len = MathMax(1, g_atrLength);
for(int i = 0; i < copied - 1; i++)
{
double tr = r[i].high - r[i].low;
if(i > 0)
{
double hc = MathAbs(r[i].high - r[i - 1].close);
double lc = MathAbs(r[i].low - r[i - 1].close);
if(hc > tr) tr = hc;
if(lc > tr) tr = lc;
}
if(i < len) { sumTR += tr; atr = sumTR / (double)(i + 1); }
else { atr = (atr * (double)(len - 1) + tr) / (double)len; }
}

double expectedSlDist = atr * g_customValueForFirstDay;
double diff = MathAbs(expectedSlDist - actualSlDist);
if(diff < minDiff)
{
minDiff = diff;
bestTf = candidates[idx];
}
}
return bestTf;
}

string StandbySetupGVKey(string suffix)
{
return AccountScopedGV("EAP85_STBY_" + _Symbol + "_" + suffix);
}

void SaveStandbySetupToGV()
{
if(!g_standbySetupLocked)
return;
GlobalVariableSet(StandbySetupGVKey("LOCKED"), 1.0);
GlobalVariableSet(StandbySetupGVKey("TF"), (double)g_standbyLockedTf);
GlobalVariableSet(StandbySetupGVKey("ANC_T"), (double)g_standbyLockedAnchorTime);
GlobalVariableSet(StandbySetupGVKey("BAR_T"), (double)g_standbyLockedRefBarTime);
GlobalVariableSet(StandbySetupGVKey("ENTRY"), g_standbyLockedEntry);
GlobalVariableSet(StandbySetupGVKey("SL"), g_standbyLockedSl);
GlobalVariableSet(StandbySetupGVKey("TP"), g_standbyLockedTp);
GlobalVariableSet(StandbySetupGVKey("1R"), g_standbyLocked1R);
GlobalVariableSet(StandbySetupGVKey("SIDE"), (double)g_tradeSide);
}

bool LoadStandbySetupFromGV()
{
if(!GlobalVariableCheck(StandbySetupGVKey("LOCKED")) || GlobalVariableGet(StandbySetupGVKey("LOCKED")) < 0.5)
return false;
int tfVal = (int)GlobalVariableGet(StandbySetupGVKey("TF"));
if(tfVal <= 0)
return false;
g_standbyLockedTf = (ENUM_TIMEFRAMES)tfVal;
g_standbyLockedAnchorTime = (datetime)GlobalVariableGet(StandbySetupGVKey("ANC_T"));
g_standbyLockedRefBarTime = (datetime)GlobalVariableGet(StandbySetupGVKey("BAR_T"));
g_standbyLockedEntry = GlobalVariableGet(StandbySetupGVKey("ENTRY"));
g_standbyLockedSl = GlobalVariableGet(StandbySetupGVKey("SL"));
g_standbyLockedTp = GlobalVariableGet(StandbySetupGVKey("TP"));
g_standbyLocked1R = GlobalVariableGet(StandbySetupGVKey("1R"));
g_standbySetupLocked = (g_standbyLockedEntry > 0.0 && g_standbyLocked1R > 0.0);
return g_standbySetupLocked;
}

void ResetStandbySetupLock(ENUM_TIMEFRAMES preferredTf = PERIOD_CURRENT)
{
g_standbySetupLocked = false;
g_standbyLockedEntry = 0.0;
g_standbyLockedSl = 0.0;
g_standbyLockedTp = 0.0;
g_standbyLocked1R = 0.0;
g_standbyLockedAnchorTime = 0;
g_standbyLockedRefBarTime = 0;
ENUM_TIMEFRAMES baseTf = (preferredTf == PERIOD_CURRENT) ? _Period : preferredTf;
if(g_atrTfMode == ATR_TF_FIXED_H1) baseTf = PERIOD_H1;
else if(g_atrTfMode == ATR_TF_FIXED_M15) baseTf = PERIOD_M15;
else if(g_atrTfMode == ATR_TF_FIXED_M5) baseTf = PERIOD_M5;
else if(g_atrTfMode == ATR_TF_FIXED_H4) baseTf = PERIOD_H4;
else if(g_atrTfMode == ATR_TF_FIXED_D1) baseTf = PERIOD_D1;
g_standbyLockedTf = baseTf;
GlobalVariableDel(StandbySetupGVKey("LOCKED"));
GlobalVariableDel(StandbySetupGVKey("TF"));
GlobalVariableDel(StandbySetupGVKey("ANC_T"));
GlobalVariableDel(StandbySetupGVKey("BAR_T"));
GlobalVariableDel(StandbySetupGVKey("ENTRY"));
GlobalVariableDel(StandbySetupGVKey("SL"));
GlobalVariableDel(StandbySetupGVKey("TP"));
GlobalVariableDel(StandbySetupGVKey("1R"));
GlobalVariableDel(StandbySetupGVKey("SIDE"));
}

ENUM_TIMEFRAMES ResolveActiveAtrTimeframe(int openOrderCount, long anchorPosId, datetime earliestOpenTime, double actualSlDist)
{
if(openOrderCount > 0 && anchorPosId > 0)
{
string gvTfKey = AccountScopedGV("EAP82_LOCKTF_" + IntegerToString(anchorPosId));
string gvTfExact = AccountScopedGV("EAP82_EXACT_" + IntegerToString(anchorPosId));

// Khóa cứng khung thời gian riêng cho từng vị thế/rổ lệnh đang mở. Đổi khung biểu đồ không được ghi đè.
if(GlobalVariableCheck(gvTfKey))
{
int savedTf = (int)GlobalVariableGet(gvTfKey);
if(savedTf > 0)
return (ENUM_TIMEFRAMES)savedTf;
}

ENUM_TIMEFRAMES selectedTf = (g_standbySetupLocked && g_standbyLockedTf != PERIOD_CURRENT) ? g_standbyLockedTf : _Period;
if(g_atrTfMode == ATR_TF_FIXED_H1) selectedTf = PERIOD_H1;
else if(g_atrTfMode == ATR_TF_FIXED_M15) selectedTf = PERIOD_M15;
else if(g_atrTfMode == ATR_TF_FIXED_M5) selectedTf = PERIOD_M5;
else if(g_atrTfMode == ATR_TF_FIXED_H4) selectedTf = PERIOD_H4;
else if(g_atrTfMode == ATR_TF_FIXED_D1) selectedTf = PERIOD_D1;
else if(g_atrTfMode == ATR_TF_AUTO_ENTRY && !g_standbySetupLocked && (TimeCurrent() - earliestOpenTime) > 120)
{
if(_Period == PERIOD_H1 || _Period == PERIOD_H4 || _Period == PERIOD_D1)
selectedTf = _Period;
else
selectedTf = DetectBestMatchingTimeframeForSlDist(actualSlDist);
}

GlobalVariableSet(gvTfKey, (double)selectedTf);
GlobalVariableSet(gvTfExact, 1.0);
return selectedTf;
}

if(g_atrTfMode == ATR_TF_FIXED_H1) return PERIOD_H1;
if(g_atrTfMode == ATR_TF_FIXED_M15) return PERIOD_M15;
if(g_atrTfMode == ATR_TF_FIXED_M5) return PERIOD_M5;
if(g_atrTfMode == ATR_TF_FIXED_H4) return PERIOD_H4;
if(g_atrTfMode == ATR_TF_FIXED_D1) return PERIOD_D1;

// Lúc chờ lệnh: nếu bật khóa khung cho setup thì giữ nguyên khung đã khóa khi người dùng chuyển đổi khung biểu đồ
if(InpLockStandbySetupTfAndBar)
{
if(!g_standbySetupLocked)
LoadStandbySetupFromGV();
if(g_standbySetupLocked && g_standbyLockedTf != PERIOD_CURRENT)
return g_standbyLockedTf;
if(g_standbyLockedTf != PERIOD_CURRENT)
return g_standbyLockedTf;
}
return _Period;
}

//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
string LockGVKey(string suffix)
{
return AccountScopedGV("EAP85_LK_" + suffix);
}

int GetCurrentServerHash()
{
string server = AccountInfoString(ACCOUNT_SERVER);
long serverHash = 0;
for(int i = 0; i < StringLen(server); i++)
serverHash = (serverHash * 31 + (long)StringGetCharacter(server, i)) % 2147483647;
return (int)serverHash;
}

string AccountScopedGV(string key)
{
long login = AccountInfoInteger(ACCOUNT_LOGIN);
long accountHash = ((login % 2147483647) * 31 + (long)GetCurrentServerHash()) % 2147483647;
if(accountHash < 0) accountHash = -accountHash;
string prefix = "E85_" + IntegerToString(accountHash) + "_";
string fullKey = prefix + key;
if(StringLen(fullKey) <= 63)
return fullKey;

long keyHash = 0;
for(int i = 0; i < StringLen(key); i++)
keyHash = (keyHash * 31 + (long)StringGetCharacter(key, i)) % 2147483647;
string suffix = "_" + IntegerToString(keyHash);
int keepLength = 63 - StringLen(prefix) - StringLen(suffix);
if(keepLength < 1) keepLength = 1;
return prefix + StringSubstr(key, 0, keepLength) + suffix;
}

string AccountContextGVKey(string suffix)
{
return "EAP85_CTX_" + IntegerToString((long)ChartID()) + "_" + suffix;
}

void SaveLockStateToGV()
{
GlobalVariableSet(LockGVKey("TIME"), (double)g_breachTimestamp);
GlobalVariableSet(LockGVKey("REC_MODE"), g_inRecoveryMode ? 1.0 : 0.0);
GlobalVariableSet(LockGVKey("REC_START"), g_recStartMonthPct);
GlobalVariableSet(LockGVKey("PIN_EX_D"), g_pinExtraDayPct);
GlobalVariableSet(LockGVKey("PIN_EX_W"), g_pinExtraWeekPct);
GlobalVariableSet(LockGVKey("PIN_EX_M"), g_pinExtraMonthPct);
GlobalVariableSet(LockGVKey("LAST_DOY"), (double)g_lastDayOfYear);
}

void LoadLockStateFromGV()
{
if(GlobalVariableCheck(LockGVKey("TIME"))) g_breachTimestamp = (datetime)GlobalVariableGet(LockGVKey("TIME"));
if(GlobalVariableCheck(LockGVKey("REC_MODE"))) g_inRecoveryMode = (GlobalVariableGet(LockGVKey("REC_MODE")) > 0.5);
if(GlobalVariableCheck(LockGVKey("REC_START"))) g_recStartMonthPct = GlobalVariableGet(LockGVKey("REC_START"));
if(GlobalVariableCheck(LockGVKey("PIN_EX_D"))) g_pinExtraDayPct = GlobalVariableGet(LockGVKey("PIN_EX_D"));
if(GlobalVariableCheck(LockGVKey("PIN_EX_W"))) g_pinExtraWeekPct = GlobalVariableGet(LockGVKey("PIN_EX_W"));
if(GlobalVariableCheck(LockGVKey("PIN_EX_M"))) g_pinExtraMonthPct = GlobalVariableGet(LockGVKey("PIN_EX_M"));
if(GlobalVariableCheck(LockGVKey("LAST_DOY"))) g_lastDayOfYear = (int)GlobalVariableGet(LockGVKey("LAST_DOY"));
}

void NotifyQuotaRestored(string title, string detail)
{
string fullMsg = StringFormat("EA [%s - %s]: %s", _Symbol, title, detail);
Alert(fullMsg);
SendNotification(fullMsg);
PlaySound("ok.wav");
}

color BlendWithBg(color fg, double alphaPct)
{
color bg = (color)ChartGetInteger(0, CHART_COLOR_BACKGROUND);
double a = MathMax(0.05, MathMin(alphaPct / 100.0, 0.45));
int bgR = (bg & 0xFF), bgG = ((bg >> 8) & 0xFF), bgB = ((bg >> 16) & 0xFF);
int fgR = (fg & 0xFF), fgG = ((fg >> 8) & 0xFF), fgB = ((fg >> 16) & 0xFF);
int r = (int)MathRound(bgR * (1.0 - a) + fgR * a);
int g = (int)MathRound(bgG * (1.0 - a) + fgG * a);
int b = (int)MathRound(bgB * (1.0 - a) + fgB * a);
return (color)(r | (g << 8) | (b << 16));
}

void ApplyTrailStyleFlags()
{
if(g_trailStyle == TRAIL_STYLE_AUTO_ATR)
{
g_enTrail = true;
}
else if(g_trailStyle == TRAIL_STYLE_BE_FLOAT)
{
g_enTrail = false;
g_enBe = true;
}
else
{
g_enTrail = false;
g_enBe = false;
g_enLock = false;
}
}

void InitParamsFromInputs()
{
g_atrTfMode = InpAtrTfMode;
g_resolvedAtrTf = _Period;
g_autoSyncDate = InpAutoSyncAnchorDate;
g_standbyLookback = MathMax(10, InpStandbyLookbackBars);

g_tradeSide = InpTradeSide;
g_entryDateYear = InpEntryDateYear;
g_entryDateMonth = InpEntryDateMonth;
g_entryDateDay = InpEntryDateDay;
if(g_autoSyncDate)
SyncAnchorDateFields(_Period, 0);

g_entryPriceInput = InpCustomEntryPrice;
g_atrLength = MathMax(1, InpAtrLength);
g_atrMultiplier = InpAtrMultiplier;
g_customValueForFirstDay = InpCustomValueForFirstDay;
g_atrSource = InpAtrCalcSource;
g_sweepMode = InpSweepProtection;
g_tierPctOf1R = MathMax(5.0, MathMin(InpTierBufferPctOf1R, 90.0));
g_swingLookback = MathMax(1, InpSwingLookbackBars);
g_autoRestartAtr = InpAutoRestartAtrOnBreak;

g_enRiskGuard = InpEnableRiskGuard;
g_maxDailyLossPct = InpMaxDailyLossPct;
g_maxWeeklyLossPct = InpMaxWeeklyLossPct;
g_maxMonthlyLossPct = InpMaxMonthlyLossPct;
double realEq = AccountInfoDouble(ACCOUNT_EQUITY);
g_useLiveEquity = (realEq > 0.0);
g_customEquity = (realEq > 0.0) ? NormalizeDouble(realEq, 0) : InpFallbackEquity;

g_cooldownHours = InpCooldownHours;
g_enHalfRiskRec = InpEnableHalfRiskRec;
g_recoveryTargetPct = InpRecoveryTargetPct;
g_maxRecOrders = MathMax(1, InpMaxRecoveryOrders);
g_enteredPinStr = "****";

g_enNewsFilter = InpEnableNewsFilter;
g_newsTz = InpNewsTimeZone;
g_minBeforeNews = InpMinBeforeNews;
g_minAfterNews = InpMinAfterNews;
g_enSlot1 = InpEnableSlot1;
g_newsSlot1 = InpNewsSlot1;
g_enSlot2 = InpEnableSlot2;
g_newsSlot2 = InpNewsSlot2;
g_enSlot3 = InpEnableSlot3;
g_newsSlot3 = InpNewsSlot3;

g_slMode = InpSlCalcMode;
g_volRule = InpVolSlTpRule;
g_multiMode = InpMultiOrderMode;
g_trailStyle = InpTrailStyle;
g_riskPct = InpRiskPerTradePct;
g_targetRR = InpTargetRR;
g_manualSlPts = InpManualSlPoints;
g_bufferPts = InpBufferPoints;
g_commPerLot = InpCommissionPerLot;
g_autoSlTp = InpAutoAttachSlTp;
g_showJournal = InpShowJournalSignals;

g_enPartial = InpEnablePartialTP;
g_partialRR = MathMax(0.1, InpPartialAtRR);
g_partialPct = MathMax(1.0, MathMin(99.0, InpPartialClosePct));

g_enBe = InpEnableBe;
g_beRR = InpBeTriggerRR;
g_bePoints = InpBePlusPoints;

g_enLock = InpEnableLockProfit;
g_lockTrigRR = InpLockTriggerRR;
g_lockLvlRR = InpLockLevelRR;

g_trailStartRR = MathMax(0.0, InpTrailingStartRR);
ApplyTrailStyleFlags();

g_showAtrPlot = InpShowAnchoredAtrLine;
g_showSizer = InpShowSizerLines;

g_enteredManualLot = MathMax(0.0, InpEnteredManualLot);
if(!LoadStandbySetupFromGV())
{
ENUM_TIMEFRAMES initTf = _Period;
if(g_atrTfMode == ATR_TF_FIXED_H1) initTf = PERIOD_H1;
else if(g_atrTfMode == ATR_TF_FIXED_M15) initTf = PERIOD_M15;
else if(g_atrTfMode == ATR_TF_FIXED_M5) initTf = PERIOD_M5;
else if(g_atrTfMode == ATR_TF_FIXED_H4) initTf = PERIOD_H4;
else if(g_atrTfMode == ATR_TF_FIXED_D1) initTf = PERIOD_D1;
g_standbyLockedTf = initTf;
}

g_panelX = InpStartPanelX;
g_panelY = InpStartPanelY;
}

double GetEffectiveEquity()
{
if(g_useLiveEquity)
{
double liveEq = AccountInfoDouble(ACCOUNT_EQUITY);
if(liveEq > 0.0)
return liveEq;
}
if(g_customEquity > 0.0)
return g_customEquity;
double realEq = AccountInfoDouble(ACCOUNT_EQUITY);
return (realEq > 0.0) ? realEq : InpFallbackEquity;
}

double GetActiveRiskPercent()
{
if(g_inRecoveryMode && g_enHalfRiskRec)
return NormalizeDouble(g_riskPct * 0.5, 2);
return g_riskPct;
}

int GetStepDigits(double step)
{
if(step <= 0.0)
return 2;
int digits = 0;
double temp = step;
while(MathAbs(MathRound(temp) - temp) > 1e-6 && digits < 8)
{
temp *= 10.0;
digits++;
}
return digits;
}

double FloorLotStep(double rawLot)
{
double step = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);
double minL = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
double maxL = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX);
if(step <= 0.0)
step = 0.01;
double lots = MathFloor((rawLot + step * 1e-9) / step) * step;
if(lots < minL)
return 0.0;
if(lots > maxL)
lots = maxL;
return NormalizeDouble(lots, GetStepDigits(step));
}

bool CanSplitVolume(double volume, double closePercent)
{
double minLot = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
if(volume <= 0.0 || closePercent <= 0.0 || closePercent >= 100.0 || minLot <= 0.0)
return false;
double closeVolume = FloorLotStep(volume * closePercent / 100.0);
return (closeVolume >= minLot && volume - closeVolume >= minLot - 1e-6);
}

// Estimate account-currency loss at the stop using the broker's contract calculation.
// The configured buffer and commission are added conservatively; no guessed tick value is used.
bool EstimateStopRiskCash(string symbol, bool isLong, double volume, double entryPrice,
double stopPrice, int bufferPoints, double commissionPerLot, double &riskCash)
{
riskCash = 0.0;
if(symbol == "" || volume <= 0.0 || entryPrice <= 0.0 || stopPrice <= 0.0)
return false;

double point = SymbolInfoDouble(symbol, SYMBOL_POINT);
if(point <= 0.0)
return false;
double bufferedStop = stopPrice + (isLong ? -1.0 : 1.0) * MathMax(0, bufferPoints) * point;
double pnlAtStop = 0.0;
ENUM_ORDER_TYPE orderType = isLong ? ORDER_TYPE_BUY : ORDER_TYPE_SELL;
if(!OrderCalcProfit(orderType, symbol, volume, entryPrice, bufferedStop, pnlAtStop))
return false;

// A profit-protecting stop has no remaining price risk, but still incurs estimated commission.
riskCash = MathMax(0.0, -pnlAtStop) + MathMax(0.0, commissionPerLot) * volume;
return true;
}

double FindStopDistanceForRiskBudget(string symbol, bool isLong, double entryPrice,
double budgetPerLot, int bufferPoints, double commissionPerLot)
{
double point = SymbolInfoDouble(symbol, SYMBOL_POINT);
double tickSize = SymbolInfoDouble(symbol, SYMBOL_TRADE_TICK_SIZE);
double distance = MathMax(point, tickSize);
if(point <= 0.0 || distance <= 0.0 || entryPrice <= 0.0 || budgetPerLot <= 0.0)
return 0.0;

double zeroDistanceRisk = 0.0;
if(!EstimateStopRiskCash(symbol, isLong, 1.0, entryPrice, entryPrice, bufferPoints, commissionPerLot, zeroDistanceRisk)
|| zeroDistanceRisk > budgetPerLot)
return 0.0;

double low = 0.0, high = distance;
bool bracketed = false;
for(int i = 0; i < 48; i++)
{
double stop = entryPrice + (isLong ? -high : high);
if(stop <= 0.0)
return 0.0;
double risk = 0.0;
if(!EstimateStopRiskCash(symbol, isLong, 1.0, entryPrice, stop, bufferPoints, commissionPerLot, risk))
return 0.0;
if(risk > budgetPerLot)
{
bracketed = true;
break;
}
low = high;
high *= 2.0;
}
if(!bracketed)
return 0.0;

for(int i = 0; i < 52; i++)
{
double mid = (low + high) * 0.5;
double stop = entryPrice + (isLong ? -mid : mid);
double risk = 0.0;
if(stop <= 0.0 || !EstimateStopRiskCash(symbol, isLong, 1.0, entryPrice, stop, bufferPoints, commissionPerLot, risk))
return 0.0;
if(risk <= budgetPerLot)
low = mid;
else
high = mid;
}
return low;
}

bool IsBuyPendingType(long orderType)
{
return (orderType == ORDER_TYPE_BUY_LIMIT || orderType == ORDER_TYPE_BUY_STOP || orderType == ORDER_TYPE_BUY_STOP_LIMIT);
}

// Aggregate currently exposed risk for the current chart symbol. A position/order without SL
// makes the total unknown instead of silently presenting it as zero.
bool CalculateChartSymbolExposureRisk(double &riskCash, double &riskVolume, bool includePending)
{
riskCash = 0.0;
riskVolume = 0.0;
bool known = true;
for(int i = PositionsTotal() - 1; i >= 0; i--)
{
ulong ticket = PositionGetTicket(i);
if(ticket == 0 || PositionGetString(POSITION_SYMBOL) != _Symbol)
continue;
double sl = PositionGetDouble(POSITION_SL);
double volume = PositionGetDouble(POSITION_VOLUME);
double entry = PositionGetDouble(POSITION_PRICE_OPEN);
bool isLong = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY);
double oneRisk = 0.0;
if(sl <= 0.0 || !EstimateStopRiskCash(_Symbol, isLong, volume, entry, sl, g_bufferPts, g_commPerLot, oneRisk))
known = false;
else
riskCash += oneRisk;
riskVolume += volume;
}

if(includePending)
for(int i = OrdersTotal() - 1; i >= 0; i--)
{
ulong ticket = OrderGetTicket(i);
if(ticket == 0 || OrderGetString(ORDER_SYMBOL) != _Symbol)
continue;
long type = OrderGetInteger(ORDER_TYPE);
double sl = OrderGetDouble(ORDER_SL);
double volume = OrderGetDouble(ORDER_VOLUME_CURRENT);
double entry = OrderGetDouble(ORDER_PRICE_OPEN);
double oneRisk = 0.0;
bool isLong = IsBuyPendingType(type);
bool stopOnLossSide = isLong ? (sl < entry) : (sl > entry);
if(sl <= 0.0 || !stopOnLossSide || !EstimateStopRiskCash(_Symbol, isLong, volume, entry, sl, g_bufferPts, g_commPerLot, oneRisk))
known = false;
else
riskCash += oneRisk;
riskVolume += volume;
}
return known;
}

// Account-wide cap helper. The chart's buffer/commission inputs apply only to this symbol;
// other symbols use OrderCalcProfit without an assumed fee or point buffer.
bool CalculateAccountExposureRisk(double &riskCash)
{
riskCash = 0.0;
bool known = true;
for(int i = PositionsTotal() - 1; i >= 0; i--)
{
ulong ticket = PositionGetTicket(i);
if(ticket == 0)
continue;
string symbol = PositionGetString(POSITION_SYMBOL);
double sl = PositionGetDouble(POSITION_SL);
double volume = PositionGetDouble(POSITION_VOLUME);
double entry = PositionGetDouble(POSITION_PRICE_OPEN);
bool isLong = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY);
int buffer = (symbol == _Symbol) ? g_bufferPts : 0;
double commission = (symbol == _Symbol) ? g_commPerLot : 0.0;
double oneRisk = 0.0;
if(sl <= 0.0 || !EstimateStopRiskCash(symbol, isLong, volume, entry, sl, buffer, commission, oneRisk))
known = false;
else
riskCash += oneRisk;
}
for(int i = OrdersTotal() - 1; i >= 0; i--)
{
ulong ticket = OrderGetTicket(i);
if(ticket == 0)
continue;
string symbol = OrderGetString(ORDER_SYMBOL);
long type = OrderGetInteger(ORDER_TYPE);
double sl = OrderGetDouble(ORDER_SL);
double volume = OrderGetDouble(ORDER_VOLUME_CURRENT);
double entry = OrderGetDouble(ORDER_PRICE_OPEN);
int buffer = (symbol == _Symbol) ? g_bufferPts : 0;
double commission = (symbol == _Symbol) ? g_commPerLot : 0.0;
double oneRisk = 0.0;
bool isLong = IsBuyPendingType(type);
bool stopOnLossSide = isLong ? (sl < entry) : (sl > entry);
if(sl <= 0.0 || !stopOnLossSide || !EstimateStopRiskCash(symbol, isLong, volume, entry, sl, buffer, commission, oneRisk))
known = false;
else
riskCash += oneRisk;
}
return known;
}

// Lấy "Entry kế hoạch" (Planned Entry) đã khóa của vị thế để đối chiếu với "Giá khớp thực tế" (POSITION_PRICE_OPEN).
// Lưu ý: Mọi tính toán SL/TP, Rủi ro ($) và tỷ lệ R khi lệnh đã khớp đều phải dùng Giá khớp thực tế, KHÔNG dùng hàm này làm giá vào lệnh!
double GetFrozenClosedEntryPrice(long positionId, datetime openTime, double actualEntry)
{
if(positionId <= 0)
return actualEntry;

string gvKey = AccountScopedGV("EAP82_CLOSEPX_" + IntegerToString(positionId));
if(GlobalVariableCheck(gvKey))
{
double savedPrice = GlobalVariableGet(gvKey);
if(savedPrice > 0.0)
return savedPrice;
}

double plannedPrice = 0.0;
if(g_standbySetupLocked && g_standbyLockedEntry > 0.0 && MathAbs((double)(TimeCurrent() - openTime)) <= 300)
plannedPrice = g_standbyLockedEntry;

if(plannedPrice <= 0.0)
{
string gvTfKey = AccountScopedGV("EAP82_LOCKTF_" + IntegerToString(positionId));
ENUM_TIMEFRAMES refTf = GlobalVariableCheck(gvTfKey) ? (ENUM_TIMEFRAMES)(int)GlobalVariableGet(gvTfKey)
: ((g_standbyLockedTf != PERIOD_CURRENT) ? g_standbyLockedTf : _Period);
int entryShift = iBarShift(_Symbol, refTf, openTime, false);
if(entryShift >= 0)
plannedPrice = iClose(_Symbol, refTf, entryShift + 1);
if(plannedPrice <= 0.0 && entryShift == 0)
plannedPrice = iClose(_Symbol, refTf, 1);
}
if(plannedPrice <= 0.0)
plannedPrice = actualEntry;

if(plannedPrice > 0.0)
GlobalVariableSet(gvKey, plannedPrice);
return plannedPrice;
}

// Kiểm tra xem vị thế có cần gỡ Hard TP trên máy chủ để tránh đóng 100% lệnh tại mức cắt 50% (TP1) & bật Trailing/BE hay không
bool ShouldSuppressBrokerHardTpForPartial(double positionVol, bool partialAlreadyDone, double currentEntry, double currentSL, double candidateTP, bool isLong)
{
if(!InpPreventHardTpConflictWithPartial || !g_enPartial || partialAlreadyDone)
return false;
if(!CanSplitVolume(positionVol, g_partialPct))
return false;

bool trailOrBeActive = ((g_enTrail && g_trailStyle == TRAIL_STYLE_AUTO_ATR) || g_enBe || g_enLock);
if(g_targetRR <= g_partialRR + 0.05 && trailOrBeActive)
return true;

if(candidateTP > 0.0 && currentEntry > 0.0 && currentSL > 0.0)
{
double slDist = MathAbs(currentEntry - currentSL);
double tpDist = isLong ? (candidateTP - currentEntry) : (currentEntry - candidateTP);
if(slDist > _Point && tpDist > 0.0)
{
double candidateRR = tpDist / slDist;
if(candidateRR <= g_partialRR + 0.05 && trailOrBeActive)
return true;
}
}
return false;
}

bool TradeRequestSucceeded(bool requestSent)
{
if(!requestSent)
return false;
uint retcode = trade.ResultRetcode();
return (retcode == TRADE_RETCODE_DONE || retcode == TRADE_RETCODE_DONE_PARTIAL || retcode == TRADE_RETCODE_NO_CHANGES);
}

string GetSymbolAlertKey()
{
long symbolHash = 0;
for(int i = 0; i < StringLen(_Symbol); i++)
symbolHash = (symbolHash * 31 + (long)StringGetCharacter(_Symbol, i)) % 2147483647;
return IntegerToString(AccountInfoInteger(ACCOUNT_LOGIN)) + "_" + IntegerToString(symbolHash);
}

void AlertThrottled(string key, string message, int cooldownSeconds = 60)
{
string gvKey = AccountScopedGV("EAP82_ALERT_" + key + "_" + GetSymbolAlertKey());
datetime now = TimeLocal();
datetime lastAlert = GlobalVariableCheck(gvKey) ? (datetime)GlobalVariableGet(gvKey) : 0;
if(lastAlert > 0 && now - lastAlert < cooldownSeconds)
return;
GlobalVariableSet(gvKey, (double)now);
Alert(message);
}

double NormalizePriceToTickSize(string symbol, double price)
{
if(price <= 0.0)
return price;
double tickSize = SymbolInfoDouble(symbol, SYMBOL_TRADE_TICK_SIZE);
if(tickSize <= 0.0)
tickSize = SymbolInfoDouble(symbol, SYMBOL_POINT);
int digits = (int)SymbolInfoInteger(symbol, SYMBOL_DIGITS);
if(tickSize <= 0.0)
return NormalizeDouble(price, digits);
double snapped = (double)MathRound(price / tickSize) * tickSize;
return NormalizeDouble(snapped, digits);
}

bool ValidateStopsForModify(ulong ticket, double &sl, double &tp, string &reason)
{
reason = "";
if(!PositionSelectByTicket(ticket))
{
reason = "không tìm thấy vị thế";
return false;
}

string symbol = PositionGetString(POSITION_SYMBOL);
long type = PositionGetInteger(POSITION_TYPE);
double currentSL = PositionGetDouble(POSITION_SL);
double currentTP = PositionGetDouble(POSITION_TP);
double point = SymbolInfoDouble(symbol, SYMBOL_POINT);
double tickSize = SymbolInfoDouble(symbol, SYMBOL_TRADE_TICK_SIZE);
if(tickSize <= 0.0)
tickSize = point;
if(point <= 0.0 || tickSize <= 0.0)
{
reason = "không đọc được bước giá của mã";
return false;
}

if(sl > 0.0)
sl = NormalizePriceToTickSize(symbol, sl);
if(tp > 0.0)
tp = NormalizePriceToTickSize(symbol, tp);

double tolerance = tickSize * 0.5;
bool slChanged = (sl > 0.0 && (currentSL <= 0.0 || MathAbs(sl - currentSL) > tolerance));
bool tpChanged = (tp > 0.0 && (currentTP <= 0.0 || MathAbs(tp - currentTP) > tolerance));
if(!slChanged && !tpChanged)
return true;

MqlTick tick;
if(!SymbolInfoTick(symbol, tick) || tick.bid <= 0.0 || tick.ask <= 0.0)
{
reason = "không đọc được giá Bid/Ask mới nhất";
return false;
}

long stopsLevel = SymbolInfoInteger(symbol, SYMBOL_TRADE_STOPS_LEVEL);
long freezeLevel = SymbolInfoInteger(symbol, SYMBOL_TRADE_FREEZE_LEVEL);
double minGap = (double)MathMax(stopsLevel, freezeLevel) * point;
double eps = point * 0.1;

if(slChanged)
{
if(type == POSITION_TYPE_BUY)
{
if(sl >= tick.bid - eps || tick.bid - sl + eps < minGap)
{
reason = "SL mua nằm trong khoảng Stops/Freeze của sàn";
return false;
}
}
else if(sl <= tick.ask + eps || sl - tick.ask + eps < minGap)
{
reason = "SL bán nằm trong khoảng Stops/Freeze của sàn";
return false;
}
}

if(tpChanged)
{
if(type == POSITION_TYPE_BUY)
{
if(tp <= tick.ask + eps || tp - tick.ask + eps < minGap)
{
reason = "TP mua nằm trong khoảng Stops/Freeze của sàn";
return false;
}
}
else if(tp >= tick.bid - eps || tick.bid - tp + eps < minGap)
{
reason = "TP bán nằm trong khoảng Stops/Freeze của sàn";
return false;
}
}
return true;
}

bool ModifyPositionWithConfirmation(ulong ticket, double sl, double tp)
{
string warnKey = AccountScopedGV("EAP82_MODWARN_" + IntegerToString(AccountInfoInteger(ACCOUNT_LOGIN)) + "_" + IntegerToString((long)ticket));
string validationReason = "";
if(!ValidateStopsForModify(ticket, sl, tp, validationReason))
{
datetime now = TimeLocal();
datetime lastWarning = GlobalVariableCheck(warnKey) ? (datetime)GlobalVariableGet(warnKey) : 0;
if(lastWarning == 0 || now - lastWarning >= 60)
{
Print("EA PRO: Bỏ qua sửa SL/TP vị thế #", ticket, ". ", validationReason, ". Sẽ kiểm tra lại ở chu kỳ sau.");
GlobalVariableSet(warnKey, (double)now);
}
return false;
}
bool succeeded = TradeRequestSucceeded(trade.PositionModify(ticket, sl, tp));
if(succeeded)
{
GlobalVariableDel(warnKey);
return true;
}

datetime now = TimeLocal();
datetime lastWarning = GlobalVariableCheck(warnKey) ? (datetime)GlobalVariableGet(warnKey) : 0;
if(lastWarning == 0 || now - lastWarning >= 60)
{
Print("EA PRO: Sửa SL/TP vị thế #", ticket, " chưa được máy chủ xác nhận. Retcode=", trade.ResultRetcode(), " ", trade.ResultRetcodeDescription());
GlobalVariableSet(warnKey, (double)now);
}
return false;
}

bool ClosePositionWithConfirmation(ulong ticket)
{
string accountKey = IntegerToString(AccountInfoInteger(ACCOUNT_LOGIN)) + "_" + IntegerToString((long)ticket);
string tryKey = AccountScopedGV("EAP82_CLOSETRY_" + accountKey);
string warnKey = AccountScopedGV("EAP82_CLOSEWARN_" + accountKey);
if(!PositionSelectByTicket(ticket))
{
GlobalVariableDel(tryKey);
GlobalVariableDel(warnKey);
return true;
}
datetime now = TimeLocal();
datetime lastTry = GlobalVariableCheck(tryKey) ? (datetime)GlobalVariableGet(tryKey) : 0;
if(lastTry > 0 && now - lastTry < 2)
return false;
GlobalVariableSet(tryKey, (double)now);

bool requestAccepted = TradeRequestSucceeded(trade.PositionClose(ticket));
if(requestAccepted && !PositionSelectByTicket(ticket))
{
GlobalVariableDel(tryKey);
GlobalVariableDel(warnKey);
return true;
}

datetime lastWarning = GlobalVariableCheck(warnKey) ? (datetime)GlobalVariableGet(warnKey) : 0;
if(lastWarning == 0 || now - lastWarning >= 60)
{
Print("EA PRO: Đóng vị thế #", ticket, requestAccepted ? " mới khớp một phần, còn vị thế; EA sẽ thử tiếp." : " chưa được máy chủ xác nhận. Retcode=", trade.ResultRetcode(), " ", trade.ResultRetcodeDescription());
GlobalVariableSet(warnKey, (double)now);
}
return false;
}

bool DeleteOrderWithConfirmation(ulong ticket)
{
string accountKey = IntegerToString(AccountInfoInteger(ACCOUNT_LOGIN)) + "_" + IntegerToString((long)ticket);
string tryKey = AccountScopedGV("EAP82_ORDERTRY_" + accountKey);
string warnKey = AccountScopedGV("EAP82_ORDERWARN_" + accountKey);
if(!OrderSelect(ticket))
{
GlobalVariableDel(tryKey);
GlobalVariableDel(warnKey);
return true;
}
datetime now = TimeLocal();
datetime lastTry = GlobalVariableCheck(tryKey) ? (datetime)GlobalVariableGet(tryKey) : 0;
if(lastTry > 0 && now - lastTry < 2)
return false;
GlobalVariableSet(tryKey, (double)now);

if(TradeRequestSucceeded(trade.OrderDelete(ticket)))
{
if(!OrderSelect(ticket))
{
GlobalVariableDel(tryKey);
GlobalVariableDel(warnKey);
return true;
}
}

datetime lastWarning = GlobalVariableCheck(warnKey) ? (datetime)GlobalVariableGet(warnKey) : 0;
if(lastWarning == 0 || now - lastWarning >= 60)
{
Print("EA PRO: Xóa lệnh chờ #", ticket, " chưa được máy chủ xác nhận. Retcode=", trade.ResultRetcode(), " ", trade.ResultRetcodeDescription());
GlobalVariableSet(warnKey, (double)now);
}
return false;
}

bool CloseAllPositionsOnChartSymbol()
{
bool hadPosition = false;
for(int i = PositionsTotal() - 1; i >= 0; i--)
{
ulong ticket = PositionGetTicket(i);
if(ticket == 0 || PositionGetString(POSITION_SYMBOL) != _Symbol)
continue;
hadPosition = true;
ClosePositionWithConfirmation(ticket);
}
if(!hadPosition)
return true;
for(int i = PositionsTotal() - 1; i >= 0; i--)
{
ulong ticket = PositionGetTicket(i);
if(ticket > 0 && PositionGetString(POSITION_SYMBOL) == _Symbol)
return false;
}
return true;
}

void ReportPartialTPIssue(long positionId, string message)
{
string warnKey = AccountScopedGV("EAP82_PARTWARN_" + IntegerToString(positionId));
datetime now = TimeCurrent();
datetime lastWarning = GlobalVariableCheck(warnKey) ? (datetime)GlobalVariableGet(warnKey) : 0;
if(lastWarning == 0 || now - lastWarning >= 60)
{
Print("EA PRO TP1 | Position #", positionId, ": ", message);
GlobalVariableSet(warnKey, (double)now);
}
}

bool ClosePositionPartiallyByTicket(ulong ticket, double requestedVolume, double &actualClosedVolume)
{
actualClosedVolume = 0.0;
if(!PositionSelectByTicket(ticket))
return false;

string symbol = PositionGetString(POSITION_SYMBOL);
if(symbol != _Symbol)
return false;

double volumeBefore = PositionGetDouble(POSITION_VOLUME);
double minVolume = SymbolInfoDouble(symbol, SYMBOL_VOLUME_MIN);
double closeVolume = FloorLotStep(MathMin(requestedVolume, volumeBefore - minVolume));
if(closeVolume < minVolume || volumeBefore - closeVolume < minVolume - 1e-8)
return false;

trade.SetTypeFillingBySymbol(symbol);
bool requestSent = false;
ENUM_ACCOUNT_MARGIN_MODE marginMode = (ENUM_ACCOUNT_MARGIN_MODE)AccountInfoInteger(ACCOUNT_MARGIN_MODE);
if(marginMode == ACCOUNT_MARGIN_MODE_RETAIL_HEDGING)
requestSent = trade.PositionClosePartial(ticket, closeVolume);
else
{
long positionType = PositionGetInteger(POSITION_TYPE);
if(positionType == POSITION_TYPE_BUY)
requestSent = trade.Sell(closeVolume, symbol, 0.0, 0.0, 0.0, "Partial close");
else
requestSent = trade.Buy(closeVolume, symbol, 0.0, 0.0, 0.0, "Partial close");
}
if(!TradeRequestSucceeded(requestSent))
return false;

if(PositionSelectByTicket(ticket))
actualClosedVolume = MathMax(0.0, volumeBefore - PositionGetDouble(POSITION_VOLUME));
else
actualClosedVolume = volumeBefore;
return (actualClosedVolume > 0.0);
}

bool ClosePositionPartiallyByTicket(ulong ticket, double requestedVolume)
{
double actualClosedVolume = 0.0;
if(!ClosePositionPartiallyByTicket(ticket, requestedVolume, actualClosedVolume))
return false;
double step = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);
if(step <= 0.0) step = 0.01;
return (actualClosedVolume + step * 0.5 >= requestedVolume);
}

int OnInit()
{
ObjectsDeleteAll(0, "EAPRO");
ObjectsDeleteAll(0, "EAP31");
ObjectsDeleteAll(0, "EAP40");
ObjectsDeleteAll(0, "EAP50");
ObjectsDeleteAll(0, "EAP51");
ObjectsDeleteAll(0, "EAP60");
ObjectsDeleteAll(0, "EAP61");
ObjectsDeleteAll(0, "EAP62");
ObjectsDeleteAll(0, "EAP70");
ObjectsDeleteAll(0, "EAP71");
ObjectsDeleteAll(0, "EAP72");
ObjectsDeleteAll(0, "EAP73");
ObjectsDeleteAll(0, "EAP74");
ObjectsDeleteAll(0, "EAP75");
ObjectsDeleteAll(0, "EAP76");
ObjectsDeleteAll(0, "EAP77");
ObjectsDeleteAll(0, "EAP78");
ObjectsDeleteAll(0, "EAP79");
ObjectsDeleteAll(0, "EAP80");
ObjectsDeleteAll(0, "EAP81");
ObjectsDeleteAll(0, "PSIZER");
ObjectsDeleteAll(0, PREFIX);
ObjectsDeleteAll(0, VIS_PREFIX);
ObjectsDeleteAll(0, DRAG_PREFIX);
ObjectsDeleteAll(0, JRN_PREFIX);

if(UninitializeReason() != REASON_CHARTCHANGE)
InitParamsFromInputs();

g_initAccountLogin = AccountInfoInteger(ACCOUNT_LOGIN);
g_initServerHash = GetCurrentServerHash();
string savedLoginKey = AccountContextGVKey("LOGIN");
string savedServerKey = AccountContextGVKey("SERVER");
g_accountSwitchHold = false;
if(GlobalVariableCheck(savedLoginKey) && GlobalVariableCheck(savedServerKey))
{
long previousLogin = (long)GlobalVariableGet(savedLoginKey);
int previousServerHash = (int)GlobalVariableGet(savedServerKey);
g_accountSwitchHold = (previousLogin != g_initAccountLogin || previousServerHash != g_initServerHash);
}
else if(PositionsTotal() > 0 || OrdersTotal() > 0)
g_accountSwitchHold = true; // First install with live trades requires explicit operator review.
g_accountHoldRiskDataReady = false;

LoadLockStateFromGV();


ChartSetInteger(0, CHART_SHIFT, true);
if(ChartGetDouble(0, CHART_SHIFT_SIZE) < 22.0)
ChartSetDouble(0, CHART_SHIFT_SIZE, 26.0);
ChartSetInteger(0, CHART_EVENT_MOUSE_MOVE, true);

RebuildCleanPanel(true);
ProcessCoreLogic();
EventSetTimer(1);
return(INIT_SUCCEEDED);
}

void OnDeinit(const int reason)
{
if(g_initAccountLogin > 0)
{
GlobalVariableSet(AccountContextGVKey("LOGIN"), (double)g_initAccountLogin);
GlobalVariableSet(AccountContextGVKey("SERVER"), (double)g_initServerHash);
}
EventKillTimer();
ChartSetInteger(0, CHART_MOUSE_SCROLL, true);
if(reason != REASON_CHARTCHANGE)
{
ObjectsDeleteAll(0, PREFIX);
ObjectsDeleteAll(0, VIS_PREFIX);
ObjectsDeleteAll(0, DRAG_PREFIX);
ObjectsDeleteAll(0, JRN_PREFIX);
}
ChartRedraw(0);
}

//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
void WriteTradeJournalCsvRow(string eventType, ulong ticket, string sideStr, double volume,
double entryPrice, double slPrice, double tpPrice, double closePrice,
double pointsRes, double netProfitCash, string noteStr)
{
if(!InpAutoExportJournalCsv)
return;

string fileName = "NhatKy_EAPRO_" + _Symbol + ".csv";
bool fileExists = FileIsExist(fileName);
int handle = FileOpen(fileName, FILE_READ | FILE_WRITE | FILE_CSV | FILE_ANSI, ';');
if(handle == INVALID_HANDLE)
return;

if(!fileExists || FileSize(handle) == 0)
{
FileWrite(handle, "ThoiGian", "Ticket", "CapTien", "KhungATR", "SuKien", "Chieu",
"Lot", "GiaEntry", "GiaSL", "GiaTP", "GiaDong", "KetQua_Pts", "LaiLo_USD", "GhiChu");
}

FileSeek(handle, 0, SEEK_END);
FileWrite(handle,
TimeToString(TimeCurrent(), TIME_DATE | TIME_MINUTES | TIME_SECONDS),
IntegerToString(ticket),
_Symbol,
GetTfShortName(g_resolvedAtrTf),
eventType,
sideStr,
DoubleToString(volume, 2),
DoubleToString(entryPrice, _Digits),
DoubleToString(slPrice, _Digits),
DoubleToString(tpPrice, _Digits),
DoubleToString(closePrice, _Digits),
DoubleToString(pointsRes, 0),
DoubleToString(netProfitCash, 2),
noteStr);
FileClose(handle);
}

//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
void DrawOrderPinsAndTradingJournal(int openCount, double vwapEntry, bool basketIsLong)
{
if(!g_showJournal)
{
ObjectsDeleteAll(0, JRN_PREFIX);
return;
}


ObjectsDeleteAll(0, JRN_PREFIX + "OPEN_");
int orderIdx = 0;

for(int i = 0; i < PositionsTotal(); i++)
{
ulong ticket = PositionGetTicket(i);
if(ticket == 0 || PositionGetString(POSITION_SYMBOL) != _Symbol)
continue;

orderIdx++;
datetime openTime = (datetime)PositionGetInteger(POSITION_TIME);
double entry = PositionGetDouble(POSITION_PRICE_OPEN);
double vol = PositionGetDouble(POSITION_VOLUME);
double sl = PositionGetDouble(POSITION_SL);
double tp = PositionGetDouble(POSITION_TP);
long posId = PositionGetInteger(POSITION_IDENTIFIER);
bool isBuy = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY);

int barShift = iBarShift(_Symbol, PERIOD_CURRENT, openTime, false);
datetime exactBar = (barShift >= 0) ? iTime(_Symbol, PERIOD_CURRENT, barShift) : openTime;
color pinClr = isBuy ? clrDeepSkyBlue : clrHotPink;


string gvLoggedOpen = AccountScopedGV("EAP82_JRN_OPEN_" + IntegerToString(posId));
if(!GlobalVariableCheck(gvLoggedOpen))
{
WriteTradeJournalCsvRow("VAO_LENH", ticket, isBuy ? "BUY" : "SELL", vol, entry, sl, tp, 0.0, 0.0, 0.0,
"Khung " + GetTfShortName(g_resolvedAtrTf));
GlobalVariableSet(gvLoggedOpen, 1.0);
}


string vlineName = JRN_PREFIX + "OPEN_VL_" + IntegerToString(ticket);
double topP = (sl > 0.0 && tp > 0.0) ? MathMax(sl, tp) : (entry + 150 * _Point);
double botP = (sl > 0.0 && tp > 0.0) ? MathMin(sl, tp) : (entry - 150 * _Point);
ObjectCreate(0, vlineName, OBJ_TREND, 0, exactBar, botP, exactBar, topP);
ObjectSetInteger(0, vlineName, OBJPROP_RAY_RIGHT, false);
ObjectSetInteger(0, vlineName, OBJPROP_SELECTABLE, false);
ObjectSetInteger(0, vlineName, OBJPROP_BACK, true);
ObjectSetInteger(0, vlineName, OBJPROP_COLOR, pinClr);
ObjectSetInteger(0, vlineName, OBJPROP_WIDTH, 1);
ObjectSetInteger(0, vlineName, OBJPROP_STYLE, STYLE_DOT);


string pinName = JRN_PREFIX + "OPEN_PIN_" + IntegerToString(ticket);
ObjectCreate(0, pinName, OBJ_TEXT, 0, exactBar, entry);
ObjectSetString(0, pinName, OBJPROP_FONT, "Segoe UI Bold");
ObjectSetInteger(0, pinName, OBJPROP_ANCHOR, ANCHOR_CENTER);
ObjectSetInteger(0, pinName, OBJPROP_SELECTABLE, false);
ObjectSetInteger(0, pinName, OBJPROP_FONTSIZE, InpFontSize + 2);
ObjectSetInteger(0, pinName, OBJPROP_COLOR, clrYellow);
ObjectSetString(0, pinName, OBJPROP_TEXT, "VÀO");


string lblName = JRN_PREFIX + "OPEN_TXT_" + IntegerToString(ticket);
string timeStr = TimeToString(openTime, TIME_MINUTES);
string pinText = StringFormat(" #%d %s %.2f @%s [%s | %s]",
orderIdx, (isBuy ? "BUY" : "SELL"), vol,
DoubleToString(entry, _Digits), timeStr, GetTfShortName(g_resolvedAtrTf));
ObjectCreate(0, lblName, OBJ_TEXT, 0, exactBar, entry);
ObjectSetString(0, lblName, OBJPROP_FONT, "Segoe UI Bold");
ObjectSetInteger(0, lblName, OBJPROP_ANCHOR, isBuy ? ANCHOR_LEFT_UPPER : ANCHOR_LEFT_LOWER);
ObjectSetInteger(0, lblName, OBJPROP_SELECTABLE, false);
ObjectSetInteger(0, lblName, OBJPROP_FONTSIZE, MathMax(8, InpFontSize - 1));
ObjectSetInteger(0, lblName, OBJPROP_COLOR, clrYellow);
ObjectSetString(0, lblName, OBJPROP_TEXT, pinText);


if(openCount > 1 && g_multiMode == MULTI_BASKET_VWAP && !g_mixedPositionFallback && MathAbs(entry - vwapEntry) > _Point)
{
string linkName = JRN_PREFIX + "OPEN_LNK_" + IntegerToString(ticket);
datetime bar0 = iTime(_Symbol, PERIOD_CURRENT, 0);
ObjectCreate(0, linkName, OBJ_TREND, 0, exactBar, entry, bar0, vwapEntry);
ObjectSetInteger(0, linkName, OBJPROP_RAY_RIGHT, false);
ObjectSetInteger(0, linkName, OBJPROP_SELECTABLE, false);
ObjectSetInteger(0, linkName, OBJPROP_COLOR, pinClr);
ObjectSetInteger(0, linkName, OBJPROP_STYLE, STYLE_DOT);
}
}


datetime now = TimeCurrent();
datetime from = now - MathMax(1, InpJournalHistoryDays) * 86400;
if(!HistorySelect(from, now + 60))
return;

int totalDeals = HistoryDealsTotal();
for(int d = 0; d < totalDeals; d++)
{
ulong dealTicket = HistoryDealGetTicket(d);
if(dealTicket == 0 || HistoryDealGetString(dealTicket, DEAL_SYMBOL) != _Symbol)
continue;

long entryType = HistoryDealGetInteger(dealTicket, DEAL_ENTRY);
if(entryType != DEAL_ENTRY_OUT && entryType != DEAL_ENTRY_INOUT && entryType != DEAL_ENTRY_OUT_BY)
continue;

long posId = HistoryDealGetInteger(dealTicket, DEAL_POSITION_ID);
datetime outTime = (datetime)HistoryDealGetInteger(dealTicket, DEAL_TIME);
double outPrice = HistoryDealGetDouble(dealTicket, DEAL_PRICE);
double outVol = HistoryDealGetDouble(dealTicket, DEAL_VOLUME);
long dealType = HistoryDealGetInteger(dealTicket, DEAL_TYPE);
bool wasBuyPos = (dealType == DEAL_TYPE_SELL); 
double netCash = HistoryDealGetDouble(dealTicket, DEAL_PROFIT)
+ HistoryDealGetDouble(dealTicket, DEAL_COMMISSION)
+ HistoryDealGetDouble(dealTicket, DEAL_SWAP)
+ HistoryDealGetDouble(dealTicket, DEAL_FEE);


datetime inTime = 0;
double inPrice = 0.0;
for(int k = 0; k < d; k++)
{
ulong prevDeal = HistoryDealGetTicket(k);
if(prevDeal > 0 && HistoryDealGetInteger(prevDeal, DEAL_POSITION_ID) == posId &&
HistoryDealGetInteger(prevDeal, DEAL_ENTRY) == DEAL_ENTRY_IN)
{
inTime = (datetime)HistoryDealGetInteger(prevDeal, DEAL_TIME);
inPrice = HistoryDealGetDouble(prevDeal, DEAL_PRICE);
break;
}
}

double ptsDiff = 0.0;
if(inPrice > 0.0 && _Point > 0.0)
ptsDiff = (wasBuyPos ? (outPrice - inPrice) : (inPrice - outPrice)) / _Point;


string gvDealLogged = AccountScopedGV("EAP82_JRN_DEAL_" + IntegerToString(dealTicket));
if(!GlobalVariableCheck(gvDealLogged))
{
WriteTradeJournalCsvRow("DONG_LENH", dealTicket, wasBuyPos ? "BUY" : "SELL", outVol, inPrice, 0.0, 0.0, outPrice,
ptsDiff, netCash, (netCash >= 0.0 ? "CHOT_LOI" : "CAT_LO"));
GlobalVariableSet(gvDealLogged, 1.0);
}

int outShift = iBarShift(_Symbol, PERIOD_CURRENT, outTime, false);
datetime outBar = (outShift >= 0) ? iTime(_Symbol, PERIOD_CURRENT, outShift) : outTime;
color resClr = (netCash >= 0.0) ? clrLime : clrTomato;


if(inTime > 0 && inPrice > 0.0)
{
int inShift = iBarShift(_Symbol, PERIOD_CURRENT, inTime, false);
datetime inBar = (inShift >= 0) ? iTime(_Symbol, PERIOD_CURRENT, inShift) : inTime;
string pathName = JRN_PREFIX + "HIST_PATH_" + IntegerToString(dealTicket);
if(ObjectFind(0, pathName) < 0)
{
ObjectCreate(0, pathName, OBJ_TREND, 0, inBar, inPrice, outBar, outPrice);
ObjectSetInteger(0, pathName, OBJPROP_RAY_RIGHT, false);
ObjectSetInteger(0, pathName, OBJPROP_SELECTABLE, false);
ObjectSetInteger(0, pathName, OBJPROP_COLOR, resClr);
ObjectSetInteger(0, pathName, OBJPROP_WIDTH, 2);
ObjectSetInteger(0, pathName, OBJPROP_STYLE, STYLE_DOT);
}

string inPin = JRN_PREFIX + "HIST_IN_" + IntegerToString(dealTicket);
if(ObjectFind(0, inPin) < 0)
{
ObjectCreate(0, inPin, OBJ_TEXT, 0, inBar, inPrice);
ObjectSetString(0, inPin, OBJPROP_FONT, "Segoe UI Bold");
ObjectSetInteger(0, inPin, OBJPROP_ANCHOR, ANCHOR_CENTER);
ObjectSetInteger(0, inPin, OBJPROP_SELECTABLE, false);
ObjectSetInteger(0, inPin, OBJPROP_FONTSIZE, InpFontSize);
ObjectSetInteger(0, inPin, OBJPROP_COLOR, clrAqua);
ObjectSetString(0, inPin, OBJPROP_TEXT, wasBuyPos ? "▲" : "▼");
}
}


string outBadge = JRN_PREFIX + "HIST_OUT_" + IntegerToString(dealTicket);
if(ObjectFind(0, outBadge) < 0)
{
string outTxt = StringFormat("ĐÓNG %.2f @%s [%+.0f điểm | %+$%.2f | %s]",
outVol, DoubleToString(outPrice, _Digits), ptsDiff, netCash, TimeToString(outTime, TIME_MINUTES));
ObjectCreate(0, outBadge, OBJ_TEXT, 0, outBar, outPrice);
ObjectSetString(0, outBadge, OBJPROP_FONT, "Segoe UI Bold");
ObjectSetInteger(0, outBadge, OBJPROP_ANCHOR, ANCHOR_LEFT);
ObjectSetInteger(0, outBadge, OBJPROP_SELECTABLE, false);
ObjectSetInteger(0, outBadge, OBJPROP_FONTSIZE, MathMax(8, InpFontSize - 1));
ObjectSetInteger(0, outBadge, OBJPROP_COLOR, resClr);
ObjectSetString(0, outBadge, OBJPROP_TEXT, outTxt);
}
}
}

//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
void DrawTrendSeg(string name, datetime t1, double p1, datetime t2, double p2, color clr, int width, ENUM_LINE_STYLE style = STYLE_SOLID)
{
string obj = VIS_PREFIX + name;
if(ObjectFind(0, obj) < 0)
{
ObjectCreate(0, obj, OBJ_TREND, 0, t1, p1, t2, p2);
ObjectSetInteger(0, obj, OBJPROP_RAY_RIGHT, false);
ObjectSetInteger(0, obj, OBJPROP_SELECTABLE, false);
ObjectSetInteger(0, obj, OBJPROP_BACK, false);
}
ObjectSetInteger(0, obj, OBJPROP_TIME, 0, t1);
ObjectSetDouble(0, obj, OBJPROP_PRICE, 0, p1);
ObjectSetInteger(0, obj, OBJPROP_TIME, 1, t2);
ObjectSetDouble(0, obj, OBJPROP_PRICE, 1, p2);
ObjectSetInteger(0, obj, OBJPROP_COLOR, clr);
ObjectSetInteger(0, obj, OBJPROP_WIDTH, width);
ObjectSetInteger(0, obj, OBJPROP_STYLE, style);
}

void DrawVisZone(string name, datetime t1, datetime t2, double p1, double p2, color rawClr, double alphaPct, bool show)
{
string obj = VIS_PREFIX + name;
if(!show || p1 <= 0.0 || p2 <= 0.0 || MathAbs(p1 - p2) < _Point * 0.5)
{
ObjectDelete(0, obj);
return;
}
if(ObjectFind(0, obj) < 0)
{
ObjectCreate(0, obj, OBJ_RECTANGLE, 0, t1, p1, t2, p2);
ObjectSetInteger(0, obj, OBJPROP_FILL, true);
ObjectSetInteger(0, obj, OBJPROP_BACK, true);
ObjectSetInteger(0, obj, OBJPROP_SELECTABLE, false);
}
color blended = BlendWithBg(rawClr, alphaPct);
ObjectSetInteger(0, obj, OBJPROP_TIME, 0, t1);
ObjectSetDouble(0, obj, OBJPROP_PRICE, 0, p1);
ObjectSetInteger(0, obj, OBJPROP_TIME, 1, t2);
ObjectSetDouble(0, obj, OBJPROP_PRICE, 1, p2);
ObjectSetInteger(0, obj, OBJPROP_BGCOLOR, blended);
ObjectSetInteger(0, obj, OBJPROP_COLOR, blended);
}

void DrawMarkerSymbol(string name, datetime t, double price, string sym, color clr, int fontSizeOffset = 1)
{
string obj = VIS_PREFIX + name;
if(ObjectFind(0, obj) < 0)
{
ObjectCreate(0, obj, OBJ_TEXT, 0, t, price);
ObjectSetString(0, obj, OBJPROP_FONT, "Segoe UI Bold");
ObjectSetInteger(0, obj, OBJPROP_ANCHOR, ANCHOR_CENTER);
ObjectSetInteger(0, obj, OBJPROP_SELECTABLE, false);
}
ObjectSetInteger(0, obj, OBJPROP_TIME, 0, t);
ObjectSetDouble(0, obj, OBJPROP_PRICE, 0, price);
ObjectSetInteger(0, obj, OBJPROP_FONTSIZE, InpFontSize + fontSizeOffset);
ObjectSetInteger(0, obj, OBJPROP_COLOR, clr);
ObjectSetString(0, obj, OBJPROP_TEXT, sym);
}

//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
void DrawCurrentAtrSpotlight(double currentTrailPrice, double ref1RDist, ENUM_TRADE_SIDE sideParam,
int openOrders, double currentBrokerSL, bool isViolated, double currentR, bool isTrailArmed)
{
string t1Ray = VIS_PREFIX + "SPOT_RAY";
string t1Badge = VIS_PREFIX + "SPOT_BADGE";
string t1Tag = VIS_PREFIX + "SPOT_TAG";

string t2Ray = VIS_PREFIX + "SPOT_T2_RAY";
string t2Badge = VIS_PREFIX + "SPOT_T2_BADGE";
string t2Tag = VIS_PREFIX + "SPOT_T2_TAG";

string t3Ray = VIS_PREFIX + "SPOT_T3_RAY";
string t3Badge = VIS_PREFIX + "SPOT_T3_BADGE";
string t3Tag = VIS_PREFIX + "SPOT_T3_TAG";

if(!g_showAtrPlot || currentTrailPrice <= 0.0)
{
ObjectDelete(0, t1Ray); ObjectDelete(0, t1Badge); ObjectDelete(0, t1Tag);
ObjectDelete(0, t2Ray); ObjectDelete(0, t2Badge); ObjectDelete(0, t2Tag);
ObjectDelete(0, t3Ray); ObjectDelete(0, t3Badge); ObjectDelete(0, t3Tag);
DrawVisZone("Z_T1_T2", 0, 0, 0, 0, clrNONE, 0, false);
DrawVisZone("Z_T2_T3", 0, 0, 0, 0, clrNONE, 0, false);
return;
}

datetime bar0 = iTime(_Symbol, PERIOD_CURRENT, 0);
int sec = PeriodSeconds(PERIOD_CURRENT);


datetime tStart = bar0 + sec * 1;
datetime tEnd = bar0 + sec * 15;
string tfName = GetTfShortName(g_resolvedAtrTf);


if(ObjectFind(0, t1Ray) < 0)
{
ObjectCreate(0, t1Ray, OBJ_TREND, 0, bar0, currentTrailPrice, tEnd, currentTrailPrice);
ObjectSetInteger(0, t1Ray, OBJPROP_RAY_RIGHT, false);
ObjectSetInteger(0, t1Ray, OBJPROP_SELECTABLE, false);
}
ObjectSetInteger(0, t1Ray, OBJPROP_TIME, 0, bar0);
ObjectSetDouble(0, t1Ray, OBJPROP_PRICE, 0, currentTrailPrice);
ObjectSetInteger(0, t1Ray, OBJPROP_TIME, 1, tEnd);
ObjectSetDouble(0, t1Ray, OBJPROP_PRICE, 1, currentTrailPrice);
ObjectSetInteger(0, t1Ray, OBJPROP_COLOR, C_TIER1_RAY);
ObjectSetInteger(0, t1Ray, OBJPROP_WIDTH, 2);
ObjectSetInteger(0, t1Ray, OBJPROP_STYLE, STYLE_SOLID);

if(ObjectFind(0, t1Badge) < 0)
{
ObjectCreate(0, t1Badge, OBJ_ARROW_RIGHT_PRICE, 0, tEnd, currentTrailPrice);
ObjectSetInteger(0, t1Badge, OBJPROP_SELECTABLE, false);
}
ObjectSetInteger(0, t1Badge, OBJPROP_TIME, 0, tEnd);
ObjectSetDouble(0, t1Badge, OBJPROP_PRICE, 0, currentTrailPrice);
ObjectSetInteger(0, t1Badge, OBJPROP_COLOR, C_TIER1_RAY);

double liveClose = iClose(_Symbol, PERIOD_CURRENT, 0);
double distPts = (_Point > 0.0) ? (MathAbs(liveClose - currentTrailPrice) / _Point) : 0.0;

string t1Text = StringFormat("T1 [ATR %s: %s | %.0f điểm] Rút râu = giữ (%d nến)",
tfName, DoubleToString(currentTrailPrice, _Digits), distPts, g_tier1SavedCount);

if(ObjectFind(0, t1Tag) < 0)
{
ObjectCreate(0, t1Tag, OBJ_TEXT, 0, tStart, currentTrailPrice);
ObjectSetString(0, t1Tag, OBJPROP_FONT, "Segoe UI Bold");
ObjectSetInteger(0, t1Tag, OBJPROP_SELECTABLE, false);
}
ObjectSetInteger(0, t1Tag, OBJPROP_ANCHOR, (sideParam == SIDE_LONG) ? ANCHOR_LEFT_LOWER : ANCHOR_LEFT_UPPER);
ObjectSetInteger(0, t1Tag, OBJPROP_TIME, 0, tStart);
ObjectSetDouble(0, t1Tag, OBJPROP_PRICE, 0, currentTrailPrice);
ObjectSetInteger(0, t1Tag, OBJPROP_FONTSIZE, MathMax(8, InpFontSize - 1));
ObjectSetInteger(0, t1Tag, OBJPROP_COLOR, (g_enTrail && isTrailArmed) ? clrLime : C_TIER1_RAY);
ObjectSetString(0, t1Tag, OBJPROP_TEXT, t1Text);


double base1R = (ref1RDist > 0.0) ? ref1RDist : ((g_pineFirstBarSlDist > 0.0) ? g_pineFirstBarSlDist : (g_pineLatestAtr * g_customValueForFirstDay));
double buffer20Pct1R = base1R * (g_tierPctOf1R / 100.0);
double buffer10Pct1R = buffer20Pct1R * 0.5;

if(g_sweepMode == SWEEP_3LAYER_20PCT_1R && buffer20Pct1R > 0.0)
{
double tier2Price = (sideParam == SIDE_LONG) ? NormalizeDouble(currentTrailPrice - buffer10Pct1R, _Digits)
: NormalizeDouble(currentTrailPrice + buffer10Pct1R, _Digits);
double tier3Price = (sideParam == SIDE_LONG) ? NormalizeDouble(currentTrailPrice - buffer20Pct1R, _Digits)
: NormalizeDouble(currentTrailPrice + buffer20Pct1R, _Digits);

double t2Pts = (_Point > 0.0) ? (buffer10Pct1R / _Point) : 0.0;
double t3Pts = (_Point > 0.0) ? (buffer20Pct1R / _Point) : 0.0;

DrawVisZone("Z_T1_T2", bar0, tEnd, currentTrailPrice, tier2Price, C_TIER2_RAY, 10.0, true);
DrawVisZone("Z_T2_T3", bar0, tEnd, tier2Price, tier3Price, C_TIER3_RAY, 14.0, true);


if(ObjectFind(0, t2Ray) < 0)
{
ObjectCreate(0, t2Ray, OBJ_TREND, 0, bar0, tier2Price, tEnd, tier2Price);
ObjectSetInteger(0, t2Ray, OBJPROP_RAY_RIGHT, false);
ObjectSetInteger(0, t2Ray, OBJPROP_SELECTABLE, false);
}
ObjectSetInteger(0, t2Ray, OBJPROP_TIME, 0, bar0);
ObjectSetDouble(0, t2Ray, OBJPROP_PRICE, 0, tier2Price);
ObjectSetInteger(0, t2Ray, OBJPROP_TIME, 1, tEnd);
ObjectSetDouble(0, t2Ray, OBJPROP_PRICE, 1, tier2Price);
ObjectSetInteger(0, t2Ray, OBJPROP_COLOR, C_TIER2_RAY);
ObjectSetInteger(0, t2Ray, OBJPROP_WIDTH, 2);
ObjectSetInteger(0, t2Ray, OBJPROP_STYLE, STYLE_DASH);

if(ObjectFind(0, t2Badge) < 0)
{
ObjectCreate(0, t2Badge, OBJ_ARROW_RIGHT_PRICE, 0, tEnd, tier2Price);
ObjectSetInteger(0, t2Badge, OBJPROP_SELECTABLE, false);
}
ObjectSetInteger(0, t2Badge, OBJPROP_TIME, 0, tEnd);
ObjectSetDouble(0, t2Badge, OBJPROP_PRICE, 0, tier2Price);
ObjectSetInteger(0, t2Badge, OBJPROP_COLOR, C_TIER2_RAY);

string t2Text = StringFormat("T2 [CẮT 50%%: %s | %.0f%% 1R=%.0f điểm] Nến đóng %s (%d nến)",
DoubleToString(tier2Price, _Digits), g_tierPctOf1R * 0.5, t2Pts, tfName, g_tier2HalfCutCount);
if(ObjectFind(0, t2Tag) < 0)
{
ObjectCreate(0, t2Tag, OBJ_TEXT, 0, tStart, tier2Price);
ObjectSetString(0, t2Tag, OBJPROP_FONT, "Segoe UI Bold");
ObjectSetInteger(0, t2Tag, OBJPROP_ANCHOR, ANCHOR_LEFT);
ObjectSetInteger(0, t2Tag, OBJPROP_SELECTABLE, false);
}
ObjectSetInteger(0, t2Tag, OBJPROP_TIME, 0, tStart);
ObjectSetDouble(0, t2Tag, OBJPROP_PRICE, 0, tier2Price);
ObjectSetInteger(0, t2Tag, OBJPROP_FONTSIZE, MathMax(8, InpFontSize - 1));
ObjectSetInteger(0, t2Tag, OBJPROP_COLOR, C_TIER2_RAY);
ObjectSetString(0, t2Tag, OBJPROP_TEXT, t2Text);


if(ObjectFind(0, t3Ray) < 0)
{
ObjectCreate(0, t3Ray, OBJ_TREND, 0, bar0, tier3Price, tEnd, tier3Price);
ObjectSetInteger(0, t3Ray, OBJPROP_RAY_RIGHT, false);
ObjectSetInteger(0, t3Ray, OBJPROP_SELECTABLE, false);
}
ObjectSetInteger(0, t3Ray, OBJPROP_TIME, 0, bar0);
ObjectSetDouble(0, t3Ray, OBJPROP_PRICE, 0, tier3Price);
ObjectSetInteger(0, t3Ray, OBJPROP_TIME, 1, tEnd);
ObjectSetDouble(0, t3Ray, OBJPROP_PRICE, 1, tier3Price);
ObjectSetInteger(0, t3Ray, OBJPROP_COLOR, C_TIER3_RAY);
ObjectSetInteger(0, t3Ray, OBJPROP_WIDTH, 2);
ObjectSetInteger(0, t3Ray, OBJPROP_STYLE, STYLE_DOT);

if(ObjectFind(0, t3Badge) < 0)
{
ObjectCreate(0, t3Badge, OBJ_ARROW_RIGHT_PRICE, 0, tEnd, tier3Price);
ObjectSetInteger(0, t3Badge, OBJPROP_SELECTABLE, false);
}
ObjectSetInteger(0, t3Badge, OBJPROP_TIME, 0, tEnd);
ObjectSetDouble(0, t3Badge, OBJPROP_PRICE, 0, tier3Price);
ObjectSetInteger(0, t3Badge, OBJPROP_COLOR, C_TIER3_RAY);

string t3Text = StringFormat("T3 [SL 100%%: %s | %.0f%% 1R=%.0f điểm] Thủng = đóng luôn!",
DoubleToString(tier3Price, _Digits), g_tierPctOf1R, t3Pts);
if(ObjectFind(0, t3Tag) < 0)
{
ObjectCreate(0, t3Tag, OBJ_TEXT, 0, tStart, tier3Price);
ObjectSetString(0, t3Tag, OBJPROP_FONT, "Segoe UI Bold");
ObjectSetInteger(0, t3Tag, OBJPROP_SELECTABLE, false);
}
ObjectSetInteger(0, t3Tag, OBJPROP_ANCHOR, (sideParam == SIDE_LONG) ? ANCHOR_LEFT_UPPER : ANCHOR_LEFT_LOWER);
ObjectSetInteger(0, t3Tag, OBJPROP_TIME, 0, tStart);
ObjectSetDouble(0, t3Tag, OBJPROP_PRICE, 0, tier3Price);
ObjectSetInteger(0, t3Tag, OBJPROP_FONTSIZE, MathMax(8, InpFontSize - 1));
ObjectSetInteger(0, t3Tag, OBJPROP_COLOR, C_TIER3_RAY);
ObjectSetString(0, t3Tag, OBJPROP_TEXT, t3Text);
}
else
{
ObjectDelete(0, t2Ray); ObjectDelete(0, t2Badge); ObjectDelete(0, t2Tag);
ObjectDelete(0, t3Ray); ObjectDelete(0, t3Badge); ObjectDelete(0, t3Tag);
DrawVisZone("Z_T1_T2", 0, 0, 0, 0, clrNONE, 0, false);
DrawVisZone("Z_T2_T3", 0, 0, 0, 0, clrNONE, 0, false);
}
}

void ComputeExactPineAtrArray(const MqlRates &rates[], int total, int length, double &outAtr[])
{
ArrayResize(outAtr, total);
ArrayInitialize(outAtr, 0.0);
if(total <= 0)
return;

int len = MathMax(1, length);
double sumTR = 0.0;

for(int i = 0; i < total; i++)
{
double high_i = rates[i].high;
double low_i = rates[i].low;
double tr = high_i - low_i;

if(i > 0)
{
double prevClose = rates[i - 1].close;
double trHC = MathAbs(high_i - prevClose);
double trLC = MathAbs(low_i - prevClose);
if(trHC > tr) tr = trHC;
if(trLC > tr) tr = trLC;
}

if(i < len - 1)
{
sumTR += tr;
outAtr[i] = sumTR / (double)(i + 1);
}
else if(i == len - 1)
{
sumTR += tr;
outAtr[i] = sumTR / (double)len;
}
else
{
outAtr[i] = (outAtr[i - 1] * (double)(len - 1) + tr) / (double)len;
}
}
}

//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
double ExecuteExactPineScriptFormula(ENUM_TIMEFRAMES calcTf,
datetime entryDate,
double entryPriceParam,
ENUM_TRADE_SIDE sideParam,
bool drawPlotOnChart,
bool allowAutoRestart,
double &outEntryLevel,
double &outFirstBarSlDist,
bool &outStopPlotting,
bool &outStartCalculating,
bool &outDataReady)
{
outEntryLevel = 0.0;
outFirstBarSlDist = 0.0;
outStopPlotting = false;
outStartCalculating = false;
outDataReady = false;

datetime pingTfBar0 = iTime(_Symbol, calcTf, 0);
if(pingTfBar0 <= 0)
return 0.0;

int anchorShift = iBarShift(_Symbol, calcTf, entryDate, false);
if(anchorShift < 0)
return 0.0;

int visualShift = MathMax(anchorShift, 60);
int barsToCopy = MathMin(visualShift + g_atrLength * 8 + 120, 5000);
barsToCopy = MathMax(barsToCopy, g_atrLength * 4 + 80);

MqlRates rates[];
ArraySetAsSeries(rates, false);
int copied = CopyRates(_Symbol, calcTf, 0, barsToCopy, rates);
if(copied < g_atrLength + 2 || anchorShift >= copied)
return 0.0;

double atrArr[];
ComputeExactPineAtrArray(rates, copied, g_atrLength, atrArr);

g_pineLatestAtr = (copied >= 2) ? atrArr[copied - 2] : atrArr[copied - 1];

int anchorIdx = copied - 1 - anchorShift;
if(anchorIdx < g_atrLength - 1 || anchorIdx >= copied)
return 0.0;
outDataReady = true;

if(drawPlotOnChart)
{
ObjectsDeleteAll(0, VIS_PREFIX + "ATRLINE_");
g_tier1SavedCount = 0;
g_tier2HalfCutCount = 0;
}

datetime effectiveEntryDate = rates[anchorIdx].time;

bool hasEntryLevel = false;
double entryLevel = 0.0;
bool hasPrevTrailing = false;
double prevTrailingStop = 0.0;
double trailingStop = 0.0;
bool firstDayCalculated = false;
bool stopPlotting = false;
bool tier2TriggeredCycle = false;
bool trailArmedInLoop = allowAutoRestart; 
datetime armedTriggerBarTime = 0;
datetime prevPlottedTime = 0;
double prevPlottedValue = 0.0;
color plotColor = (sideParam == SIDE_LONG) ? C_ATR_LONG : C_ATR_SHORT;
datetime chartBar0 = iTime(_Symbol, PERIOD_CURRENT, 0);

for(int i = 0; i < copied; i++)
{
datetime barTime = rates[i].time;
double barClose = rates[i].close;
double barHigh = rates[i].high;
double barLow = rates[i].low;
double atrValue = (i == copied - 1 && i > 0) ? atrArr[i - 1] : atrArr[i];
bool isFormingBar0 = (i == copied - 1);

if(!hasEntryLevel && barTime >= effectiveEntryDate)
{
entryLevel = (entryPriceParam > 0.0) ? entryPriceParam : barClose;
hasEntryLevel = true;
outEntryLevel = entryLevel;
}

bool startCalculating = (hasEntryLevel && barTime >= effectiveEntryDate);
if(startCalculating)
outStartCalculating = true;

if(startCalculating && !stopPlotting)
{
double ref1R = (outFirstBarSlDist > 0.0) ? outFirstBarSlDist : (atrValue * g_customValueForFirstDay);


if(!trailArmedInLoop && ref1R > 0.0)
{
double bestExtent = (sideParam == SIDE_LONG) ? (barHigh - entryLevel) : (entryLevel - barLow);
if((bestExtent / ref1R) >= g_trailStartRR - 1e-6)
{
trailArmedInLoop = true;
armedTriggerBarTime = barTime;
}
}

if(!hasPrevTrailing)
{
if(sideParam == SIDE_LONG)
{
if(!firstDayCalculated)
{ trailingStop = entryLevel - atrValue * g_customValueForFirstDay; firstDayCalculated = true; }
else
trailingStop = entryLevel - g_atrMultiplier * atrValue;
}
else
{
if(!firstDayCalculated)
{ trailingStop = entryLevel + atrValue * g_customValueForFirstDay; firstDayCalculated = true; }
else
trailingStop = entryLevel + g_atrMultiplier * atrValue;
}
outFirstBarSlDist = MathAbs(entryLevel - trailingStop);
ref1R = outFirstBarSlDist;
tier2TriggeredCycle = false;

if(!trailArmedInLoop && ref1R > 0.0)
{
double bestExtent0 = (sideParam == SIDE_LONG) ? (barHigh - entryLevel) : (entryLevel - barLow);
if((bestExtent0 / ref1R) >= g_trailStartRR - 1e-6)
{
trailArmedInLoop = true;
armedTriggerBarTime = barTime;
}
}
}
else
{


if(!trailArmedInLoop || (!allowAutoRestart && barTime <= armedTriggerBarTime))
{
trailingStop = prevTrailingStop;
}
else if(g_atrSource == ATR_SRC_CLOSE_SWING)
{
if(isFormingBar0)
{
trailingStop = prevTrailingStop;
}
else
{
if(sideParam == SIDE_LONG)
{
double newStop = barClose - g_atrMultiplier * atrValue;

double lowestRecent = barLow;
for(int k = 1; k <= g_swingLookback && (i - k) >= 0; k++)
if(rates[i - k].low < lowestRecent)
lowestRecent = rates[i - k].low;

double swingCap = lowestRecent - atrValue * 0.25;
if(newStop > swingCap && barClose > lowestRecent)
newStop = MathMin(newStop, lowestRecent - _Point * 10);

trailingStop = MathMax(prevTrailingStop, newStop);
}
else
{
double newStop = barClose + g_atrMultiplier * atrValue;

double highestRecent = barHigh;
for(int k = 1; k <= g_swingLookback && (i - k) >= 0; k++)
if(rates[i - k].high > highestRecent)
highestRecent = rates[i - k].high;

double swingCap = highestRecent + atrValue * 0.25;
if(newStop < swingCap && barClose < highestRecent)
newStop = MathMax(newStop, highestRecent + _Point * 10);

trailingStop = MathMin(prevTrailingStop, newStop);
}
}
}
else
{
if(sideParam == SIDE_LONG)
{
double newStop = barHigh - g_atrMultiplier * atrValue;
trailingStop = MathMax(prevTrailingStop, newStop);
}
else
{
double newStop = barLow + g_atrMultiplier * atrValue;
trailingStop = MathMin(prevTrailingStop, newStop);
}
}
}

double tierBuffer20 = ref1R * (g_tierPctOf1R / 100.0);
bool tier1WickSaved = false;
bool tier2HalfCut = false;
bool tier3FullBreak = false;

if(hasPrevTrailing && (allowAutoRestart || (trailArmedInLoop && barTime > armedTriggerBarTime)))
{
double tier3HardBoundary = (sideParam == SIDE_LONG) ? (prevTrailingStop - tierBuffer20)
: (prevTrailingStop + tierBuffer20);

if(g_sweepMode == SWEEP_3LAYER_20PCT_1R)
{
if(sideParam == SIDE_LONG)
{
if(barLow <= tier3HardBoundary)
tier3FullBreak = true;
else if(!isFormingBar0)
{
if(barLow < prevTrailingStop && barClose >= prevTrailingStop)
tier1WickSaved = true;
else if(barClose < prevTrailingStop && barClose > tier3HardBoundary)
{
if(!tier2TriggeredCycle)
{ tier2HalfCut = true; tier2TriggeredCycle = true; }
else
tier3FullBreak = true;
}
}
}
else
{
if(barHigh >= tier3HardBoundary)
tier3FullBreak = true;
else if(!isFormingBar0)
{
if(barHigh > prevTrailingStop && barClose <= prevTrailingStop)
tier1WickSaved = true;
else if(barClose > prevTrailingStop && barClose < tier3HardBoundary)
{
if(!tier2TriggeredCycle)
{ tier2HalfCut = true; tier2TriggeredCycle = true; }
else
tier3FullBreak = true;
}
}
}
}
else if(g_sweepMode == SWEEP_WAIT_CANDLE_CLOSE)
{
if(!isFormingBar0)
{
if(sideParam == SIDE_LONG)
{
if(barClose < prevTrailingStop) tier3FullBreak = true;
else if(barLow < prevTrailingStop && barClose >= prevTrailingStop) tier1WickSaved = true;
}
else
{
if(barClose > prevTrailingStop) tier3FullBreak = true;
else if(barHigh > prevTrailingStop && barClose <= prevTrailingStop) tier1WickSaved = true;
}
}
}
else
{
if(sideParam == SIDE_LONG && barLow < prevTrailingStop) tier3FullBreak = true;
if(sideParam == SIDE_SHORT && barHigh > prevTrailingStop) tier3FullBreak = true;
}
}

if(tier1WickSaved && drawPlotOnChart)
{
g_tier1SavedCount++;
double markP = (sideParam == SIDE_LONG) ? barLow : barHigh;
DrawMarkerSymbol("ATRLINE_T1_" + IntegerToString(i), barTime, markP, "T1", clrAqua, -1);
}

if(tier2HalfCut && drawPlotOnChart)
{
g_tier2HalfCutCount++;
double markP = (sideParam == SIDE_LONG) ? barLow : barHigh;
DrawMarkerSymbol("ATRLINE_T2_" + IntegerToString(i), barTime, markP, "T2-50%", C_TIER2_RAY, -1);
}

if(tier3FullBreak)
{
outStopPlotting = true;
if(drawPlotOnChart)
DrawMarkerSymbol("ATRLINE_T3_" + IntegerToString(i), barTime, prevTrailingStop, "T3", C_TIER3_RAY, 0);

if(allowAutoRestart && i < copied - 1)
{
entryLevel = barClose;
outEntryLevel = entryLevel;
firstDayCalculated = true;
trailingStop = (sideParam == SIDE_LONG) ? (entryLevel - atrValue * g_customValueForFirstDay)
: (entryLevel + atrValue * g_customValueForFirstDay);
outFirstBarSlDist = MathAbs(entryLevel - trailingStop);
outStopPlotting = false;
tier2TriggeredCycle = false;
prevPlottedTime = 0;
}
else
{
stopPlotting = true;
}
}

if(!stopPlotting)
{
hasPrevTrailing = true;
prevTrailingStop = trailingStop;

if(drawPlotOnChart)
{
if(prevPlottedTime > 0)
{
DrawTrendSeg("ATRLINE_H_" + IntegerToString(i), prevPlottedTime, prevPlottedValue, barTime, prevPlottedValue, plotColor, 3);
if(MathAbs(trailingStop - prevPlottedValue) >= _Point * 0.5)
DrawTrendSeg("ATRLINE_V_" + IntegerToString(i), barTime, prevPlottedValue, barTime, trailingStop, plotColor, 2);
}
if(i == copied - 1)
{
datetime endPlotTime = MathMax(barTime, chartBar0);
DrawTrendSeg("ATRLINE_H0", barTime, trailingStop, endPlotTime, trailingStop, plotColor, 3);
}
prevPlottedTime = barTime;
prevPlottedValue = trailingStop;
}
}
}
}

return trailingStop;
}

//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
string GetRiskAccountSuffix()
{
string server = AccountInfoString(ACCOUNT_SERVER);
long serverHash = 0;
for(int i = 0; i < StringLen(server); i++)
serverHash = (serverHash * 31 + (long)StringGetCharacter(server, i)) % 2147483647;
return IntegerToString(AccountInfoInteger(ACCOUNT_LOGIN)) + "_" + IntegerToString(serverHash);
}

bool PreparePositionPartialState(long positionId, string partialStateKey)
{
if(positionId <= 0)
return false;

string reviewedKey = AccountScopedGV("EAP85_HISTCHECK_" + IntegerToString(positionId));
if(GlobalVariableCheck(reviewedKey))
return true;

if(!HistorySelectByPosition((ulong)positionId))
return false; // Retry after MT5 has synchronized this position's history.

int total = HistoryDealsTotal();
bool foundClose = false;
for(int i = 0; i < total; i++)
{
ulong deal = HistoryDealGetTicket(i);
if(deal == 0 || HistoryDealGetInteger(deal, DEAL_POSITION_ID) != positionId)
continue;
long entry = HistoryDealGetInteger(deal, DEAL_ENTRY);
if(entry == DEAL_ENTRY_OUT || entry == DEAL_ENTRY_OUT_BY || entry == DEAL_ENTRY_INOUT)
{
if(HistoryDealGetDouble(deal, DEAL_VOLUME) > 0.0)
foundClose = true;
}
}
GlobalVariableSet(reviewedKey, 1.0);
if(foundClose)
GlobalVariableSet(partialStateKey, 1.0);
return true;
}

double GetOrCreateRiskEquityAnchor(string periodKey, double currentEquity,
double periodTradingPnl, double externalCashFlow)
{
string key = "EAP83_EQ_" + GetRiskAccountSuffix() + "_" + periodKey;
if(GlobalVariableCheck(key))
{
double saved = GlobalVariableGet(key);
if(saved > 0.0)
return saved;
}
double anchor = currentEquity - periodTradingPnl - externalCashFlow;
if(anchor <= 0.0)
anchor = currentEquity;
GlobalVariableSet(key, anchor);
return anchor;
}

void CalculateDayWeekMonthPnl(double &outDayPnl, double &outDayPct,
double &outWeekPnl, double &outWeekPct,
double &outMonthPnl, double &outMonthPct)
{
datetime now = TimeCurrent();
MqlDateTime dt;
TimeToStruct(now, dt);

if(g_lastDayOfYear != -1 && g_lastDayOfYear != dt.day_of_year)
{
g_pinExtraDayPct = 0.0;
string restoredCycle = "NGÀY MỚI";
if(dt.day_of_week == 1) { g_pinExtraWeekPct = 0.0; restoredCycle = "TUẦN MỚI"; }
if(dt.day == 1) { g_pinExtraMonthPct = 0.0; restoredCycle = "THÁNG MỚI"; }
SaveLockStateToGV();

if(g_autoSyncDate)
SyncAnchorDateFields(g_resolvedAtrTf, now);

if(g_wasBreachedPrev && !g_inCooldownLock)
NotifyQuotaRestored("KHÔI PHỤC HẠN MỨC " + restoredCycle, "Hạn mức rủi ro đã được làm mới cho chu kỳ giao dịch tiếp theo!");
}
g_lastDayOfYear = dt.day_of_year;

dt.hour = 0; dt.min = 0; dt.sec = 0;
datetime startOfDay = StructToTime(dt);

int daysSinceMonday = (dt.day_of_week == 0) ? 6 : (dt.day_of_week - 1);
datetime startOfWeek = startOfDay - daysSinceMonday * 86400;

MqlDateTime dtMonth = dt;
dtMonth.day = 1; dtMonth.hour = 0; dtMonth.min = 0; dtMonth.sec = 0;
datetime startOfMonth = StructToTime(dtMonth);

double closedDay = 0.0, closedWeek = 0.0, closedMonth = 0.0;
double flowDay = 0.0, flowWeek = 0.0, flowMonth = 0.0;
datetime earliest = MathMin(startOfMonth, startOfWeek);

if(!HistorySelect(earliest, now + 60))
{
g_riskDataAvailable = false;
AlertThrottled("RISK_HISTORY_UNAVAILABLE", "Không tải được lịch sử giao dịch; tạm dừng đề xuất lot vì chưa xác minh được Risk Guard.");
outDayPnl = outWeekPnl = outMonthPnl = 0.0;
outDayPct = outWeekPct = outMonthPct = 0.0;
return;
}
g_riskDataAvailable = true;
{
int totalDeals = HistoryDealsTotal();
for(int i = 0; i < totalDeals; i++)
{
ulong dealTicket = HistoryDealGetTicket(i);
if(dealTicket == 0)
continue;
long entryType = HistoryDealGetInteger(dealTicket, DEAL_ENTRY);
datetime dealTime = (datetime)HistoryDealGetInteger(dealTicket, DEAL_TIME);
long dealType = HistoryDealGetInteger(dealTicket, DEAL_TYPE);
double netPnl = HistoryDealGetDouble(dealTicket, DEAL_PROFIT)
+ HistoryDealGetDouble(dealTicket, DEAL_COMMISSION)
+ HistoryDealGetDouble(dealTicket, DEAL_SWAP)
+ HistoryDealGetDouble(dealTicket, DEAL_FEE);

if(dealType == DEAL_TYPE_BALANCE || dealType == DEAL_TYPE_CREDIT ||
dealType == DEAL_TYPE_BONUS || dealType == DEAL_TYPE_CORRECTION)
{
if(dealTime >= startOfDay) flowDay += netPnl;
if(dealTime >= startOfWeek) flowWeek += netPnl;
if(dealTime >= startOfMonth) flowMonth += netPnl;
continue;
}

bool isTradeExit = (entryType == DEAL_ENTRY_OUT || entryType == DEAL_ENTRY_INOUT || entryType == DEAL_ENTRY_OUT_BY);
bool isAccountCost = (dealType == DEAL_TYPE_CHARGE || dealType == DEAL_TYPE_INTEREST ||
dealType == DEAL_TYPE_COMMISSION || dealType == DEAL_TYPE_COMMISSION_DAILY ||
dealType == DEAL_TYPE_COMMISSION_MONTHLY || dealType == DEAL_TYPE_COMMISSION_AGENT_DAILY ||
dealType == DEAL_TYPE_COMMISSION_AGENT_MONTHLY);
if(!isTradeExit && !isAccountCost)
continue;

if(dealTime >= startOfDay) closedDay += netPnl;
if(dealTime >= startOfWeek) closedWeek += netPnl;
if(dealTime >= startOfMonth) closedMonth += netPnl;
}
}

double floatingPnl = AccountInfoDouble(ACCOUNT_PROFIT);
double eq = GetEffectiveEquity();
double dayStartEquity = 0.0, weekStartEquity = 0.0, monthStartEquity = 0.0;
if(g_useLiveEquity && AccountInfoDouble(ACCOUNT_EQUITY) > 0.0)
{
double liveEquity = AccountInfoDouble(ACCOUNT_EQUITY);
string dayId = TimeToString(startOfDay, TIME_DATE);
string weekId = TimeToString(startOfWeek, TIME_DATE);
string monthId = TimeToString(startOfMonth, TIME_DATE);
StringReplace(dayId, ".", "");
StringReplace(weekId, ".", "");
StringReplace(monthId, ".", "");
dayStartEquity = GetOrCreateRiskEquityAnchor("D_" + dayId, liveEquity, closedDay + floatingPnl, flowDay);
weekStartEquity = GetOrCreateRiskEquityAnchor("W_" + weekId, liveEquity, closedWeek + floatingPnl, flowWeek);
monthStartEquity = GetOrCreateRiskEquityAnchor("M_" + monthId, liveEquity, closedMonth + floatingPnl, flowMonth);
outDayPnl = liveEquity - dayStartEquity - flowDay;
outWeekPnl = liveEquity - weekStartEquity - flowWeek;
outMonthPnl = liveEquity - monthStartEquity - flowMonth;
}
else
{
outDayPnl = closedDay + floatingPnl;
outWeekPnl = closedWeek + floatingPnl;
outMonthPnl = closedMonth + floatingPnl;
dayStartEquity = eq - outDayPnl;
weekStartEquity = eq - outWeekPnl;
monthStartEquity = eq - outMonthPnl;
}
outDayPct = (dayStartEquity > 0.0) ? (outDayPnl / dayStartEquity * 100.0) : 0.0;
outWeekPct = (weekStartEquity > 0.0) ? (outWeekPnl / weekStartEquity * 100.0) : 0.0;
outMonthPct = (monthStartEquity > 0.0) ? (outMonthPnl / monthStartEquity * 100.0) : 0.0;

double effMaxDay = g_maxDailyLossPct + g_pinExtraDayPct;
double effMaxWeek = g_maxWeeklyLossPct + g_pinExtraWeekPct;
double effMaxMonth = g_maxMonthlyLossPct + g_pinExtraMonthPct;

bool rawBreach = false;
string rawReason = "";

if(g_enRiskGuard)
{
if(effMaxDay > 0.0 && outDayPct <= -effMaxDay)
{ rawBreach = true; rawReason = StringFormat("Quá lỗ NGÀY (%.2f%% <= -%.1f%%)", outDayPct, effMaxDay); }
else if(effMaxWeek > 0.0 && outWeekPct <= -effMaxWeek)
{ rawBreach = true; rawReason = StringFormat("Quá lỗ TUẦN (%.2f%% <= -%.1f%%)", outWeekPct, effMaxWeek); }
else if(effMaxMonth > 0.0 && outMonthPct <= -effMaxMonth)
{ rawBreach = true; rawReason = StringFormat("Quá lỗ THÁNG (%.2f%% <= -%.1f%%)", outMonthPct, effMaxMonth); }
}

if(rawBreach)
{
if(g_breachTimestamp == 0)
{
g_breachTimestamp = now;
g_inRecoveryMode = true;
g_recStartMonthPct = outMonthPct;
SaveLockStateToGV();
}
}

g_inCooldownLock = false;
g_cooldownRemSec = 0;
if(g_enRiskGuard && g_breachTimestamp > 0 && g_cooldownHours > 0.0)
{
int elapsedSec = (int)(now - g_breachTimestamp);
int requiredSec = (int)MathRound(g_cooldownHours * 3600.0);
if(elapsedSec < requiredSec)
{
g_inCooldownLock = true;
g_cooldownRemSec = requiredSec - elapsedSec;
}
else if(!rawBreach)
{
g_breachTimestamp = 0;
g_inRecoveryMode = true;
g_recStartMonthPct = outMonthPct;
SaveLockStateToGV();
NotifyQuotaRestored("HẾT GIỜ HẠ NHIỆT - MỞ KHÓA TÀI KHOẢN",
StringFormat("Tài khoản đã được mở khóa trong CHẾ ĐỘ PHỤC HỒI (Risk: %.2f%%/lệnh). Khi lãi đạt +%.1f%% sẽ khôi phục 100%% hạn mức!",
GetActiveRiskPercent(), g_recoveryTargetPct));
}
}

if(g_inRecoveryMode && !rawBreach && !g_inCooldownLock)
{
double gainedPct = outMonthPct - g_recStartMonthPct;
if(gainedPct >= g_recoveryTargetPct)
{
g_inRecoveryMode = false;
SaveLockStateToGV();
NotifyQuotaRestored("KHÔI PHỤC 100%% HẠN MỨC RỦI RO",
StringFormat("Chúc mừng! Bạn đã đạt lợi nhuận phục hồi +%.2f%%. Hạn mức Risk/Lệnh đã được khôi phục về 100%% (%.2f%%)!",
gainedPct, g_riskPct));
}
}

g_riskBreached = (rawBreach || g_inCooldownLock);
g_wasBreachedPrev = g_riskBreached;

if(rawBreach)
{
if(g_inCooldownLock)
{
int h = g_cooldownRemSec / 3600;
int m = (g_cooldownRemSec % 3600) / 60;
g_breachReason = StringFormat("%s | Hạ nhiệt %02dg:%02dp", rawReason, h, m);
}
else
g_breachReason = rawReason;
}
else if(g_inCooldownLock)
{
int h = g_cooldownRemSec / 3600;
int m = (g_cooldownRemSec % 3600) / 60;
g_breachReason = StringFormat("KHÓA HẠ NHIỆT (Mở sau %02dg:%02dp)", h, m);
}
else
g_breachReason = "";
}

void TryEmergencyPinUnlock()
{
string cleanPin = g_enteredPinStr;
StringTrimLeft(cleanPin);
StringTrimRight(cleanPin);

if(cleanPin != InpUnlockPinCode)
{
Alert("SAI MÃ PIN! Hãy nhập đúng mã PIN (Mặc định: ", InpUnlockPinCode, ")");
return;
}

double dayPnl, dayPct, weekPnl, weekPct, monthPnl, monthPct;
CalculateDayWeekMonthPnl(dayPnl, dayPct, weekPnl, weekPct, monthPnl, monthPct);

if(dayPct <= -(g_maxDailyLossPct + g_pinExtraDayPct))
g_pinExtraDayPct = MathAbs(dayPct) - g_maxDailyLossPct + InpPinExtraBufferPct;
if(weekPct <= -(g_maxWeeklyLossPct + g_pinExtraWeekPct))
g_pinExtraWeekPct = MathAbs(weekPct) - g_maxWeeklyLossPct + InpPinExtraBufferPct;
if(monthPct <= -(g_maxMonthlyLossPct + g_pinExtraMonthPct))
g_pinExtraMonthPct = MathAbs(monthPct) - g_maxMonthlyLossPct + InpPinExtraBufferPct;

g_breachTimestamp = 0;
g_inCooldownLock = false;
g_riskBreached = false;
g_manualForceLock = false;
g_inRecoveryMode = true;
g_recStartMonthPct = monthPct;
g_enteredPinStr = "****";

SaveLockStateToGV();
RebuildCleanPanel(true);
ProcessCoreLogic();

NotifyQuotaRestored("MỞ KHÓA KHẨN CẤP BẰNG PIN (" + InpUnlockPinCode + ")",
StringFormat("Đã cấp thêm +%.1f%% hạn mức dự phòng và bật CHẾ ĐỘ PHỤC HỒI (50%% Risk = %.2f%%/lệnh).",
InpPinExtraBufferPct, GetActiveRiskPercent()));
}

//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
bool ParseNewsSlotTime(string timeStr, datetime refNow, datetime &outEventTime)
{
string clean = timeStr;
StringTrimLeft(clean);
StringTrimRight(clean);
if(StringLen(clean) < 4 || StringFind(clean, ":") <= 0 || clean == "00:00" || clean == "0:00" || clean == "0")
return false;

MqlDateTime day;
TimeToStruct(refNow, day);
day.hour = 0; day.min = 0; day.sec = 0;
datetime today = StructToTime(day);
long bestDistance = 2147483647;
datetime bestEvent = 0;
for(int shift = -1; shift <= 1; shift++)
{
datetime candidateDay = today + (datetime)(shift * 86400);
datetime candidate = StringToTime(TimeToString(candidateDay, TIME_DATE) + " " + clean);
if(candidate <= 0)
continue;
long distance = (long)MathAbs((double)(candidate - refNow));
if(distance < bestDistance)
{
bestDistance = distance;
bestEvent = candidate;
}
}
outEventTime = bestEvent;
return (outEventTime > 0);
}

void DrawNewsVerticalLine(string slotName, datetime evServerTime, string labelText, bool isDanger)
{
string obj = VIS_PREFIX + "NEWS_" + slotName;
if(evServerTime <= 0)
{
ObjectDelete(0, obj);
return;
}
if(ObjectFind(0, obj) < 0)
{
ObjectCreate(0, obj, OBJ_VLINE, 0, evServerTime, 0);
ObjectSetInteger(0, obj, OBJPROP_SELECTABLE, false);
ObjectSetInteger(0, obj, OBJPROP_BACK, true);
}
ObjectSetInteger(0, obj, OBJPROP_TIME, 0, evServerTime);
ObjectSetInteger(0, obj, OBJPROP_COLOR, isDanger ? clrRed : clrMediumOrchid);
ObjectSetInteger(0, obj, OBJPROP_STYLE, isDanger ? STYLE_SOLID : STYLE_DOT);
ObjectSetInteger(0, obj, OBJPROP_WIDTH, isDanger ? 2 : 1);
ObjectSetString(0, obj, OBJPROP_TEXT, labelText);
}

bool CheckNewsScheduleAndLock(datetime &outActiveWindowStartServer, datetime &outActiveWindowEndServer)
{
outActiveWindowStartServer = 0;
outActiveWindowEndServer = 0;

if(!g_enNewsFilter)
{
g_newsStatusText = "Lọc tin: TẮT";
DrawNewsVerticalLine("S1", 0, "", false);
DrawNewsVerticalLine("S2", 0, "", false);
DrawNewsVerticalLine("S3", 0, "", false);
return false;
}

datetime serverNow = TimeCurrent();
datetime localNow = TimeLocal();
datetime refNow = (g_newsTz == TZ_LOCAL_PC) ? localNow : serverNow;
long tzOffset = (long)(serverNow - localNow);

string slots[3];
slots[0] = g_newsSlot1;
slots[1] = g_newsSlot2;
slots[2] = g_newsSlot3;

bool slotEnabled[3];
slotEnabled[0] = g_enSlot1;
slotEnabled[1] = g_enSlot2;
slotEnabled[2] = g_enSlot3;

int activeSlotCount = 0;
bool inForbiddenWindow = false;
int nearestFutureSec = 999999;
string nearestSlotStr = "";
string activeLockStr = "";

for(int i = 0; i < 3; i++)
{
string slotId = "S" + IntegerToString(i + 1);
datetime evTimeRef = 0;

if(!slotEnabled[i] || !ParseNewsSlotTime(slots[i], refNow, evTimeRef))
{
DrawNewsVerticalLine(slotId, 0, "", false);
continue;
}

activeSlotCount++;
int diffSec = (int)(evTimeRef - refNow);
bool slotDanger = (diffSec <= g_minBeforeNews * 60 && diffSec >= -g_minAfterNews * 60);

datetime evServerTime = (g_newsTz == TZ_LOCAL_PC) ? (evTimeRef + (datetime)tzOffset) : evTimeRef;
DrawNewsVerticalLine(slotId, evServerTime, "Tin " + IntegerToString(i + 1) + " (" + slots[i] + ")", slotDanger);

if(slotDanger)
{
inForbiddenWindow = true;
outActiveWindowStartServer = evServerTime - g_minBeforeNews * 60;
outActiveWindowEndServer = evServerTime + g_minAfterNews * 60;
activeLockStr = "CẤM TRADE: Đang vướng tin " + IntegerToString(i + 1) + " (" + slots[i] + ")!";
}
else if(diffSec > 0 && diffSec < nearestFutureSec)
{
nearestFutureSec = diffSec;
nearestSlotStr = "Tin " + IntegerToString(i + 1) + " (" + slots[i] + ")";
}
}

if(activeSlotCount == 0)
g_newsStatusText = "Tin: Chưa bật khung giờ";
else if(inForbiddenWindow)
g_newsStatusText = activeLockStr;
else if(nearestFutureSec < 999999)
{
int mins = nearestFutureSec / 60;
int secs = nearestFutureSec % 60;
g_newsStatusText = StringFormat("Bật %d tin | Tới %s (%02dp:%02ds)", activeSlotCount, nearestSlotStr, mins, secs);
}
else
g_newsStatusText = StringFormat("Tin (%d khung): An toàn", activeSlotCount);

return inForbiddenWindow;
}

//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
void DrawSizerHLine(string name, double price, color clr, int width, ENUM_LINE_STYLE style, bool show)
{
string obj = DRAG_PREFIX + name;
if(!show || price <= 0.0)
{
ObjectDelete(0, obj);
return;
}
if(ObjectFind(0, obj) < 0)
{
ObjectCreate(0, obj, OBJ_HLINE, 0, 0, price);
ObjectSetInteger(0, obj, OBJPROP_COLOR, clr);
ObjectSetInteger(0, obj, OBJPROP_WIDTH, width);
ObjectSetInteger(0, obj, OBJPROP_STYLE, style);
ObjectSetInteger(0, obj, OBJPROP_SELECTABLE, true);
ObjectSetInteger(0, obj, OBJPROP_SELECTED, true);
ObjectSetInteger(0, obj, OBJPROP_BACK, false);
}
ObjectSetDouble(0, obj, OBJPROP_PRICE, 0, price);
}

void DrawSizerZone(string name, datetime t1, datetime t2, double p1, double p2, color rawClr, bool show)
{
string obj = DRAG_PREFIX + name;
if(!show || p1 <= 0.0 || p2 <= 0.0 || p1 == p2)
{
ObjectDelete(0, obj);
return;
}
if(ObjectFind(0, obj) < 0)
{
ObjectCreate(0, obj, OBJ_RECTANGLE, 0, t1, p1, t2, p2);
ObjectSetInteger(0, obj, OBJPROP_FILL, true);
ObjectSetInteger(0, obj, OBJPROP_BACK, true);
ObjectSetInteger(0, obj, OBJPROP_SELECTABLE, false);
}
color blended = BlendWithBg(rawClr, 14.0);
ObjectSetInteger(0, obj, OBJPROP_TIME, 0, t1);
ObjectSetDouble(0, obj, OBJPROP_PRICE, 0, p1);
ObjectSetInteger(0, obj, OBJPROP_TIME, 1, t2);
ObjectSetDouble(0, obj, OBJPROP_PRICE, 1, p2);
ObjectSetInteger(0, obj, OBJPROP_BGCOLOR, blended);
ObjectSetInteger(0, obj, OBJPROP_COLOR, blended);
}

void DrawSizerTag(string name, datetime t, double price, string text, color clr, ENUM_ANCHOR_POINT anchor, bool show)
{
string obj = DRAG_PREFIX + name;
if(!show || price <= 0.0)
{
ObjectDelete(0, obj);
return;
}
if(ObjectFind(0, obj) < 0)
{
ObjectCreate(0, obj, OBJ_TEXT, 0, t, price);
ObjectSetString(0, obj, OBJPROP_FONT, "Segoe UI Bold");
ObjectSetInteger(0, obj, OBJPROP_SELECTABLE, false);
}
ObjectSetInteger(0, obj, OBJPROP_ANCHOR, anchor);
ObjectSetInteger(0, obj, OBJPROP_TIME, 0, t);
ObjectSetDouble(0, obj, OBJPROP_PRICE, 0, price);
ObjectSetInteger(0, obj, OBJPROP_FONTSIZE, InpFontSize);
ObjectSetInteger(0, obj, OBJPROP_COLOR, clr);
ObjectSetString(0, obj, OBJPROP_TEXT, text);
}

//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
void CalculateSizingAndActiveRules(int openOrderCount,
double openTotalVol,
double openVwapEntry,
double openActiveSL,
double openActiveTP,
bool openIsLong,
long anchorId,
datetime earliestOpenTime,
double &outSlPriceDist,
double &outSlPoints,
double &outRecommendedLot,
double &outDisplayVol,
double &outDisplayRiskCash,
double &outDisplayRiskPct,
bool &outRiskKnown,
double &outDisplayRewardCash,
double &outPartialLot,
double &outRemainLot)
{
outSlPriceDist = 0.0;
outSlPoints = 0.0;
outRecommendedLot = 0.0;
outDisplayVol = 0.0;
outDisplayRiskCash = 0.0;
outDisplayRiskPct = 0.0;
outRiskKnown = true;
outDisplayRewardCash = 0.0;
outPartialLot = 0.0;
outRemainLot = 0.0;

double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);

int pendingCount = 0;
double pendingEntry = 0.0, pendingSL = 0.0, pendingTP = 0.0, pendingVol = 0.0;
bool pendingIsLong = true;
datetime pendingTime = 0;
if(openOrderCount == 0)
{
for(int j = OrdersTotal() - 1; j >= 0; j--)
{
ulong ordTk = OrderGetTicket(j);
if(ordTk > 0 && OrderGetString(ORDER_SYMBOL) == _Symbol)
{
pendingCount++;
pendingEntry = OrderGetDouble(ORDER_PRICE_OPEN);
pendingSL = OrderGetDouble(ORDER_SL);
pendingTP = OrderGetDouble(ORDER_TP);
pendingVol += OrderGetDouble(ORDER_VOLUME_CURRENT);
pendingTime = (datetime)OrderGetInteger(ORDER_TIME_SETUP);
long oType = OrderGetInteger(ORDER_TYPE);
pendingIsLong = (oType == ORDER_TYPE_BUY_LIMIT || oType == ORDER_TYPE_BUY_STOP || oType == ORDER_TYPE_BUY_STOP_LIMIT);
}
}
}

bool isLong = (openOrderCount > 0) ? openIsLong : ((pendingCount > 0) ? pendingIsLong : (g_tradeSide == SIDE_LONG));
ENUM_TIMEFRAMES setupTf = (g_resolvedAtrTf != PERIOD_CURRENT) ? g_resolvedAtrTf : _Period;
double live = iClose(_Symbol, setupTf, 1);
if(live <= 0.0)
live = isLong ? (ask > 0.0 ? ask : bid) : (bid > 0.0 ? bid : ask);

double atrValue = (g_pineLatestAtr > 0.0) ? g_pineLatestAtr : (100 * _Point);
double sign = isLong ? 1.0 : -1.0;

double equity = GetEffectiveEquity();
double activeRiskPct = GetActiveRiskPercent();
double riskBudgetCash = equity * (activeRiskPct / 100.0);
if(g_enRiskGuard && !g_riskDataAvailable)
{
riskBudgetCash = 0.0;
outRiskKnown = false;
}

double techSlDist = (g_pineFirstBarSlDist > 0.0) ? g_pineFirstBarSlDist : (atrValue * g_customValueForFirstDay);
if(g_slMode == SL_MODE_ATR_LINE && g_pineTrailingStop > 0.0 && !g_pineStopPlotting)
{
double refEntry = (openOrderCount > 0) ? openVwapEntry : (g_pinSizerEntry && g_sizerEntryPrice > 0.0 ? g_sizerEntryPrice : live);
double distLine = MathAbs(refEntry - g_pineTrailingStop);
if(distLine > 0.0)
techSlDist = distLine;
}
else if(g_slMode == SL_MODE_POINTS)
techSlDist = g_manualSlPts * _Point;
else if(g_slMode == SL_MODE_DRAG && g_sizerEntryPrice > 0.0 && g_sizerSlPrice > 0.0)
techSlDist = MathAbs(g_sizerEntryPrice - g_sizerSlPrice);

if(techSlDist <= 0.0)
techSlDist = atrValue * g_customValueForFirstDay;

if(openOrderCount > 0 && openTotalVol > 0.0)
{
// 1. Khi lệnh đã khớp: dùng GIÁ KHỚP THỰC TẾ (openVwapEntry = VWAP POSITION_PRICE_OPEN) làm chuẩn tính SL/TP, R và Rủi ro
g_actualFillEntryPrice = NormalizeDouble(openVwapEntry, _Digits);
g_sizerEntryPrice = g_actualFillEntryPrice;
if(g_plannedEntryPrice <= 0.0)
g_plannedEntryPrice = (g_standbyLockedEntry > 0.0) ? g_standbyLockedEntry : g_actualFillEntryPrice;
outDisplayVol = openTotalVol;

string gvLock1R = AccountScopedGV("EAP82_LK1R_" + IntegerToString(anchorId));
string gvLockSL = AccountScopedGV("EAP82_LKSL_" + IntegerToString(anchorId));
string gvLockTP = AccountScopedGV("EAP82_LKTP_" + IntegerToString(anchorId));
string gvLockVl = AccountScopedGV("EAP82_LKVL_" + IntegerToString(anchorId));

double savedVol = GlobalVariableCheck(gvLockVl) ? GlobalVariableGet(gvLockVl) : 0.0;
double locked1R = GlobalVariableCheck(gvLock1R) ? GlobalVariableGet(gvLock1R) : 0.0;
double lockedSL = GlobalVariableCheck(gvLockSL) ? GlobalVariableGet(gvLockSL) : 0.0;
double lockedTP = GlobalVariableCheck(gvLockTP) ? GlobalVariableGet(gvLockTP) : 0.0;

bool slStillInRiskZone = (openActiveSL > 0.0) && ((isLong && openActiveSL < openVwapEntry - _Point) || (!isLong && openActiveSL > openVwapEntry + _Point));

if(locked1R <= 0.0 || openTotalVol > savedVol + 1e-5 || (slStillInRiskZone && !g_isTrailingArmedNow))
{
if(slStillInRiskZone)
{
locked1R = MathAbs(openVwapEntry - openActiveSL);
}
else if(g_volRule == RULE_SCALE_DIST_BY_VOL)
{
double budgetPerLot = riskBudgetCash / openTotalVol;
double scaledDistance = FindStopDistanceForRiskBudget(_Symbol, isLong, openVwapEntry,
budgetPerLot, g_bufferPts, g_commPerLot);
locked1R = (scaledDistance > 0.0) ? scaledDistance : techSlDist;
if(scaledDistance <= 0.0)
AlertThrottled("RISK_SCALE_UNAVAILABLE", "Không thể tính SL theo Risk/Vol bằng dữ liệu broker; giữ nguyên khoảng SL đang chọn.");
}
else
{
locked1R = techSlDist;
}
lockedSL = (openActiveSL > 0.0) ? openActiveSL : NormalizeDouble(g_sizerEntryPrice - sign * locked1R, _Digits);
lockedTP = (openActiveTP > 0.0) ? openActiveTP : NormalizeDouble(g_sizerEntryPrice + sign * locked1R * g_targetRR, _Digits);

GlobalVariableSet(gvLock1R, locked1R);
GlobalVariableSet(gvLockSL, lockedSL);
GlobalVariableSet(gvLockTP, lockedTP);
GlobalVariableSet(gvLockVl, openTotalVol);
}

// Tính khoảng cách SL thực tế từ Giá khớp thực tế đến SL đang đặt
double actualSlDistFromFill = (openActiveSL > 0.0) ? MathAbs(g_sizerEntryPrice - openActiveSL) : locked1R;
outSlPriceDist = (actualSlDistFromFill > 0.0) ? actualSlDistFromFill : locked1R;
g_sizerSlPrice = (openActiveSL > 0.0) ? NormalizeDouble(openActiveSL, _Digits) : NormalizeDouble(lockedSL, _Digits);
// Nếu Hard TP trên server đã được gỡ để phục vụ chạm 2R cắt 50% & Trail, hiển thị mốc mục tiêu TP1/Target dự kiến theo Giá khớp thực tế
double visualTargetTp = NormalizeDouble(g_sizerEntryPrice + sign * outSlPriceDist * g_targetRR, _Digits);
g_sizerTpPrice = (openActiveTP > 0.0) ? NormalizeDouble(openActiveTP, _Digits) : ((lockedTP > 0.0 && !g_hardTpSuppressedForPartial) ? NormalizeDouble(lockedTP, _Digits) : visualTargetTp);
}
else if(pendingCount > 0 && pendingEntry > 0.0)
{
g_plannedEntryPrice = NormalizeDouble(pendingEntry, _Digits);
g_actualFillEntryPrice = 0.0;
g_sizerEntryPrice = g_plannedEntryPrice;
outSlPriceDist = (pendingSL > 0.0) ? MathAbs(pendingEntry - pendingSL) : techSlDist;
g_sizerSlPrice = (pendingSL > 0.0) ? NormalizeDouble(pendingSL, _Digits) : NormalizeDouble(g_sizerEntryPrice - sign * outSlPriceDist, _Digits);
g_sizerTpPrice = (pendingTP > 0.0) ? NormalizeDouble(pendingTP, _Digits) : NormalizeDouble(g_sizerEntryPrice + sign * outSlPriceDist * g_targetRR, _Digits);

outDisplayVol = pendingVol;
}
else
{
g_actualFillEntryPrice = 0.0;
if(g_slMode == SL_MODE_DRAG)
{
if(g_sizerEntryPrice <= 0.0)
g_sizerEntryPrice = NormalizeDouble(live, _Digits);
if(g_sizerSlPrice <= 0.0)
g_sizerSlPrice = NormalizeDouble(g_sizerEntryPrice - sign * techSlDist, _Digits);

outSlPriceDist = MathAbs(g_sizerEntryPrice - g_sizerSlPrice);
bool dragBuy = (g_sizerEntryPrice >= g_sizerSlPrice);
g_tradeSide = dragBuy ? SIDE_LONG : SIDE_SHORT;
g_sizerTpPrice = dragBuy ? NormalizeDouble(g_sizerEntryPrice + outSlPriceDist * g_targetRR, _Digits)
: NormalizeDouble(g_sizerEntryPrice - outSlPriceDist * g_targetRR, _Digits);
g_plannedEntryPrice = g_sizerEntryPrice;
if(InpLockStandbySetupTfAndBar)
{
g_standbyLockedEntry = g_sizerEntryPrice;
g_standbyLockedSl = g_sizerSlPrice;
g_standbyLockedTp = g_sizerTpPrice;
g_standbyLocked1R = outSlPriceDist;
g_standbySetupLocked = true;
SaveStandbySetupToGV();
}
}
else if(g_pinSizerEntry && g_sizerEntryPrice > 0.0)
{
outSlPriceDist = (g_pinnedSlDist > 0.0) ? g_pinnedSlDist : techSlDist;
g_sizerSlPrice = NormalizeDouble(g_sizerEntryPrice - sign * outSlPriceDist, _Digits);
g_sizerTpPrice = NormalizeDouble(g_sizerEntryPrice + sign * outSlPriceDist * g_targetRR, _Digits);
g_plannedEntryPrice = g_sizerEntryPrice;
}
else if(InpLockStandbySetupTfAndBar && g_standbySetupLocked && g_standbyLockedEntry > 0.0 && g_standbyLocked1R > 0.0)
{
// 6. Khóa khung và nến cho từng setup lúc chờ lệnh: giữ nguyên Entry/SL/TP kế hoạch khi đổi khung biểu đồ
g_sizerEntryPrice = NormalizeDouble(g_standbyLockedEntry, _Digits);
outSlPriceDist = g_standbyLocked1R;
g_pinnedSlDist = g_standbyLocked1R;
g_sizerSlPrice = NormalizeDouble(g_standbyLockedSl, _Digits);
g_sizerTpPrice = NormalizeDouble(g_standbyLockedTp, _Digits);
g_plannedEntryPrice = g_sizerEntryPrice;
}
else
{
g_sizerEntryPrice = NormalizeDouble(live, _Digits);
outSlPriceDist = techSlDist;
g_pinnedSlDist = techSlDist;
g_sizerSlPrice = (g_slMode == SL_MODE_ATR_LINE && g_pineTrailingStop > 0.0 && !g_pineStopPlotting)
? NormalizeDouble(g_pineTrailingStop, _Digits)
: NormalizeDouble(g_sizerEntryPrice - sign * outSlPriceDist, _Digits);
outSlPriceDist = MathAbs(g_sizerEntryPrice - g_sizerSlPrice);
g_sizerTpPrice = NormalizeDouble(g_sizerEntryPrice + sign * outSlPriceDist * g_targetRR, _Digits);
g_plannedEntryPrice = g_sizerEntryPrice;

if(InpLockStandbySetupTfAndBar && g_sizerEntryPrice > 0.0 && outSlPriceDist > 0.0)
{
g_standbyLockedTf = setupTf;
g_standbyLockedRefBarTime = iTime(_Symbol, setupTf, 1);
g_standbyLockedEntry = g_sizerEntryPrice;
g_standbyLockedSl = g_sizerSlPrice;
g_standbyLockedTp = g_sizerTpPrice;
g_standbyLocked1R = outSlPriceDist;
g_standbySetupLocked = true;
SaveStandbySetupToGV();
}
}
}

// Tính khoảng cách SL (điểm) và tỷ lệ R thực tế từ Giá khớp thực tế (khi có lệnh) hoặc Entry kế hoạch (khi chờ lệnh)
double currentSlGap = MathAbs(g_sizerEntryPrice - g_sizerSlPrice);
outSlPoints = (_Point > 0.0) ? (currentSlGap / _Point) : 0.0;
double tpDistancePrice = MathAbs(g_sizerTpPrice - g_sizerEntryPrice);
double actualRR = (currentSlGap > 0.0) ? (tpDistancePrice / currentSlGap) : g_targetRR;

// 2-4 & 7. Tính lot từ ngân sách rủi ro (Equity * %Risk) chia cho lỗ 1 lot (OrderCalcProfit), làm tròn xuống theo SYMBOL_VOLUME_STEP,
// đồng thời chia ngân sách rủi ro cho các lệnh thành phần trong cùng setup (VD: 50% + 30% + 20% = 0.25% + 0.15% + 0.10%)
double riskOneLot = 0.0;
bool stopOnLossSide = isLong ? (g_sizerSlPrice < g_sizerEntryPrice) : (g_sizerSlPrice > g_sizerEntryPrice);
bool oneLotRiskKnown = stopOnLossSide && EstimateStopRiskCash(_Symbol, isLong, 1.0, g_sizerEntryPrice,
g_sizerSlPrice, g_bufferPts, g_commPerLot, riskOneLot);

double totalSetupBudget = riskBudgetCash;
if(InpMaxPortfolioRiskPct > 0.0)
{
double portfolioRisk = 0.0;
if(!CalculateAccountExposureRisk(portfolioRisk))
{
totalSetupBudget = 0.0;
outRiskKnown = false;
}
else if(openOrderCount == 0 && pendingCount == 0)
{
totalSetupBudget = MathMin(totalSetupBudget,
MathMax(0.0, equity * (InpMaxPortfolioRiskPct / 100.0) - portfolioRisk));
}
}

double currentSymbolRiskCash = 0.0, currentSymbolVol = 0.0;
bool symbolExposureKnown = true;
if(openOrderCount > 0 || pendingCount > 0)
symbolExposureKnown = CalculateChartSymbolExposureRisk(currentSymbolRiskCash, currentSymbolVol, true);

g_remainingSetupRiskCash = MathMax(0.0, totalSetupBudget - (symbolExposureKnown ? currentSymbolRiskCash : totalSetupBudget));
g_remainingSetupRiskPct = (equity > 0.0) ? (g_remainingSetupRiskCash / equity * 100.0) : 0.0;

double s1 = MathMax(0.0, InpLeg1RiskSharePct);
double s2 = MathMax(0.0, InpLeg2RiskSharePct);
double s3 = MathMax(0.0, InpLeg3RiskSharePct);
double sumShares = s1 + s2 + s3;
if(sumShares <= 0.0) { s1 = 100.0; s2 = 0.0; s3 = 0.0; sumShares = 100.0; }
double w1 = s1 / sumShares;
double w2 = s2 / sumShares;
double w3 = s3 / sumShares;

if(oneLotRiskKnown && riskOneLot > 0.0 && totalSetupBudget > 0.0)
{
outRecommendedLot = FloorLotStep(totalSetupBudget / riskOneLot);
g_leg1SuggestedLot = FloorLotStep((totalSetupBudget * w1) / riskOneLot);
g_leg2SuggestedLot = FloorLotStep((totalSetupBudget * w2) / riskOneLot);
g_leg3SuggestedLot = FloorLotStep((totalSetupBudget * w3) / riskOneLot);

int activeOrderLegs = openOrderCount + pendingCount;
if(InpSplitSetupRiskAcrossOrders)
{
double nextLegTargetCash = 0.0;
if(activeOrderLegs == 0)
nextLegTargetCash = totalSetupBudget * w1;
else if(activeOrderLegs == 1)
nextLegTargetCash = MathMin(g_remainingSetupRiskCash, totalSetupBudget * w2);
else
nextLegTargetCash = g_remainingSetupRiskCash;
g_nextAddOnSuggestedLot = (nextLegTargetCash > 0.0) ? FloorLotStep(nextLegTargetCash / riskOneLot) : 0.0;
}
else
{
g_nextAddOnSuggestedLot = (g_remainingSetupRiskCash > 0.0) ? FloorLotStep(g_remainingSetupRiskCash / riskOneLot) : 0.0;
}

if(openOrderCount == 0 && pendingCount == 0)
outDisplayVol = (g_enteredManualLot > 0.0) ? FloorLotStep(g_enteredManualLot) : outRecommendedLot;
}
else
{
outRiskKnown = false;
outRecommendedLot = 0.0;
g_leg1SuggestedLot = 0.0;
g_leg2SuggestedLot = 0.0;
g_leg3SuggestedLot = 0.0;
g_nextAddOnSuggestedLot = 0.0;
if(openOrderCount == 0 && pendingCount == 0)
outDisplayVol = (g_enteredManualLot > 0.0) ? FloorLotStep(g_enteredManualLot) : 0.0;
}

if(openOrderCount > 0 || pendingCount > 0)
{
double exposureRisk = 0.0, exposureVol = 0.0;
outRiskKnown = CalculateChartSymbolExposureRisk(exposureRisk, exposureVol, openOrderCount == 0);
outDisplayRiskCash = outRiskKnown ? exposureRisk : 0.0;
outDisplayVol = exposureVol;
}
else
outDisplayRiskCash = outRiskKnown ? riskOneLot * outDisplayVol : 0.0;
outDisplayRiskPct = (outRiskKnown && equity > 0.0) ? (outDisplayRiskCash / equity * 100.0) : 0.0;

double pnlAtTarget = 0.0;
if(outDisplayVol > 0.0 && OrderCalcProfit(isLong ? ORDER_TYPE_BUY : ORDER_TYPE_SELL,
_Symbol, outDisplayVol, g_sizerEntryPrice, g_sizerTpPrice, pnlAtTarget))
outDisplayRewardCash = MathMax(0.0, pnlAtTarget - MathMax(0.0, g_commPerLot) * outDisplayVol);
else
outDisplayRewardCash = 0.0;

double minL = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
if(outDisplayVol > 0.0 && g_enPartial)
{
double pLot = FloorLotStep(outDisplayVol * (g_partialPct / 100.0));
if(pLot >= minL && (outDisplayVol - pLot) >= minL - 1e-6)
{
outPartialLot = pLot;
outRemainLot = NormalizeDouble(outDisplayVol - pLot, GetStepDigits(SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP)));
}
else
{
outPartialLot = 0.0;
outRemainLot = outDisplayVol;
}
}
else
{
outPartialLot = 0.0;
outRemainLot = outDisplayVol;
}

// =========================================================================

// =========================================================================
datetime tRight = TimeCurrent();
datetime tLeft = tRight - 86400;

// Use absolute times so the Entry/SL/TP zone stays fixed when changing chart timeframe.
if(openOrderCount > 0 && earliestOpenTime > 0)
tLeft = earliestOpenTime;
else if(pendingCount > 0 && pendingTime > 0)
tLeft = pendingTime;
else if(InpLockStandbySetupTfAndBar && g_standbySetupLocked && g_standbyLockedRefBarTime > 0)
tLeft = g_standbyLockedRefBarTime;

DrawSizerHLine("ENTRY", g_sizerEntryPrice, clrDodgerBlue, 2, STYLE_SOLID, g_showSizer);
DrawSizerHLine("SL", g_sizerSlPrice, clrRed, 2, STYLE_SOLID, g_showSizer);
DrawSizerHLine("TP", g_sizerTpPrice, clrLimeGreen, 2, STYLE_DASH, g_showSizer);

// Vẽ thêm đường tham chiếu "Entry kế hoạch" nét chấm mảnh khi đã khớp lệnh và có độ lệch so với Giá khớp thực tế
bool showPlannedRefLine = (g_showSizer && openOrderCount > 0 && g_plannedEntryPrice > 0.0 && MathAbs(g_plannedEntryPrice - g_sizerEntryPrice) >= _Point);
string planLineObj = DRAG_PREFIX + "PLAN_ENTRY";
if(showPlannedRefLine)
{
if(ObjectFind(0, planLineObj) < 0)
{
ObjectCreate(0, planLineObj, OBJ_HLINE, 0, 0, g_plannedEntryPrice);
ObjectSetInteger(0, planLineObj, OBJPROP_COLOR, clrSilver);
ObjectSetInteger(0, planLineObj, OBJPROP_WIDTH, 1);
ObjectSetInteger(0, planLineObj, OBJPROP_STYLE, STYLE_DOT);
ObjectSetInteger(0, planLineObj, OBJPROP_SELECTABLE, false);
ObjectSetInteger(0, planLineObj, OBJPROP_BACK, true);
}
ObjectSetDouble(0, planLineObj, OBJPROP_PRICE, 0, g_plannedEntryPrice);
}
else
ObjectDelete(0, planLineObj);

DrawSizerZone("Z_RISK", tLeft, tRight, g_sizerEntryPrice, g_sizerSlPrice, clrRed, g_showSizer);
DrawSizerZone("Z_REWARD", tLeft, tRight, g_sizerEntryPrice, g_sizerTpPrice, clrLimeGreen, g_showSizer);

string tfLockStr = GetTfShortName(g_resolvedAtrTf);
string openTimeStr = (openOrderCount > 0 && earliestOpenTime > 0) ? TimeToString(earliestOpenTime, TIME_MINUTES) : "";

double entryDiffPts = (openOrderCount > 0 && g_plannedEntryPrice > 0.0 && _Point > 0.0)
? ((g_sizerEntryPrice - g_plannedEntryPrice) / _Point) : 0.0;

string entryTagTxt = "";
if(openOrderCount > 0)
{
entryTagTxt = StringFormat("GIÁ KHỚP THỰC TẾ (%d lệnh | %s): %s [Entry KH: %s | Lệch: %+.0f pts] | MỞ: %.2f LOT (Gợi ý: %.2f) ",
openOrderCount, tfLockStr, DoubleToString(g_sizerEntryPrice, _Digits),
DoubleToString(g_plannedEntryPrice, _Digits), entryDiffPts, outDisplayVol, outRecommendedLot);
}
else if(InpSplitSetupRiskAcrossOrders && (w1 < 0.999))
{
entryTagTxt = StringFormat("ENTRY KẾ HOẠCH %s (Khung %s cố định) | TỔNG GỢI Ý: %.2f LOT (%.2f%%) [Chia lệnh: %.2f | %.2f | %.2f] ",
DoubleToString(g_sizerEntryPrice, _Digits), tfLockStr, outRecommendedLot, activeRiskPct,
g_leg1SuggestedLot, g_leg2SuggestedLot, g_leg3SuggestedLot);
}
else
{
entryTagTxt = StringFormat("ENTRY KẾ HOẠCH %s (Khung %s cố định) | GỢI Ý: %.2f LOT (Risk %.2f%%) ",
DoubleToString(g_sizerEntryPrice, _Digits), tfLockStr, outRecommendedLot, activeRiskPct);
}

string riskTag = "";
if(openOrderCount > 0)
{
riskTag = outRiskKnown
? StringFormat("Risk thực tế (%.2f Lot): -$%.2f (%.2f%% / Mục tiêu %.2f%%)", outDisplayVol, outDisplayRiskCash, outDisplayRiskPct, activeRiskPct)
: "Risk chưa xác định (kiểm tra SL / dữ liệu broker)";
}
else
{
riskTag = outRiskKnown
? StringFormat("Risk dự kiến (%.2f Lot): -$%.2f (%.2f%%)", outDisplayVol, outDisplayRiskCash, outDisplayRiskPct)
: "Risk chưa xác định (kiểm tra SL / dữ liệu broker)";
}
string slTagTxt = StringFormat("STOP LOSS %s (%.0f pts) | %s ",
DoubleToString(g_sizerSlPrice, _Digits), outSlPoints, riskTag);

string tpModeNote = (openOrderCount > 0 && g_hardTpSuppressedForPartial)
? StringFormat("MỤC TIÊU TP1 [CẮT %.0f%% & TRAIL - GỠ HARD TP SÀN]", g_partialPct)
: "TAKE PROFIT";
string tpTagTxt = StringFormat("%s %s (Thực tế 1:%.2fR) | Kỳ vọng (%.2f Lot): +$%.2f ",
tpModeNote, DoubleToString(g_sizerTpPrice, _Digits), actualRR, outDisplayVol, outDisplayRewardCash);

DrawSizerTag("T_ENTRY", tRight, g_sizerEntryPrice, entryTagTxt, clrDodgerBlue, ANCHOR_RIGHT_LOWER, g_showSizer);
DrawSizerTag("T_SL", tRight, g_sizerSlPrice, slTagTxt, clrTomato, ANCHOR_RIGHT_LOWER, g_showSizer);
DrawSizerTag("T_TP", tRight, g_sizerTpPrice, tpTagTxt, clrLime, ANCHOR_RIGHT_LOWER, g_showSizer);
}

void CloseAllTradesAndOrders(string reason, bool accountWide = true)
{
int attempted = 0, failed = 0;
for(int i = PositionsTotal() - 1; i >= 0; i--)
{
ulong ticket = PositionGetTicket(i);
if(ticket == 0 || (!accountWide && PositionGetString(POSITION_SYMBOL) != _Symbol))
continue;
attempted++;
if(!ClosePositionWithConfirmation(ticket))
failed++;
}
for(int j = OrdersTotal() - 1; j >= 0; j--)
{
ulong ordTicket = OrderGetTicket(j);
if(ordTicket == 0 || (!accountWide && OrderGetString(ORDER_SYMBOL) != _Symbol))
continue;
attempted++;
if(!DeleteOrderWithConfirmation(ordTicket))
failed++;
}
if(attempted > 0 && failed > 0)
{
datetime now = TimeLocal();
if(g_lastBulkCloseWarning == 0 || now - g_lastBulkCloseWarning >= 60)
{
Print("EA PRO v8.5 [ĐÓNG LỆNH] ", accountWide ? "toàn tài khoản" : _Symbol, ": ", reason,
" | yêu cầu=", attempted, " | chưa xác nhận=", failed, " | sẽ tiếp tục thử lại.");
g_lastBulkCloseWarning = now;
}
}
}

bool HasTradesInScope(bool accountWide)
{
for(int i = PositionsTotal() - 1; i >= 0; i--)
{
ulong ticket = PositionGetTicket(i);
if(ticket > 0 && (accountWide || PositionGetString(POSITION_SYMBOL) == _Symbol))
return true;
}
for(int j = OrdersTotal() - 1; j >= 0; j--)
{
ulong ticket = OrderGetTicket(j);
if(ticket > 0 && (accountWide || OrderGetString(ORDER_SYMBOL) == _Symbol))
return true;
}
return false;
}

int CountPositionsInScope(bool accountWide)
{
int count = 0;
for(int i = PositionsTotal() - 1; i >= 0; i--)
{
ulong ticket = PositionGetTicket(i);
if(ticket > 0 && (accountWide || PositionGetString(POSITION_SYMBOL) == _Symbol))
count++;
}
return count;
}

void UpdateAccountSwitchHoldDisplay(double dayPct, double weekPct, double monthPct)
{
string dataText = g_accountHoldRiskDataReady ? "DỮ LIỆU RISK ĐÃ TẢI" : "ĐANG TẢI LỊCH SỬ RISK";
string hud = StringFormat("CẦN XÁC NHẬN TÀI KHOẢN/LỆNH — EA TẠM DỪNG | %s | N:%.1f%% T:%.1f%% Th:%.1f%%",
dataText, dayPct, weekPct, monthPct);
if(ObjectFind(0, PREFIX + "Hud_Line1") >= 0)
{
ObjectSetString(0, PREFIX + "Hud_Line1", OBJPROP_TEXT, hud);
ObjectSetInteger(0, PREFIX + "Hud_Line1", OBJPROP_COLOR, clrOrangeRed);
}
if(ObjectFind(0, PREFIX + "Btn_ForceLock") >= 0)
{
ObjectSetString(0, PREFIX + "Btn_ForceLock", OBJPROP_TEXT,
g_accountHoldRiskDataReady ? "XÁC NHẬN TK" : "CHỜ DỮ LIỆU");
ObjectSetInteger(0, PREFIX + "Btn_ForceLock", OBJPROP_BGCOLOR,
g_accountHoldRiskDataReady ? C_BTN_ACT : C_BTN_LOCK);
}
if(ObjectFind(0, PREFIX + "Hud_Line2R") >= 0)
ObjectSetString(0, PREFIX + "Hud_Line2R", OBJPROP_TEXT, "Kiểm tra vị thế, SL/TP trước khi xác nhận tiếp tục.");
if(ObjectFind(0, PREFIX + "Hud_Line3R") >= 0)
ObjectSetString(0, PREFIX + "Hud_Line3R", OBJPROP_TEXT, "EA không gửi lệnh khi đang tạm dừng.");
ChartRedraw(0);
}

//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
void ProcessCoreLogic()
{
double dayPnl, dayPct, weekPnl, weekPct, monthPnl, monthPct;
CalculateDayWeekMonthPnl(dayPnl, dayPct, weekPnl, weekPct, monthPnl, monthPct);

if(g_accountSwitchHold)
{
g_accountHoldRiskDataReady = g_riskDataAvailable;
UpdateAccountSwitchHoldDisplay(dayPct, weekPct, monthPct);
return;
}

bool accountWideRiskAction = g_manualForceLock || (InpRiskControlScope == SCOPE_ACCOUNT);
if((g_riskBreached || g_manualForceLock) && HasTradesInScope(accountWideRiskAction))
{
string msg = g_manualForceLock ? "Đang bật khóa thủ công" : g_breachReason;
CloseAllTradesAndOrders(msg, accountWideRiskAction);
if(!g_riskCloseNoticeShown)
{
Alert("EA RISK GUARD: Đã gửi yêu cầu đóng lệnh trong phạm vi bảo vệ. Lý do: ", msg);
g_riskCloseNoticeShown = true;
}
}
else if(!g_riskBreached && !g_manualForceLock)
g_riskCloseNoticeShown = false;

if(g_inRecoveryMode && g_enHalfRiskRec && CountPositionsInScope(InpRiskControlScope == SCOPE_ACCOUNT) > g_maxRecOrders)
{
ulong newestTicket = 0;
datetime newestTime = 0;
for(int k = PositionsTotal() - 1; k >= 0; k--)
{
ulong tk = PositionGetTicket(k);
if(tk > 0 && (InpRiskControlScope == SCOPE_ACCOUNT || PositionGetString(POSITION_SYMBOL) == _Symbol))
{
datetime tOpen = (datetime)PositionGetInteger(POSITION_TIME);
if(tOpen >= newestTime)
{ newestTime = tOpen; newestTicket = tk; }
}
}
if(newestTicket > 0)
{
if(ClosePositionWithConfirmation(newestTicket))
Alert("CHẾ ĐỘ PHỤC HỒI: Chỉ cho phép mở tối đa ", g_maxRecOrders, " lệnh! Đã đóng lệnh nhồi thêm #", newestTicket);
}
}

datetime newsWinStart = 0, newsWinEnd = 0;
g_newsLockedState = CheckNewsScheduleAndLock(newsWinStart, newsWinEnd);
if(g_enNewsFilter && g_newsLockedState)
{
for(int j = OrdersTotal() - 1; j >= 0; j--)
{
ulong ord = OrderGetTicket(j);
if(ord > 0 && (InpNewsFilterScope == SCOPE_ACCOUNT || OrderGetString(ORDER_SYMBOL) == _Symbol))
DeleteOrderWithConfirmation(ord);
}
for(int i = PositionsTotal() - 1; i >= 0; i--)
{
ulong t = PositionGetTicket(i);
if(t > 0 && (InpNewsFilterScope == SCOPE_ACCOUNT || PositionGetString(POSITION_SYMBOL) == _Symbol))
{
datetime posOpenTime = (datetime)PositionGetInteger(POSITION_TIME);
if(newsWinStart > 0 && posOpenTime >= newsWinStart && posOpenTime <= newsWinEnd)
{
if(ClosePositionWithConfirmation(t))
Alert("CẤM TRADE TRONG GIỜ TIN! Đã đóng lệnh mở trong khung cấm tin #", t);
}
}
}
}

double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
int buyCount = 0, sellCount = 0;
double buyVolSum = 0.0, sellVolSum = 0.0;
double buyPriceVolSum = 0.0, sellPriceVolSum = 0.0;
double buyPlanVolSum = 0.0, sellPlanVolSum = 0.0;
datetime earliestOpenTime = 0;
long anchorPosId = 0;
double repSL = 0.0, repTP = 0.0, netFloatingPnl = 0.0;

for(int i = PositionsTotal() - 1; i >= 0; i--)
{
ulong ticket = PositionGetTicket(i);
if(ticket == 0 || PositionGetString(POSITION_SYMBOL) != _Symbol)
continue;

double actualEntry = PositionGetDouble(POSITION_PRICE_OPEN);
double vol = PositionGetDouble(POSITION_VOLUME);
double sl = PositionGetDouble(POSITION_SL);
double tp = PositionGetDouble(POSITION_TP);
datetime oTime = (datetime)PositionGetInteger(POSITION_TIME);
long pId = PositionGetInteger(POSITION_IDENTIFIER);
double plannedEntry = GetFrozenClosedEntryPrice(pId, oTime, actualEntry);
bool isBuyPos = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY);

netFloatingPnl += PositionGetDouble(POSITION_PROFIT) + PositionGetDouble(POSITION_SWAP);
if(earliestOpenTime == 0 || oTime < earliestOpenTime)
{
earliestOpenTime = oTime;
anchorPosId = pId;
}
if(sl > 0.0) repSL = sl;
if(tp > 0.0) repTP = tp;

// 1. Tách rõ "Entry kế hoạch" (plannedEntry) và "Giá khớp thực tế" (actualEntry = POSITION_PRICE_OPEN)
// Tính vwapEntry theo GIÁ KHỚP THỰC TẾ để toàn bộ SL, TP, Rủi ro ($) và tỷ lệ R phản ánh đúng vị thế thật trên MT5
if(isBuyPos)
{
buyCount++;
buyVolSum += vol;
buyPriceVolSum += actualEntry * vol;
buyPlanVolSum += plannedEntry * vol;
}
else
{
sellCount++;
sellVolSum += vol;
sellPriceVolSum += actualEntry * vol;
sellPlanVolSum += plannedEntry * vol;
}
}

int openCount = buyCount + sellCount;
if(g_prevOpenCountForSetup > 0 && openCount == 0)
{
// Khi toàn bộ vị thế trên biểu đồ vừa đóng hết: giữ khung hiện tại làm mốc khóa cho setup mới
g_hardTpSuppressedForPartial = false;
}
g_prevOpenCountForSetup = openCount;

g_mixedPositionFallback = (buyVolSum > 1e-8 && sellVolSum > 1e-8);
if(g_multiMode == MULTI_BASKET_VWAP && g_mixedPositionFallback)
{
if(!g_mixedModeWarningShown)
Alert("ĐANG CÓ CẢ BUY VÀ SELL: EA tạm chuyển sang quản lý từng lệnh để tránh gộp sai VWAP.");
g_mixedModeWarningShown = true;
}
else
g_mixedModeWarningShown = false;
ENUM_MULTI_ORDER_MODE activeMultiMode = (g_multiMode == MULTI_BASKET_VWAP && g_mixedPositionFallback) ? MULTI_INDIVIDUAL : g_multiMode;
bool basketIsLong = (buyVolSum >= sellVolSum);
double totalOpenVol = basketIsLong ? buyVolSum : sellVolSum;
double vwapEntry = (totalOpenVol > 0.0) ? ((basketIsLong ? buyPriceVolSum : sellPriceVolSum) / totalOpenVol) : 0.0;
double plannedVwapEntry = (totalOpenVol > 0.0) ? ((basketIsLong ? buyPlanVolSum : sellPlanVolSum) / totalOpenVol) : 0.0;
if(openCount > 0)
{
g_actualFillEntryPrice = vwapEntry;
g_plannedEntryPrice = (plannedVwapEntry > 0.0) ? plannedVwapEntry : vwapEntry;
}
double currentR = 0.0;


DrawOrderPinsAndTradingJournal(openCount, vwapEntry, basketIsLong);

if(openCount > 0 && totalOpenVol > 0.0)
{
ENUM_TRADE_SIDE activeSide = basketIsLong ? SIDE_LONG : SIDE_SHORT;
double curActualSlDist = (repSL > 0.0) ? MathAbs(vwapEntry - repSL) : 0.0;

g_resolvedAtrTf = ResolveActiveAtrTimeframe(openCount, anchorPosId, earliestOpenTime, curActualSlDist);
SyncAnchorDateFields(g_resolvedAtrTf, earliestOpenTime);

bool trailDataReady = false;
double rawTrail = ExecuteExactPineScriptFormula(g_resolvedAtrTf, earliestOpenTime, vwapEntry, activeSide, g_showAtrPlot && activeMultiMode == MULTI_BASKET_VWAP, false,
g_pineEntryLevel, g_pineFirstBarSlDist, g_pineStopPlotting, g_pineStartCalc, trailDataReady);

string gvBestTrail = AccountScopedGV("EAP82_BSK_BESTTRAIL_" + IntegerToString(anchorPosId));
string gvBestTrailStopped = gvBestTrail + "_STOP";
if(!trailDataReady)
{
bool cachedTrailState = GlobalVariableCheck(gvBestTrailStopped);
rawTrail = (cachedTrailState && GlobalVariableCheck(gvBestTrail)) ? GlobalVariableGet(gvBestTrail) : 0.0;
g_pineStopPlotting = cachedTrailState ? (GlobalVariableGet(gvBestTrailStopped) > 0.5) : true;
g_pineEntryLevel = vwapEntry;
g_pineFirstBarSlDist = curActualSlDist;
}
else
GlobalVariableSet(gvBestTrailStopped, g_pineStopPlotting ? 1.0 : 0.0);
if(trailDataReady && rawTrail > 0.0 && !g_pineStopPlotting)
{
if(GlobalVariableCheck(gvBestTrail))
{
double prevBest = GlobalVariableGet(gvBestTrail);
if(prevBest > 0.0)
rawTrail = basketIsLong ? MathMax(rawTrail, prevBest) : MathMin(rawTrail, prevBest);
}
GlobalVariableSet(gvBestTrail, rawTrail);
}
g_pineTrailingStop = rawTrail;

if(!g_showAtrPlot)
ObjectsDeleteAll(0, VIS_PREFIX + "ATRLINE_");

double slDistCalc, slPtsCalc, recLot, dispVol, dispRiskCash, dispRiskPct, dispRewardCash, partLot, remLot;
bool riskKnown = true;
CalculateSizingAndActiveRules(openCount, totalOpenVol, vwapEntry, repSL, repTP, basketIsLong, anchorPosId, earliestOpenTime,
slDistCalc, slPtsCalc, recLot, dispVol, dispRiskCash, dispRiskPct, riskKnown, dispRewardCash, partLot, remLot);

double prevBarClose = iClose(_Symbol, g_resolvedAtrTf, 1);
datetime prevBarTime = iTime(_Symbol, g_resolvedAtrTf, 1);

if(activeMultiMode == MULTI_BASKET_VWAP)
{
string gvBasket1R = AccountScopedGV("EAP82_BSK_1R_" + IntegerToString(anchorPosId));
string gvBasketArmed = AccountScopedGV("EAP82_BSK_ARMED_" + IntegerToString(anchorPosId));
string gvBasketArmBar = AccountScopedGV("EAP82_BSK_ARMBAR_" + IntegerToString(anchorPosId));
string gvBasketCnt = AccountScopedGV("EAP82_BSK_CNT_" + IntegerToString(anchorPosId));
string gvBasketTier2 = AccountScopedGV("EAP82_BSK_TIER2_" + IntegerToString(anchorPosId));
string gvBasketT2Time = AccountScopedGV("EAP82_BSK_T2TIME_" + IntegerToString(anchorPosId));
string gvLockedInitSL = AccountScopedGV("EAP82_BSK_INITSL_" + IntegerToString(anchorPosId));
string gvLockedInitTP = AccountScopedGV("EAP82_BSK_INITTP_" + IntegerToString(anchorPosId));

int savedCnt = GlobalVariableCheck(gvBasketCnt) ? (int)GlobalVariableGet(gvBasketCnt) : 0;
double basket1R = GlobalVariableCheck(gvBasket1R) ? GlobalVariableGet(gvBasket1R) : 0.0;

bool isNewOrderAdded = (openCount > savedCnt);
bool slStillInRiskZone = (repSL > 0.0) && ((basketIsLong && repSL < vwapEntry - _Point) || (!basketIsLong && repSL > vwapEntry + _Point));

if(basket1R <= 0.0 || isNewOrderAdded || (slStillInRiskZone && !g_isTrailingArmedNow))
{
basket1R = slStillInRiskZone ? MathAbs(vwapEntry - repSL)
: ((slDistCalc > 0.0) ? slDistCalc : ((g_pineFirstBarSlDist > 0.0) ? g_pineFirstBarSlDist : (g_pineLatestAtr * g_customValueForFirstDay)));
double lockSL = (repSL > 0.0) ? repSL : (basketIsLong ? NormalizeDouble(vwapEntry - basket1R, _Digits) : NormalizeDouble(vwapEntry + basket1R, _Digits));
double lockTP = (repTP > 0.0) ? repTP : (basketIsLong ? NormalizeDouble(vwapEntry + basket1R * g_targetRR, _Digits) : NormalizeDouble(vwapEntry - basket1R * g_targetRR, _Digits));

GlobalVariableSet(gvBasket1R, basket1R);
GlobalVariableSet(gvLockedInitSL, lockSL);
GlobalVariableSet(gvLockedInitTP, lockTP);
GlobalVariableSet(gvBasketCnt, (double)openCount);
}
else if(openCount < savedCnt)
{
GlobalVariableSet(gvBasketCnt, (double)openCount);
}

double unifiedInitSL = GlobalVariableCheck(gvLockedInitSL) ? GlobalVariableGet(gvLockedInitSL)
: (basketIsLong ? NormalizeDouble(vwapEntry - basket1R, _Digits) : NormalizeDouble(vwapEntry + basket1R, _Digits));
double unifiedInitTP = GlobalVariableCheck(gvLockedInitTP) ? GlobalVariableGet(gvLockedInitTP)
: (basketIsLong ? NormalizeDouble(vwapEntry + basket1R * g_targetRR, _Digits) : NormalizeDouble(vwapEntry - basket1R * g_targetRR, _Digits));

// 5. Kiểm tra độ lệch giữa Giá khớp thực tế và Entry kế hoạch + Kiểm tra vượt ngân sách rủi ro sau khi khớp
double equityNow = GetEffectiveEquity();
double targetRiskBudgetCash = equityNow * (GetActiveRiskPercent() / 100.0);
double adverseSlip = basketIsLong ? (vwapEntry - g_plannedEntryPrice) : (g_plannedEntryPrice - vwapEntry);
double planned1RRef = (g_standbyLocked1R > 0.0) ? g_standbyLocked1R : basket1R;

if(InpRejectMaxSlippagePctOf1R > 0.0 && planned1RRef > _Point && adverseSlip > 0.0)
{
double slipPct1R = (adverseSlip / planned1RRef) * 100.0;
if(slipPct1R > InpRejectMaxSlippagePctOf1R)
{
CloseAllPositionsOnChartSymbol();
AlertThrottled("REJECT_SLIP_" + IntegerToString(anchorPosId),
StringFormat("TỪ CHỐI LỆNH [%s]: Giá khớp thực tế (%s) trượt xấu %.1f%% 1R so với Entry kế hoạch (%s) > ngưỡng %.1f%%! Đã đóng lệnh bảo vệ.",
_Symbol, DoubleToString(vwapEntry, _Digits), slipPct1R, DoubleToString(g_plannedEntryPrice, _Digits), InpRejectMaxSlippagePctOf1R), 30);
return;
}
}

string gvSlipChecked = AccountScopedGV("EAP85_SLIPCHK_" + IntegerToString(anchorPosId) + "_" + IntegerToString(openCount));
if(!GlobalVariableCheck(gvSlipChecked))
{
bool needRecalcLevels = false;
if(InpRecalcSlTpOnFillDeviation && MathAbs(vwapEntry - g_plannedEntryPrice) >= _Point)
{
// Nếu TP hiện tại đang neo theo Entry kế hoạch làm lệch tỷ lệ R thực tế (như 1.09R hoặc 0.16R), đồng bộ lại TP theo Giá khớp thực tế
double currentSlRef = (repSL > 0.0) ? repSL : unifiedInitSL;
double actual1RNow = MathAbs(vwapEntry - currentSlRef);
if(actual1RNow > _Point)
{
basket1R = actual1RNow;
unifiedInitSL = currentSlRef;
unifiedInitTP = basketIsLong ? NormalizeDouble(vwapEntry + basket1R * g_targetRR, _Digits)
: NormalizeDouble(vwapEntry - basket1R * g_targetRR, _Digits);
GlobalVariableSet(gvBasket1R, basket1R);
GlobalVariableSet(gvLockedInitSL, unifiedInitSL);
GlobalVariableSet(gvLockedInitTP, unifiedInitTP);
needRecalcLevels = true;
}
}

if(riskKnown && targetRiskBudgetCash > 0.0 && dispRiskCash > targetRiskBudgetCash * (1.0 + InpMaxRiskOverrunWarnPct / 100.0))
{
AlertThrottled("RISK_OVERRUN_" + IntegerToString(anchorPosId),
StringFormat("CẢNH BÁO RỦI RO SAU KHỚP [%s]: Khớp %.2f Lot @ %s (Entry KH: %s) có Risk thực tế -$%.2f (%.2f%%) vượt ngân sách mục tiêu -$%.2f (%.2f%%)!",
_Symbol, totalOpenVol, DoubleToString(vwapEntry, _Digits), DoubleToString(g_plannedEntryPrice, _Digits),
dispRiskCash, dispRiskPct, targetRiskBudgetCash, GetActiveRiskPercent()), 45);

if(g_volRule == RULE_SCALE_DIST_BY_VOL && !g_isTrailingArmedNow)
{
double safeDist = FindStopDistanceForRiskBudget(_Symbol, basketIsLong, vwapEntry,
targetRiskBudgetCash / totalOpenVol, g_bufferPts, g_commPerLot);
if(safeDist > _Point)
{
basket1R = safeDist;
unifiedInitSL = basketIsLong ? NormalizeDouble(vwapEntry - basket1R, _Digits) : NormalizeDouble(vwapEntry + basket1R, _Digits);
unifiedInitTP = basketIsLong ? NormalizeDouble(vwapEntry + basket1R * g_targetRR, _Digits) : NormalizeDouble(vwapEntry - basket1R * g_targetRR, _Digits);
GlobalVariableSet(gvBasket1R, basket1R);
GlobalVariableSet(gvLockedInitSL, unifiedInitSL);
GlobalVariableSet(gvLockedInitTP, unifiedInitTP);
needRecalcLevels = true;
}
}
}

if(needRecalcLevels)
{
for(int m = PositionsTotal() - 1; m >= 0; m--)
{
ulong tkMod = PositionGetTicket(m);
if(tkMod > 0 && PositionGetString(POSITION_SYMBOL) == _Symbol)
{
long pidMod = PositionGetInteger(POSITION_IDENTIFIER);
GlobalVariableDel(AccountScopedGV("EAP82_INITDONE_" + IntegerToString(pidMod)));
}
}
}
GlobalVariableSet(gvSlipChecked, 1.0);
}

g_hardTpSuppressedForPartial = false;
double buffer20Pct1R = basket1R * (g_tierPctOf1R / 100.0);
double activeWickBuffer = (g_sweepMode == SWEEP_HARD_SL_ON_LINE) ? 0.0 : buffer20Pct1R;

double livePrice = basketIsLong ? bid : ask;
double profitDist = basketIsLong ? (livePrice - vwapEntry) : (vwapEntry - livePrice);
currentR = (basket1R > 0.0) ? (profitDist / basket1R) : 0.0;
datetime curTfBar0 = iTime(_Symbol, g_resolvedAtrTf, 0);


for(int i = PositionsTotal() - 1; i >= 0; i--)
{
ulong ticket = PositionGetTicket(i);
if(ticket == 0 || PositionGetString(POSITION_SYMBOL) != _Symbol)
continue;
bool isLong = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY);
if(isLong != basketIsLong)
continue;

long posId = PositionGetInteger(POSITION_IDENTIFIER);
double curSL = PositionGetDouble(POSITION_SL);
double curTP = PositionGetDouble(POSITION_TP);
double curVol = PositionGetDouble(POSITION_VOLUME);
string gvPart = AccountScopedGV("EAP82_PART_" + IntegerToString(posId));
string gvInitDone = AccountScopedGV("EAP82_INITDONE_" + IntegerToString(posId));
bool partialHistoryReady = PreparePositionPartialState(posId, gvPart);
bool partAlreadyDone = GlobalVariableCheck(gvPart);

// 8. Kiểm tra xung đột giữa chế độ "chạm 2R cắt 50% & Trail/BE" với Hard TP đặt trên máy chủ ở mức <= 2R
double candidateTP = (curTP > 0.0 && !isNewOrderAdded) ? curTP : unifiedInitTP;
bool removeHardTpAtPartial = ShouldSuppressBrokerHardTpForPartial(curVol, partAlreadyDone, vwapEntry, (curSL > 0.0 ? curSL : unifiedInitSL), candidateTP, isLong);
if(removeHardTpAtPartial)
g_hardTpSuppressedForPartial = true;

if(g_autoSlTp && (!GlobalVariableCheck(gvInitDone) || isNewOrderAdded))
{
double targetInitSL = (curSL <= 0.0 || isNewOrderAdded) ? unifiedInitSL : curSL;
double targetInitTP = removeHardTpAtPartial ? 0.0 : ((curTP <= 0.0 || isNewOrderAdded || InpRecalcSlTpOnFillDeviation) ? unifiedInitTP : curTP);
bool levelsReady = (MathAbs(curSL - targetInitSL) < _Point && MathAbs(curTP - targetInitTP) < _Point);
if(!levelsReady && ModifyPositionWithConfirmation(ticket, targetInitSL, targetInitTP))
{
curSL = targetInitSL;
curTP = targetInitTP;
repSL = curSL;
repTP = curTP;
levelsReady = true;
}
if(levelsReady)
GlobalVariableSet(gvInitDone, 1.0);
else
Print("EA PRO: Could not attach initial SL/TP; will retry for position #", ticket);
}
if(removeHardTpAtPartial && curTP > 0.0)
{
if(ModifyPositionWithConfirmation(ticket, curSL, 0.0))
{
curTP = 0.0;
repTP = 0.0;
AlertThrottled("HARDTP_CONFLICT_REMOVED_" + IntegerToString(posId),
StringFormat("CHỐNG XUNG ĐỘT TP1 & TRAIL [#%I64u]: Đã gỡ Hard TP trên máy chủ trùng mức cắt %.0f%% (%.1fR) để tránh đóng 100%% vị thế trước khi cắt một nửa & bật Trailing.",
ticket, g_partialPct, g_partialRR), 120);
}
}

string gvPartRetry = AccountScopedGV("EAP82_PARTTRY_" + IntegerToString(posId));
string gvPartTarget = AccountScopedGV("EAP82_PARTTARGET_" + IntegerToString(posId));
string gvPartClosed = AccountScopedGV("EAP82_PARTCLOSED_" + IntegerToString(posId));
if(g_enPartial && partialHistoryReady && !GlobalVariableCheck(gvPart) && currentR >= g_partialRR)
{
datetime now = TimeCurrent();
datetime lastTry = GlobalVariableCheck(gvPartRetry) ? (datetime)GlobalVariableGet(gvPartRetry) : 0;
if(lastTry == 0 || now - lastTry >= 3)
{
GlobalVariableSet(gvPartRetry, (double)now);
double minLot = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
double lotStep = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);
if(lotStep <= 0.0) lotStep = 0.01;
double targetClose = GlobalVariableCheck(gvPartTarget) ? GlobalVariableGet(gvPartTarget) : FloorLotStep(curVol * (g_partialPct / 100.0));
if(!GlobalVariableCheck(gvPartTarget) && targetClose >= minLot && (curVol - targetClose) >= minLot - 1e-6)
GlobalVariableSet(gvPartTarget, targetClose);
double closedSoFar = GlobalVariableCheck(gvPartClosed) ? GlobalVariableGet(gvPartClosed) : 0.0;
double remainingToClose = targetClose - closedSoFar;
if(targetClose >= minLot && remainingToClose >= minLot && remainingToClose <= curVol - minLot + 1e-6)
{
double actualClosed = 0.0;
if(ClosePositionPartiallyByTicket(ticket, remainingToClose, actualClosed))
{
closedSoFar += actualClosed;
GlobalVariableSet(gvPartClosed, closedSoFar);
if(closedSoFar + lotStep * 0.5 >= targetClose)
{
GlobalVariableSet(gvPart, 1.0);
GlobalVariableDel(gvPartRetry);
GlobalVariableDel(AccountScopedGV("EAP82_PARTWARN_" + IntegerToString(posId)));
}
else
ReportPartialTPIssue(posId, StringFormat("Đã chốt %.2f/%.2f lot TP1; EA sẽ thử tiếp phần còn thiếu.", closedSoFar, targetClose));
}
else
ReportPartialTPIssue(posId, "Yêu cầu chốt một phần chưa được xác nhận; EA sẽ thử lại sau 3 giây.");
}
else
ReportPartialTPIssue(posId, StringFormat("Không thể chốt đủ %.2f lot TP1 từ khối lượng hiện tại %.2f theo min lot/bước lot; TP1 chưa được đánh dấu hoàn tất.", targetClose, curVol));
}
}

// Remove any remaining TP at the 2R trigger after attempting the partial close.
if(g_enPartial && currentR >= g_partialRR && curTP > 0.0 && GlobalVariableCheck(gvPart))
{
if(ModifyPositionWithConfirmation(ticket, curSL, 0.0))
{ curTP = 0.0; repTP = 0.0; }
}
}


bool wasArmed = GlobalVariableCheck(gvBasketArmed) ? (GlobalVariableGet(gvBasketArmed) > 0.5) : false;
datetime armedBarTime = GlobalVariableCheck(gvBasketArmBar) ? (datetime)GlobalVariableGet(gvBasketArmBar) : 0;
bool justArmedNow = false;

if(currentR >= g_trailStartRR)
{
if(!wasArmed)
{
wasArmed = true;
justArmedNow = true;
armedBarTime = curTfBar0;
GlobalVariableSet(gvBasketArmed, 1.0);
GlobalVariableSet(gvBasketArmBar, (double)armedBarTime);
}
}
g_isTrailingArmedNow = wasArmed;


bool allowTrailStepNow = (g_isTrailingArmedNow && !justArmedNow && (armedBarTime == 0 || curTfBar0 > armedBarTime));

if(g_enTrail && g_trailStyle == TRAIL_STYLE_AUTO_ATR && allowTrailStepNow && g_pineTrailingStop > 0.0)
{
double tier3HardPrice = basketIsLong ? (g_pineTrailingStop - activeWickBuffer)
: (g_pineTrailingStop + activeWickBuffer);
if(g_enLock && currentR >= g_lockTrigRR)
{
double lockDist = basket1R * g_lockLvlRR;
double minLockProfitPrc = basketIsLong ? (vwapEntry + lockDist) : (vwapEntry - lockDist);
tier3HardPrice = basketIsLong ? MathMax(minLockProfitPrc, tier3HardPrice)
: MathMin(minLockProfitPrc, tier3HardPrice);
}

bool piercedTier3Realtime = (basketIsLong && livePrice <= tier3HardPrice) ||
(!basketIsLong && livePrice >= tier3HardPrice);

if(piercedTier3Realtime)
{
bool allSymbolPositionsClosed = CloseAllPositionsOnChartSymbol();
if(allSymbolPositionsClosed)
AlertThrottled("T3_SL_DONE", StringFormat("T3 (SL LUÔN): Giá xuyên thủng 3 tầng -> đã đóng toàn bộ vị thế trên %s.", _Symbol));
else
AlertThrottled("T3_SL_RETRY", StringFormat("T3 (SL LUÔN): Một số vị thế trên %s chưa đóng được; EA sẽ tiếp tục giám sát.", _Symbol));
return;
}

if(prevBarTime > earliestOpenTime && (armedBarTime == 0 || prevBarTime > armedBarTime))
{
bool closedBeyondTier1 = (basketIsLong && prevBarClose < g_pineTrailingStop) ||
(!basketIsLong && prevBarClose > g_pineTrailingStop);
bool closedBeyondTier3 = (basketIsLong && prevBarClose <= tier3HardPrice) ||
(!basketIsLong && prevBarClose >= tier3HardPrice);

if(g_sweepMode == SWEEP_3LAYER_20PCT_1R)
{
bool alreadyCutTier2 = GlobalVariableCheck(gvBasketTier2);
datetime lastT2Bar = GlobalVariableCheck(gvBasketT2Time) ? (datetime)GlobalVariableGet(gvBasketT2Time) : 0;

if(closedBeyondTier3)
{
bool allSymbolPositionsClosed = CloseAllPositionsOnChartSymbol();
if(allSymbolPositionsClosed)
AlertThrottled("T3_CLOSE_DONE", "T3: Nến đóng cửa xuyên thủng biên 20% của 1R -> đã đóng hết vị thế.");
else
AlertThrottled("T3_CLOSE_RETRY", "T3: Một số vị thế chưa đóng được; EA sẽ tiếp tục giám sát.");
return;
}
else if(closedBeyondTier1)
{
if(!alreadyCutTier2)
{
bool allTier2Done = true;
bool foundTier2Position = false;
for(int c = PositionsTotal() - 1; c >= 0; c--)
{
ulong tk = PositionGetTicket(c);
if(tk == 0 || PositionGetString(POSITION_SYMBOL) != _Symbol)
continue;
foundTier2Position = true;
long tier2PosId = PositionGetInteger(POSITION_IDENTIFIER);
string gvPosDone = AccountScopedGV("EAP82_BSK_T2POS_" + IntegerToString(tier2PosId));
if(GlobalVariableCheck(gvPosDone))
continue;
string gvAlreadyReduced = AccountScopedGV("EAP82_PART_" + IntegerToString(tier2PosId));
if(GlobalVariableCheck(gvAlreadyReduced))
{
GlobalVariableSet(gvPosDone, 1.0);
continue;
}
string gvTry = AccountScopedGV("EAP82_BSK_T2TRY_" + IntegerToString(tier2PosId));
datetime now = TimeCurrent();
datetime lastTry = GlobalVariableCheck(gvTry) ? (datetime)GlobalVariableGet(gvTry) : 0;
if(lastTry > 0 && now - lastTry < 3)
{ allTier2Done = false; continue; }
GlobalVariableSet(gvTry, (double)now);
double vol = PositionGetDouble(POSITION_VOLUME);
double minLot = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
double lotStep = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);
if(lotStep <= 0.0) lotStep = 0.01;
string gvTarget = AccountScopedGV("EAP82_BSK_T2TARGET_" + IntegerToString(tier2PosId));
string gvClosed = AccountScopedGV("EAP82_BSK_T2CLOSED_" + IntegerToString(tier2PosId));
double targetClose = GlobalVariableCheck(gvTarget) ? GlobalVariableGet(gvTarget) : FloorLotStep(vol * 0.5);
if(!GlobalVariableCheck(gvTarget) && targetClose >= minLot && vol - targetClose >= minLot - 1e-6)
GlobalVariableSet(gvTarget, targetClose);
double closedSoFar = GlobalVariableCheck(gvClosed) ? GlobalVariableGet(gvClosed) : 0.0;
double remaining = targetClose - closedSoFar;
if(targetClose < minLot || remaining < minLot || remaining > vol - minLot + 1e-6)
{
allTier2Done = false;
ReportPartialTPIssue(tier2PosId, StringFormat("T2 không thể chia 50%% khối lượng %.2f theo min lot/bước lot của sàn.", vol));
continue;
}
double actualClosed = 0.0;
if(!ClosePositionPartiallyByTicket(tk, remaining, actualClosed))
{
allTier2Done = false;
ReportPartialTPIssue(tier2PosId, "T2 chưa được máy chủ xác nhận; EA sẽ thử lại.");
continue;
}
closedSoFar += actualClosed;
GlobalVariableSet(gvClosed, closedSoFar);
if(closedSoFar + lotStep * 0.5 >= targetClose)
{
GlobalVariableSet(gvPosDone, 1.0);
GlobalVariableSet(gvAlreadyReduced, 1.0);
GlobalVariableDel(gvTry);
GlobalVariableDel(AccountScopedGV("EAP82_PARTWARN_" + IntegerToString(tier2PosId)));
}
else
{
allTier2Done = false;
ReportPartialTPIssue(tier2PosId, StringFormat("T2 đã cắt %.2f/%.2f lot; EA sẽ thử tiếp phần còn thiếu.", closedSoFar, targetClose));
}
}
if(allTier2Done && foundTier2Position)
{
GlobalVariableSet(gvBasketTier2, prevBarClose);
GlobalVariableSet(gvBasketT2Time, (double)prevBarTime);
Alert(StringFormat("T2: Nến %s đóng cửa, không rút râu nhưng chưa vi phạm %.0f%% 1R -> đã cắt đủ 50%% vị thế.", GetTfShortName(g_resolvedAtrTf), g_tierPctOf1R));
}
}

// Once T2 has completed, monitor later ATR closes independently of the one-time partial-cut branch.
if(GlobalVariableCheck(gvBasketTier2) && prevBarTime > lastT2Bar)
{
double t2RefClose = GlobalVariableGet(gvBasketTier2);
bool droppedFurther = (basketIsLong && prevBarClose < t2RefClose) || (!basketIsLong && prevBarClose > t2RefClose);
if(droppedFurther)
{
bool allSymbolPositionsClosed = CloseAllPositionsOnChartSymbol();
if(allSymbolPositionsClosed)
AlertThrottled("T3_AFTER_T2_DONE", "T3: Giá tiếp tục giảm sau T2 -> đã đóng hết vị thế còn lại.");
else
AlertThrottled("T3_AFTER_T2_RETRY", "T3: Một số vị thế còn lại chưa đóng được; EA sẽ tiếp tục giám sát.");
return;
}
}
}
}
else if(g_sweepMode == SWEEP_WAIT_CANDLE_CLOSE && closedBeyondTier1)
{
bool allSymbolPositionsClosed = CloseAllPositionsOnChartSymbol();
if(allSymbolPositionsClosed)
AlertThrottled("ATR_WICK_DONE", "ATR WICK-PROOF: Nến đóng cửa vượt đường ATR -> đã đóng hết vị thế.");
else
AlertThrottled("ATR_WICK_RETRY", "ATR WICK-PROOF: Một số vị thế chưa đóng được; EA sẽ tiếp tục giám sát.");
return;
}
}
}

for(int i = PositionsTotal() - 1; i >= 0; i--)
{
ulong ticket = PositionGetTicket(i);
if(ticket == 0 || PositionGetString(POSITION_SYMBOL) != _Symbol)
continue;
bool isLong = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY);
if(isLong != basketIsLong)
continue;

if(g_trailStyle == TRAIL_STYLE_MANUAL_SL || justArmedNow)
continue;

double curSL = PositionGetDouble(POSITION_SL);
double curTP = PositionGetDouble(POSITION_TP);
double targetSL = curSL;

if(isLong)
{
if(g_enBe && currentR >= g_beRR)
{
double bePrice = NormalizeDouble(vwapEntry + g_bePoints * _Point, _Digits);
if(bePrice > targetSL) targetSL = bePrice;
}
if(g_enLock && currentR >= g_lockTrigRR)
{
double lockPrice = NormalizeDouble(vwapEntry + basket1R * g_lockLvlRR, _Digits);
if(lockPrice > targetSL) targetSL = lockPrice;
}
if(g_enTrail && g_trailStyle == TRAIL_STYLE_AUTO_ATR && allowTrailStepNow && g_pineTrailingStop > 0.0)
{
double brokerTier3SL = NormalizeDouble(g_pineTrailingStop - activeWickBuffer, _Digits);
if(brokerTier3SL > targetSL)
targetSL = brokerTier3SL;
}
if(targetSL > curSL + _Point * 0.5 && targetSL < bid)
{
if(ModifyPositionWithConfirmation(ticket, targetSL, curTP))
repSL = targetSL;
}
}
else
{
if(g_enBe && currentR >= g_beRR)
{
double bePrice = NormalizeDouble(vwapEntry - g_bePoints * _Point, _Digits);
if(targetSL <= 0.0 || bePrice < targetSL) targetSL = bePrice;
}
if(g_enLock && currentR >= g_lockTrigRR)
{
double lockPrice = NormalizeDouble(vwapEntry - basket1R * g_lockLvlRR, _Digits);
if(targetSL <= 0.0 || lockPrice < targetSL) targetSL = lockPrice;
}
if(g_enTrail && g_trailStyle == TRAIL_STYLE_AUTO_ATR && allowTrailStepNow && g_pineTrailingStop > 0.0)
{
double brokerTier3SL = NormalizeDouble(g_pineTrailingStop + activeWickBuffer, _Digits);
if(targetSL <= 0.0 || brokerTier3SL < targetSL)
targetSL = brokerTier3SL;
}
if(targetSL > 0.0 && (curSL <= 0.0 || targetSL < curSL - _Point * 0.5) && targetSL > ask)
{
if(ModifyPositionWithConfirmation(ticket, targetSL, curTP))
repSL = targetSL;
}
}
}

DrawCurrentAtrSpotlight(g_pineTrailingStop, basket1R, activeSide, openCount, repSL, g_pineStopPlotting, currentR, g_isTrailingArmedNow);
}
else // MULTI_INDIVIDUAL
{
g_isTrailingArmedNow = false;
ObjectsDeleteAll(0, VIS_PREFIX + "ATRLINE_");
DrawCurrentAtrSpotlight(0.0, 0.0, basketIsLong ? SIDE_LONG : SIDE_SHORT, openCount, repSL, false, currentR, false);
double individualRiskWeightedR = 0.0;
double individualRiskWeight = 0.0;
for(int i = PositionsTotal() - 1; i >= 0; i--)
{
ulong ticket = PositionGetTicket(i);
if(ticket == 0 || PositionGetString(POSITION_SYMBOL) != _Symbol)
continue;

long posId = PositionGetInteger(POSITION_IDENTIFIER);
datetime openTime = (datetime)PositionGetInteger(POSITION_TIME);
double actualEntry = PositionGetDouble(POSITION_PRICE_OPEN);
double curSL = PositionGetDouble(POSITION_SL);
double curTP = PositionGetDouble(POSITION_TP);
double curVol = PositionGetDouble(POSITION_VOLUME);
bool isLong = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY);
double livePrice = isLong ? bid : ask;

ENUM_TIMEFRAMES indTf = ResolveActiveAtrTimeframe(1, posId, openTime, (curSL > 0.0 ? MathAbs(actualEntry - curSL) : 0.0));
double plannedEntry = GetFrozenClosedEntryPrice(posId, openTime, actualEntry);
// 1. Trong chế độ quản lý từng lệnh: luôn dùng Giá khớp thực tế (actualEntry) làm gốc tính SL, TP, 1R và R
double entry = actualEntry;
double indEntry = 0.0, indFirstDist = 0.0;
bool indStopPlot = false, indStart = false;
bool indDataReady = false;
double indTrail = ExecuteExactPineScriptFormula(indTf, openTime, entry, isLong ? SIDE_LONG : SIDE_SHORT, false, false,
indEntry, indFirstDist, indStopPlot, indStart, indDataReady);

string gvBestInd = AccountScopedGV("EAP82_IND_BEST_" + IntegerToString(posId));
string gvBestIndStopped = gvBestInd + "_STOP";
if(!indDataReady)
{
bool cachedIndTrailState = GlobalVariableCheck(gvBestIndStopped);
indTrail = (cachedIndTrailState && GlobalVariableCheck(gvBestInd)) ? GlobalVariableGet(gvBestInd) : 0.0;
indStopPlot = cachedIndTrailState ? (GlobalVariableGet(gvBestIndStopped) > 0.5) : true;
indEntry = entry;
indFirstDist = (curSL > 0.0) ? MathAbs(entry - curSL) : 0.0;
}
else
GlobalVariableSet(gvBestIndStopped, indStopPlot ? 1.0 : 0.0);
if(indDataReady && indTrail > 0.0 && !indStopPlot)
{
if(GlobalVariableCheck(gvBestInd))
{
double prevB = GlobalVariableGet(gvBestInd);
if(prevB > 0.0)
indTrail = isLong ? MathMax(indTrail, prevB) : MathMin(indTrail, prevB);
}
GlobalVariableSet(gvBestInd, indTrail);
}

string gv1R = AccountScopedGV("EAP82_1R_" + IntegerToString(posId));
string gvPart = AccountScopedGV("EAP82_PART_" + IntegerToString(posId));
bool partialHistoryReady = PreparePositionPartialState(posId, gvPart);
string gvArmed = AccountScopedGV("EAP82_ARMED_" + IntegerToString(posId));
string gvArmBar = AccountScopedGV("EAP82_ARMBAR_" + IntegerToString(posId));
string gvInitDone = AccountScopedGV("EAP82_INITDONE_" + IntegerToString(posId));
string gvTier2 = AccountScopedGV("EAP82_TIER2_" + IntegerToString(posId));
string gvT2Time = AccountScopedGV("EAP82_T2TIME_" + IntegerToString(posId));
double slDist = GlobalVariableCheck(gv1R) ? GlobalVariableGet(gv1R) : 0.0;

bool indSlInRisk = (curSL > 0.0) && ((isLong && curSL < entry - _Point) || (!isLong && curSL > entry + _Point));
if(slDist <= 0.0 || indSlInRisk)
{
slDist = indSlInRisk ? MathAbs(entry - curSL) : ((indFirstDist > 0.0) ? indFirstDist : slDistCalc);
GlobalVariableSet(gv1R, slDist);
}

// 5. Kiểm tra trượt giá / vượt rủi ro cho từng vị thế riêng lẻ
double indAdverseSlip = isLong ? (actualEntry - plannedEntry) : (plannedEntry - actualEntry);
if(InpRejectMaxSlippagePctOf1R > 0.0 && slDist > _Point && indAdverseSlip > 0.0)
{
double indSlipPct = (indAdverseSlip / slDist) * 100.0;
if(indSlipPct > InpRejectMaxSlippagePctOf1R)
{
ClosePositionWithConfirmation(ticket);
AlertThrottled("IND_REJECT_SLIP_" + IntegerToString(posId),
StringFormat("TỪ CHỐI LỆNH #%I64u: Giá khớp (%s) trượt xấu %.1f%% 1R so với Entry kế hoạch (%s)! Đã đóng lệnh.",
ticket, DoubleToString(actualEntry, _Digits), indSlipPct, DoubleToString(plannedEntry, _Digits)), 30);
continue;
}
}

double initSL = (curSL > 0.0) ? curSL : (isLong ? NormalizeDouble(entry - slDist, _Digits) : NormalizeDouble(entry + slDist, _Digits));
double rawTP = (curTP > 0.0 && !InpRecalcSlTpOnFillDeviation) ? curTP : (isLong ? NormalizeDouble(entry + slDist * g_targetRR, _Digits) : NormalizeDouble(entry - slDist * g_targetRR, _Digits));
bool useIndTrailNoHardTp = ShouldSuppressBrokerHardTpForPartial(curVol, GlobalVariableCheck(gvPart), entry, initSL, rawTP, isLong);
if(useIndTrailNoHardTp)
g_hardTpSuppressedForPartial = true;

if(g_autoSlTp && !GlobalVariableCheck(gvInitDone))
{
double initTP = useIndTrailNoHardTp ? 0.0 : rawTP;
bool levelsReady = (MathAbs(curSL - initSL) < _Point && MathAbs(curTP - initTP) < _Point);
if(!levelsReady && ModifyPositionWithConfirmation(ticket, initSL, initTP))
{
curSL = initSL;
curTP = initTP;
levelsReady = true;
}
if(levelsReady)
GlobalVariableSet(gvInitDone, 1.0);
else
Print("EA PRO: Could not attach initial SL/TP; will retry for position #", ticket);
}
if(useIndTrailNoHardTp && curTP > 0.0)
{
if(ModifyPositionWithConfirmation(ticket, curSL, 0.0))
{
curTP = 0.0;
AlertThrottled("IND_HARDTP_REMOVED_" + IntegerToString(posId),
StringFormat("CHỐNG XUNG ĐỘT TP1 & TRAIL [#%I64u]: Đã gỡ Hard TP trên máy chủ trùng mức cắt %.0f%% (%.1fR).", ticket, g_partialPct, g_partialRR), 120);
}
}

double indBuf20Pct1R = slDist * (g_tierPctOf1R / 100.0);
double indWickBuffer = (g_sweepMode == SWEEP_HARD_SL_ON_LINE) ? 0.0 : indBuf20Pct1R;

double profDist = isLong ? (livePrice - entry) : (entry - livePrice);
double ticketR = (slDist > 0.0) ? (profDist / slDist) : 0.0;
double initialStopForR = isLong ? (actualEntry - slDist) : (actualEntry + slDist);
double ticketInitialRiskCash = 0.0;
if(slDist > 0.0 && EstimateStopRiskCash(_Symbol, isLong, curVol, actualEntry,
initialStopForR, g_bufferPts, g_commPerLot, ticketInitialRiskCash) && ticketInitialRiskCash > 0.0)
{
individualRiskWeightedR += ticketR * ticketInitialRiskCash;
individualRiskWeight += ticketInitialRiskCash;
}
datetime indCurBar0 = iTime(_Symbol, indTf, 0);


string gvPartRetry = AccountScopedGV("EAP82_PARTTRY_" + IntegerToString(posId));
string gvPartTarget = AccountScopedGV("EAP82_PARTTARGET_" + IntegerToString(posId));
string gvPartClosed = AccountScopedGV("EAP82_PARTCLOSED_" + IntegerToString(posId));
if(g_enPartial && partialHistoryReady && !GlobalVariableCheck(gvPart) && ticketR >= g_partialRR)
{
datetime now = TimeCurrent();
datetime lastTry = GlobalVariableCheck(gvPartRetry) ? (datetime)GlobalVariableGet(gvPartRetry) : 0;
if(lastTry == 0 || now - lastTry >= 3)
{
GlobalVariableSet(gvPartRetry, (double)now);
double minLot = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
double lotStep = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);
if(lotStep <= 0.0) lotStep = 0.01;
double targetClose = GlobalVariableCheck(gvPartTarget) ? GlobalVariableGet(gvPartTarget) : FloorLotStep(curVol * (g_partialPct / 100.0));
if(!GlobalVariableCheck(gvPartTarget) && targetClose >= minLot && (curVol - targetClose) >= minLot - 1e-6)
GlobalVariableSet(gvPartTarget, targetClose);
double closedSoFar = GlobalVariableCheck(gvPartClosed) ? GlobalVariableGet(gvPartClosed) : 0.0;
double remainingToClose = targetClose - closedSoFar;
if(targetClose >= minLot && remainingToClose >= minLot && remainingToClose <= curVol - minLot + 1e-6)
{
double actualClosed = 0.0;
if(ClosePositionPartiallyByTicket(ticket, remainingToClose, actualClosed))
{
closedSoFar += actualClosed;
GlobalVariableSet(gvPartClosed, closedSoFar);
if(closedSoFar + lotStep * 0.5 >= targetClose)
{
GlobalVariableSet(gvPart, 1.0);
GlobalVariableDel(gvPartRetry);
GlobalVariableDel(AccountScopedGV("EAP82_PARTWARN_" + IntegerToString(posId)));
}
else
ReportPartialTPIssue(posId, StringFormat("Đã chốt %.2f/%.2f lot TP1; EA sẽ thử tiếp phần còn thiếu.", closedSoFar, targetClose));
}
else
ReportPartialTPIssue(posId, "Yêu cầu chốt một phần chưa được xác nhận; EA sẽ thử lại sau 3 giây.");
}
else
ReportPartialTPIssue(posId, StringFormat("Không thể chốt đủ %.2f lot TP1 từ khối lượng hiện tại %.2f theo min lot/bước lot; TP1 chưa được đánh dấu hoàn tất.", targetClose, curVol));
}
}
if(g_enPartial && ticketR >= g_partialRR && curTP > 0.0 && GlobalVariableCheck(gvPart))
{
if(ModifyPositionWithConfirmation(ticket, curSL, 0.0))
curTP = 0.0;
}


bool ticketArmed = GlobalVariableCheck(gvArmed) ? (GlobalVariableGet(gvArmed) > 0.5) : false;
datetime indArmedBar = GlobalVariableCheck(gvArmBar) ? (datetime)GlobalVariableGet(gvArmBar) : 0;
bool indJustArmed = false;

if(ticketR >= g_trailStartRR && !ticketArmed)
{
ticketArmed = true;
indJustArmed = true;
indArmedBar = indCurBar0;
GlobalVariableSet(gvArmed, 1.0);
GlobalVariableSet(gvArmBar, (double)indArmedBar);
}
if(ticketArmed)
g_isTrailingArmedNow = true;

if(g_trailStyle == TRAIL_STYLE_MANUAL_SL || indJustArmed)
continue;

bool indAllowTrailNow = (ticketArmed && !indJustArmed && (indArmedBar == 0 || indCurBar0 > indArmedBar));
double indPrevClose = iClose(_Symbol, indTf, 1);
datetime indPrevTime = iTime(_Symbol, indTf, 1);

if(g_enTrail && g_trailStyle == TRAIL_STYLE_AUTO_ATR && indAllowTrailNow && indTrail > 0.0)
{
double t3HardP = isLong ? (indTrail - indWickBuffer) : (indTrail + indWickBuffer);
if(g_enLock && ticketR >= g_lockTrigRR)
{
double lockD = slDist * g_lockLvlRR;
double minFloorL = isLong ? (entry + lockD) : (entry - lockD);
t3HardP = isLong ? MathMax(minFloorL, t3HardP) : MathMin(minFloorL, t3HardP);
}

if((isLong && livePrice <= t3HardP) || (!isLong && livePrice >= t3HardP))
{
ClosePositionWithConfirmation(ticket);
continue;
}

if(indPrevTime > openTime && (indArmedBar == 0 || indPrevTime > indArmedBar))
{
bool cBeyondT1 = (isLong && indPrevClose < indTrail) || (!isLong && indPrevClose > indTrail);
bool cBeyondT3 = (isLong && indPrevClose <= t3HardP) || (!isLong && indPrevClose >= t3HardP);

if(g_sweepMode == SWEEP_3LAYER_20PCT_1R)
{
bool hasT2 = GlobalVariableCheck(gvTier2);
datetime t2T = GlobalVariableCheck(gvT2Time) ? (datetime)GlobalVariableGet(gvT2Time) : 0;

if(!hasT2 && GlobalVariableCheck(gvPart))
{
GlobalVariableSet(gvTier2, indPrevClose);
GlobalVariableSet(gvT2Time, (double)indPrevTime);
GlobalVariableDel(AccountScopedGV("EAP82_T2TRY_" + IntegerToString(posId)));
hasT2 = true;
t2T = indPrevTime;
AlertThrottled("T2_ALREADY_REDUCED_" + IntegerToString(posId), "T2: Đã có lần giảm 50% trước đó; bỏ lần cắt trùng và tiếp tục theo dõi trailing.");
}

if(cBeyondT3)
{
ClosePositionWithConfirmation(ticket);
continue;
}
else if(cBeyondT1)
{
if(!hasT2)
{
string gvT2Try = AccountScopedGV("EAP82_T2TRY_" + IntegerToString(posId));
datetime now = TimeCurrent();
datetime lastTry = GlobalVariableCheck(gvT2Try) ? (datetime)GlobalVariableGet(gvT2Try) : 0;
if(lastTry == 0 || now - lastTry >= 3)
{
GlobalVariableSet(gvT2Try, (double)now);
double minLot = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
double lotStep = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);
if(lotStep <= 0.0) lotStep = 0.01;
string gvT2Target = AccountScopedGV("EAP82_T2TARGET_" + IntegerToString(posId));
string gvT2Closed = AccountScopedGV("EAP82_T2CLOSED_" + IntegerToString(posId));
double targetClose = GlobalVariableCheck(gvT2Target) ? GlobalVariableGet(gvT2Target) : FloorLotStep(curVol * 0.5);
if(!GlobalVariableCheck(gvT2Target) && targetClose >= minLot && curVol - targetClose >= minLot - 1e-6)
GlobalVariableSet(gvT2Target, targetClose);
double closedSoFar = GlobalVariableCheck(gvT2Closed) ? GlobalVariableGet(gvT2Closed) : 0.0;
double remaining = targetClose - closedSoFar;
if(targetClose >= minLot && remaining >= minLot && remaining <= curVol - minLot + 1e-6)
{
double actualClosed = 0.0;
if(ClosePositionPartiallyByTicket(ticket, remaining, actualClosed))
{
closedSoFar += actualClosed;
GlobalVariableSet(gvT2Closed, closedSoFar);
if(closedSoFar + lotStep * 0.5 >= targetClose)
{
GlobalVariableSet(gvTier2, indPrevClose);
GlobalVariableSet(gvT2Time, (double)indPrevTime);
GlobalVariableSet(gvPart, 1.0);
GlobalVariableDel(gvT2Try);
GlobalVariableDel(AccountScopedGV("EAP82_PARTWARN_" + IntegerToString(posId)));
}
else
ReportPartialTPIssue(posId, StringFormat("T2 đã cắt %.2f/%.2f lot; EA sẽ thử tiếp phần còn thiếu.", closedSoFar, targetClose));
}
else
ReportPartialTPIssue(posId, "T2 chưa được máy chủ xác nhận; EA sẽ thử lại.");
}
else
ReportPartialTPIssue(posId, StringFormat("T2 không thể chia 50%% khối lượng %.2f theo min lot/bước lot của sàn.", curVol));
}
}
else if(indPrevTime > t2T)
{
double prevT2Close = GlobalVariableGet(gvTier2);
if((isLong && indPrevClose < prevT2Close) || (!isLong && indPrevClose > prevT2Close))
{
ClosePositionWithConfirmation(ticket);
continue;
}
}
}
}
else if(g_sweepMode == SWEEP_WAIT_CANDLE_CLOSE && cBeyondT1)
{
ClosePositionWithConfirmation(ticket);
continue;
}
}
}

double targetSL = curSL;
if(isLong)
{
if(g_enBe && ticketR >= g_beRR)
{ double beP = NormalizeDouble(entry + g_bePoints * _Point, _Digits); if(beP > targetSL) targetSL = beP; }
if(g_enLock && ticketR >= g_lockTrigRR)
{ double flP = NormalizeDouble(entry + slDist * g_lockLvlRR, _Digits); if(flP > targetSL) targetSL = flP; }
if(g_enTrail && g_trailStyle == TRAIL_STYLE_AUTO_ATR && indAllowTrailNow && indTrail > 0.0)
{
double trP = NormalizeDouble(indTrail - indWickBuffer, _Digits);
if(trP > targetSL) targetSL = trP;
}
if(targetSL > curSL + _Point * 0.5 && targetSL < bid)
ModifyPositionWithConfirmation(ticket, targetSL, curTP);
}
else
{
if(g_enBe && ticketR >= g_beRR)
{ double beP = NormalizeDouble(entry - g_bePoints * _Point, _Digits); if(targetSL <= 0.0 || beP < targetSL) targetSL = beP; }
if(g_enLock && ticketR >= g_lockTrigRR)
{ double flP = NormalizeDouble(entry - slDist * g_lockLvlRR, _Digits); if(targetSL <= 0.0 || flP < targetSL) targetSL = flP; }
if(g_enTrail && g_trailStyle == TRAIL_STYLE_AUTO_ATR && indAllowTrailNow && indTrail > 0.0)
{
double trP = NormalizeDouble(indTrail + indWickBuffer, _Digits);
if(targetSL <= 0.0 || trP < targetSL) targetSL = trP;
}
if(targetSL > 0.0 && (curSL <= 0.0 || targetSL < curSL - _Point * 0.5) && targetSL > ask)
ModifyPositionWithConfirmation(ticket, targetSL, curTP);
}
}

currentR = (individualRiskWeight > 0.0) ? (individualRiskWeightedR / individualRiskWeight) : 0.0;
}
}
else
{
g_isTrailingArmedNow = false;
g_hardTpSuppressedForPartial = false;
g_resolvedAtrTf = ResolveActiveAtrTimeframe(0, 0, 0, 0.0);
SyncAnchorDateFields(g_resolvedAtrTf, 0);

datetime standbyAnchorTime = 0;
if(InpLockStandbySetupTfAndBar && g_standbySetupLocked && g_standbyLockedAnchorTime > 0)
{
standbyAnchorTime = g_standbyLockedAnchorTime;
}
else if(g_autoSyncDate)
{
datetime tfLookbackTime = iTime(_Symbol, g_resolvedAtrTf, g_standbyLookback);
standbyAnchorTime = (tfLookbackTime > 0) ? tfLookbackTime : (TimeCurrent() - PeriodSeconds(g_resolvedAtrTf) * g_standbyLookback);
if(InpLockStandbySetupTfAndBar && standbyAnchorTime > 0)
g_standbyLockedAnchorTime = standbyAnchorTime;
}
else
{
standbyAnchorTime = StringToTime(StringFormat("%04d.%02d.%02d 00:00", g_entryDateYear, g_entryDateMonth, g_entryDateDay));
if(InpLockStandbySetupTfAndBar && standbyAnchorTime > 0)
g_standbyLockedAnchorTime = standbyAnchorTime;
}

bool standbyDataReady = false;
double standbyEntryRef = (InpLockStandbySetupTfAndBar && g_standbySetupLocked && g_standbyLockedEntry > 0.0) ? g_standbyLockedEntry : g_entryPriceInput;
g_pineTrailingStop = ExecuteExactPineScriptFormula(g_resolvedAtrTf, standbyAnchorTime, standbyEntryRef, g_tradeSide, g_showAtrPlot, g_autoRestartAtr,
g_pineEntryLevel, g_pineFirstBarSlDist, g_pineStopPlotting, g_pineStartCalc, standbyDataReady);
if(!standbyDataReady)
g_pineTrailingStop = 0.0;
if(!g_showAtrPlot)
ObjectsDeleteAll(0, VIS_PREFIX + "ATRLINE_");

DrawCurrentAtrSpotlight(g_pineTrailingStop, g_pineFirstBarSlDist, g_tradeSide, 0, 0.0, g_pineStopPlotting, 0.0, false);
}

UpdateHudAndTabValues(dayPct, weekPct, monthPct, openCount, totalOpenVol, vwapEntry, repSL, repTP, basketIsLong, anchorPosId, earliestOpenTime, currentR, netFloatingPnl);
}

void ClampPanelCoordinates()
{
long chartW = ChartGetInteger(0, CHART_WIDTH_IN_PIXELS);
long chartH = ChartGetInteger(0, CHART_HEIGHT_IN_PIXELS);

int maxX = MathMax(5, (int)chartW - g_panelW - 6);
int maxY = MathMax(5, (int)chartH - g_headerH - 8);

if(g_panelX < 5) g_panelX = 5;
if(g_panelX > maxX) g_panelX = maxX;
if(g_panelY < 5) g_panelY = 5;
if(g_panelY > maxY) g_panelY = maxY;
}

void CreateBox(string name, int x, int y, int w, int h, color bg, color border)
{
string obj = PREFIX + name;
if(ObjectFind(0, obj) < 0)
{
ObjectCreate(0, obj, OBJ_RECTANGLE_LABEL, 0, 0, 0);
ObjectSetInteger(0, obj, OBJPROP_CORNER, CORNER_LEFT_UPPER);
ObjectSetInteger(0, obj, OBJPROP_SELECTABLE, false);
}
ObjectSetInteger(0, obj, OBJPROP_XDISTANCE, x);
ObjectSetInteger(0, obj, OBJPROP_YDISTANCE, y);
ObjectSetInteger(0, obj, OBJPROP_XSIZE, w);
ObjectSetInteger(0, obj, OBJPROP_YSIZE, h);
ObjectSetInteger(0, obj, OBJPROP_BGCOLOR, bg);
ObjectSetInteger(0, obj, OBJPROP_COLOR, border);
}

void CreateTxt(string name, int x, int y, string text, color clr, bool bold, int customSize = 0)
{
string obj = PREFIX + name;
if(ObjectFind(0, obj) < 0)
{
ObjectCreate(0, obj, OBJ_LABEL, 0, 0, 0);
ObjectSetInteger(0, obj, OBJPROP_CORNER, CORNER_LEFT_UPPER);
ObjectSetInteger(0, obj, OBJPROP_ANCHOR, ANCHOR_LEFT);
ObjectSetInteger(0, obj, OBJPROP_SELECTABLE, false);
}
ObjectSetInteger(0, obj, OBJPROP_XDISTANCE, x);
ObjectSetInteger(0, obj, OBJPROP_YDISTANCE, y);
ObjectSetString(0, obj, OBJPROP_FONT, bold ? "Segoe UI Bold" : "Segoe UI");
ObjectSetInteger(0, obj, OBJPROP_FONTSIZE, (customSize > 0) ? customSize : InpFontSize);
ObjectSetInteger(0, obj, OBJPROP_COLOR, clr);
ObjectSetString(0, obj, OBJPROP_TEXT, text);
}

void CreateEditBox(string name, int x, int y, int w, int h, string initVal, bool readOnly = false)
{
string obj = PREFIX + name;
if(ObjectFind(0, obj) < 0)
{
ObjectCreate(0, obj, OBJ_EDIT, 0, 0, 0);
ObjectSetInteger(0, obj, OBJPROP_CORNER, CORNER_LEFT_UPPER);
ObjectSetInteger(0, obj, OBJPROP_ALIGN, ALIGN_CENTER);
ObjectSetString(0, obj, OBJPROP_FONT, "Segoe UI Bold");
ObjectSetString(0, obj, OBJPROP_TEXT, initVal);
}
ObjectSetInteger(0, obj, OBJPROP_READONLY, readOnly);
ObjectSetInteger(0, obj, OBJPROP_XDISTANCE, x);
ObjectSetInteger(0, obj, OBJPROP_YDISTANCE, y);
ObjectSetInteger(0, obj, OBJPROP_XSIZE, w);
ObjectSetInteger(0, obj, OBJPROP_YSIZE, h);
ObjectSetInteger(0, obj, OBJPROP_FONTSIZE, InpFontSize);
ObjectSetInteger(0, obj, OBJPROP_BGCOLOR, readOnly ? C_EDIT_MUTED : C_EDIT_BG);
ObjectSetInteger(0, obj, OBJPROP_COLOR, C_EDIT_TXT);
ObjectSetInteger(0, obj, OBJPROP_BORDER_COLOR, C_BORDER);
}

void CreateBtn(string name, int x, int y, int w, int h, string text, color bg, color txtClr)
{
string obj = PREFIX + name;
if(ObjectFind(0, obj) < 0)
{
ObjectCreate(0, obj, OBJ_BUTTON, 0, 0, 0);
ObjectSetInteger(0, obj, OBJPROP_CORNER, CORNER_LEFT_UPPER);
ObjectSetString(0, obj, OBJPROP_FONT, "Segoe UI Bold");
}
ObjectSetInteger(0, obj, OBJPROP_XDISTANCE, x);
ObjectSetInteger(0, obj, OBJPROP_YDISTANCE, y);
ObjectSetInteger(0, obj, OBJPROP_XSIZE, w);
ObjectSetInteger(0, obj, OBJPROP_YSIZE, h);
ObjectSetInteger(0, obj, OBJPROP_FONTSIZE, InpFontSize);
ObjectSetInteger(0, obj, OBJPROP_BGCOLOR, bg);
ObjectSetInteger(0, obj, OBJPROP_COLOR, txtClr);
ObjectSetInteger(0, obj, OBJPROP_BORDER_COLOR, C_BORDER);
ObjectSetInteger(0, obj, OBJPROP_STATE, false);
ObjectSetString(0, obj, OBJPROP_TEXT, text);
}

string GetAtrTfBtnLabel()
{
string activeTf = GetTfShortName(g_resolvedAtrTf);
switch(g_atrTfMode)
{
case ATR_TF_AUTO_ENTRY: return "TF: AUTO (" + activeTf + ")";
case ATR_TF_FIXED_H1: return "TF: CỐ ĐỊNH H1";
case ATR_TF_FIXED_M15: return "TF: CỐ ĐỊNH M15";
case ATR_TF_FIXED_M5: return "TF: CỐ ĐỊNH M5";
case ATR_TF_FIXED_H4: return "TF: CỐ ĐỊNH H4";
case ATR_TF_FIXED_D1: return "TF: CỐ ĐỊNH D1";
default: return "TF: CHART (" + activeTf + ")";
}
}

//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
void RebuildCleanPanel(bool clearBeforeBuild)
{
if(clearBeforeBuild)
ObjectsDeleteAll(0, PREFIX);

int dpi = TerminalInfoInteger(TERMINAL_SCREEN_DPI);
double s = (dpi > 96) ? (dpi / 96.0) : 1.0;

int panelW = (int)MathRound(470 * s);
int rowH = (int)MathRound(26 * s);
int ctlH = (int)MathRound(20 * s);
int editW = (int)MathRound(58 * s);
int smallW = (int)MathRound(50 * s);
int btnW = (int)MathRound(98 * s);

g_panelW = panelW;
g_headerH = rowH + 2;
g_panelH = g_isMinimized ? g_headerH : (rowH * 12 + 12);

ClampPanelCoordinates();
int baseX = g_panelX;
int baseY = g_panelY;

CreateBox("HdrBg", baseX, baseY, panelW, rowH + 2, g_isDraggingPanel ? C_BG_DRAG : C_BG_HEADER, C_BORDER);
CreateTxt("HdrTitle", baseX + 10, baseY + rowH / 2,
g_isDraggingPanel ? "ĐANG DI CHUYỂN BẢNG..." : "EA PRO v8.5 ACCOUNT SAFE",
g_isDraggingPanel ? clrYellow : clrWhite, true);

int minW = (int)MathRound(28 * s);
int cornW = (int)MathRound(64 * s);
CreateBtn("Btn_Min", baseX + panelW - minW - 4, baseY + 3, minW, ctlH, g_isMinimized ? "[+]" : "[-]", C_BTN_OFF, clrWhite);
CreateBtn("Btn_Area", baseX + panelW - minW - cornW - 8, baseY + 3, cornW, ctlH, "GÓC", C_BTN_MODE, clrWhite);

if(g_isMinimized)
{
ChartRedraw(0);
return;
}

CreateBox("BodyBg", baseX, baseY + rowH + 1, panelW, rowH * 11 + 10, C_BG_BODY, C_BORDER);

int yHud = baseY + rowH + 4;
CreateBox("HudCard", baseX + 6, yHud, panelW - 12, rowH * 3 + 2, C_BG_HUD, clrTeal);

CreateTxt("Hud_Line1", baseX + 14, yHud + (int)(13 * s), "ĐANG KIỂM TRA TRẠNG THÁI...", clrLime, true);
CreateBtn("Btn_ForceLock", baseX + panelW - btnW - 12, yHud + 3, btnW, ctlH,
g_accountSwitchHold ? (g_accountHoldRiskDataReady ? "XÁC NHẬN TK" : "CHỜ DỮ LIỆU") : (g_manualForceLock ? "MỞ KHÓA TAY" : "Khóa Ngay"),
g_accountSwitchHold ? (g_accountHoldRiskDataReady ? C_BTN_ACT : C_BTN_LOCK) : (g_manualForceLock ? C_BTN_LOCK : C_BTN_ACT), clrWhite);

CreateTxt("Hud_Line2L", baseX + 14, yHud + (int)(38 * s), "KHỐI LƯỢNG: ...", clrWhite, true);
CreateTxt("Hud_Line2R", baseX + (int)MathRound(258 * s), yHud + (int)(38 * s), "TP1/CÒN LẠI: ...", clrAqua, true);

CreateTxt("Hud_Line3L", baseX + 14, yHud + (int)(62 * s), "ATR TRAIL: ...", clrGold, true);
CreateTxt("Hud_Line3R", baseX + (int)MathRound(258 * s), yHud + (int)(62 * s), "TRẠNG THÁI: ...", clrGold, true);

int yTab = baseY + rowH * 4 + 10;
int tabW = (panelW - 20) / 3;
CreateBtn("Tab_Pos", baseX + 6, yTab, tabW, ctlH + 3, "1. VỊ THẾ & SL/TP", (g_activeTab == TAB_POSITION) ? C_TAB_ACTIVE : C_TAB_IDLE, clrWhite);
CreateBtn("Tab_Trail", baseX + 10 + tabW, yTab, tabW, ctlH + 3, "2. ATR TRAILING", (g_activeTab == TAB_TRAILING) ? C_TAB_ACTIVE : C_TAB_IDLE, clrWhite);
CreateBtn("Tab_Risk", baseX + 14 + tabW * 2, yTab, tabW, ctlH + 3, "3. RỦI RO & MỞ KHÓA", (g_activeTab == TAB_RISKNEWS) ? C_TAB_ACTIVE : C_TAB_IDLE, clrWhite);

int yContent = baseY + rowH * 5 + 14;
CreateBox("TabCard", baseX + 6, yContent, panelW - 12, rowH * 5 + 4, C_BG_CARD, C_BORDER);

int colEdit1 = baseX + (int)MathRound(220 * s);
int colEdit2 = baseX + (int)MathRound(284 * s);
int col3_1 = baseX + (int)MathRound(198 * s);
int col3_2 = baseX + (int)MathRound(253 * s);
int col3_3 = baseX + (int)MathRound(308 * s);
int colBtn = baseX + panelW - btnW - 12;

if(g_activeTab == TAB_POSITION)
{
int r = 0, y = yContent + r * rowH + 4;
string slModeTxt = (g_slMode == SL_MODE_ATR_FIRST) ? "SL: ATR ĐẦU TIÊN" :
((g_slMode == SL_MODE_ATR_LINE) ? "SL: ĐƯỜNG ATR" :
((g_slMode == SL_MODE_POINTS) ? "SL: POINTS" : "SL: KÉO TAY"));
CreateTxt("T1_L1", baseX + 14, y + rowH / 2, "Risk/Lệnh (%) | Tỷ lệ TP (R):", clrWhite, false);
CreateEditBox("Ed_RiskPct", colEdit1, y + 2, editW, ctlH, DoubleToString(g_riskPct, 2));
CreateEditBox("Ed_RR", colEdit2, y + 2, editW, ctlH, DoubleToString(g_targetRR, 2));
CreateBtn("Btn_SlMode", colBtn, y + 2, btnW, ctlH, slModeTxt, C_BTN_MODE, clrWhite);

r = 1; y = yContent + r * rowH + 4;
string ruleTxt = (g_volRule == RULE_KEEP_DIST_CALC_CASH) ? "GIỮ KHOẢNG CÁCH SL/TP -> TÍNH $" : "ĐIỀU CHỈNH SL THEO LOT & RISK";
CreateTxt("T1_L2", baseX + 14, y + rowH / 2, "Quy tắc SL/TP khi có lệnh:", clrAqua, true);
CreateBtn("Btn_VolRule", colEdit1, y + 2, panelW - (colEdit1 - baseX) - 12, ctlH, ruleTxt, (g_volRule == RULE_KEEP_DIST_CALC_CASH) ? C_BTN_ON : C_BTN_ACT, clrWhite);

r = 2; y = yContent + r * rowH + 4;
string multiTxt = (g_multiMode == MULTI_BASKET_VWAP) ? "GỘP RỦI RO THEO GIÁ TRUNG BÌNH (VWAP)" : "TÁCH RIÊNG TỪNG LỆNH";
CreateTxt("T1_L3", baseX + 14, y + rowH / 2, "Khi vào nhiều lệnh cùng lúc:", clrYellow, true);
CreateBtn("Btn_MultiMode", colEdit1, y + 2, panelW - (colEdit1 - baseX) - 12, ctlH, multiTxt, (g_multiMode == MULTI_BASKET_VWAP) ? C_TAB_ACTIVE : C_BTN_OFF, clrWhite);

r = 3; y = yContent + r * rowH + 4;
CreateTxt("T1_L4", baseX + 14, y + rowH / 2, "SL (điểm) | Đệm (điểm) | Phí ($/lot):", clrWhite, false);
CreateEditBox("Ed_ManSlPts", col3_1, y + 2, smallW, ctlH, IntegerToString(g_manualSlPts));
CreateEditBox("Ed_BufPts", col3_2, y + 2, smallW, ctlH, IntegerToString(g_bufferPts));
CreateEditBox("Ed_CommLot", col3_3, y + 2, smallW, ctlH, DoubleToString(g_commPerLot, 1));
CreateBtn("Btn_AutoSlTp", colBtn, y + 2, btnW, ctlH, g_autoSlTp ? "GẮN SL ĐẦU: BẬT" : "GẮN SL ĐẦU: TẮT", g_autoSlTp ? C_BTN_ON : C_BTN_OFF, clrWhite);

r = 4; y = yContent + r * rowH + 4;
string trailQuickTxt = (g_trailStyle == TRAIL_STYLE_AUTO_ATR) ? "AUTO TRAIL" :
((g_trailStyle == TRAIL_STYLE_BE_FLOAT) ? "THỦ CÔNG (BE)" : "SL TAY 100%");
color trailQuickClr = (g_trailStyle == TRAIL_STYLE_AUTO_ATR) ? C_BTN_ON :
((g_trailStyle == TRAIL_STYLE_BE_FLOAT) ? C_BTN_ACT : C_BTN_OFF);
int wSmallBtn = (int)MathRound(78 * s);
CreateTxt("T1_L5", baseX + 14, y + rowH / 2, "Chế độ | Nhật ký tín hiệu:", clrLime, true);
CreateBtn("Btn_Trail", col3_1, y + 2, wSmallBtn, ctlH, trailQuickTxt, trailQuickClr, clrWhite);
CreateBtn("Btn_Journal", col3_1 + wSmallBtn + 4, y + 2, wSmallBtn, ctlH, g_showJournal ? "NHẬT KÝ: BẬT" : "NHẬT KÝ: TẮT", g_showJournal ? C_BTN_ON : C_BTN_OFF, clrWhite);
CreateBtn("Btn_ShowSizer", colBtn, y + 2, btnW, ctlH, g_showSizer ? "THƯỚC: HIỆN" : "THƯỚC: ẨN", g_showSizer ? C_BTN_ON : C_BTN_OFF, clrWhite);
}
else if(g_activeTab == TAB_TRAILING)
{
int r = 0, y = yContent + r * rowH + 4;
CreateTxt("T2_L1", baseX + 14, y + rowH / 2, "ATR (Kỳ | FirstDay | Hệ số):", clrAqua, true);
CreateEditBox("Ed_AtrPer", col3_1, y + 2, smallW, ctlH, IntegerToString(g_atrLength));
CreateEditBox("Ed_FirstMul", col3_2, y + 2, smallW, ctlH, DoubleToString(g_customValueForFirstDay, 2));
CreateEditBox("Ed_AtrMul", col3_3, y + 2, smallW, ctlH, DoubleToString(g_atrMultiplier, 2));
CreateBtn("Btn_ShowPlot", colBtn, y + 2, btnW, ctlH, g_showAtrPlot ? "VẼ LINE: BẬT" : "VẼ LINE: TẮT", g_showAtrPlot ? C_BTN_ON : C_BTN_OFF, clrWhite);

r = 1; y = yContent + r * rowH + 4;
string dateLbl = g_autoSyncDate ? "Neo [TỰ ĐỘNG NGÀY MỚI] | Khung:" : "Neo [NGÀY CỐ ĐỊNH] | Khung:";
CreateTxt("T2_L2", baseX + 14, y + rowH / 2, dateLbl, g_autoSyncDate ? clrLime : clrYellow, true);
CreateEditBox("Ed_Yr", col3_1, y + 2, smallW, ctlH, IntegerToString(g_entryDateYear));
CreateEditBox("Ed_Mo", col3_2, y + 2, smallW, ctlH, IntegerToString(g_entryDateMonth));
CreateEditBox("Ed_Dy", col3_3, y + 2, smallW, ctlH, IntegerToString(g_entryDateDay));
CreateBtn("Btn_AtrTf", colBtn, y + 2, btnW, ctlH, GetAtrTfBtnLabel(), C_BTN_MODE, clrWhite);

r = 2; y = yContent + r * rowH + 4;
int wAnti1 = (int)MathRound(136 * s);
int wAnti2 = (int)MathRound(120 * s);
string sweepBtnTxt = (g_sweepMode == SWEEP_3LAYER_20PCT_1R) ? "BẢO VỆ 3 TẦNG (20% 1R)" :
((g_sweepMode == SWEEP_WAIT_CANDLE_CLOSE) ? "CHỐNG RÂU 2 TẦNG" : "SL CỨNG THEO ATR");
color sweepBtnClr = (g_sweepMode == SWEEP_3LAYER_20PCT_1R) ? C_BTN_ON :
((g_sweepMode == SWEEP_WAIT_CANDLE_CLOSE) ? C_TAB_ACTIVE : C_BTN_OFF);

CreateTxt("T2_L3", baseX + 14, y + rowH / 2, "Cơ chế bảo vệ Trailing:", clrLime, true);
CreateBtn("Btn_SweepMode", col3_1 - 2, y + 2, wAnti1, ctlH, sweepBtnTxt, sweepBtnClr, clrWhite);
CreateBtn("Btn_AtrSrc", col3_1 + wAnti1 + 2, y + 2, wAnti2, ctlH,
(g_atrSource == ATR_SRC_CLOSE_SWING) ? "NEO: NẾN ĐÓNG" : "NEO: ĐỈNH/ĐÁY",
(g_atrSource == ATR_SRC_CLOSE_SWING) ? C_BTN_MODE : C_BTN_OFF, clrWhite);

r = 3; y = yContent + r * rowH + 4;
string trailBtnTxt = (g_trailStyle == TRAIL_STYLE_AUTO_ATR) ? "TRAIL: BẬT (>=R)" :
((g_trailStyle == TRAIL_STYLE_BE_FLOAT) ? "THỦ CÔNG (CHỜ BE)" : "SL TAY 100%");
color trailBtnClr = (g_trailStyle == TRAIL_STYLE_AUTO_ATR) ? C_BTN_ON :
((g_trailStyle == TRAIL_STYLE_BE_FLOAT) ? C_BTN_ACT : C_BTN_OFF);
CreateTxt("T2_L4", baseX + 14, y + rowH / 2, "Bật Trail (R) | Biên 3 tầng (%1R):", clrWhite, false);
CreateEditBox("Ed_TrailRR", colEdit1, y + 2, editW, ctlH, DoubleToString(g_trailStartRR, 2));
CreateEditBox("Ed_TierPct1R", colEdit2, y + 2, editW, ctlH, DoubleToString(g_tierPctOf1R, 0), (g_sweepMode == SWEEP_HARD_SL_ON_LINE));
CreateBtn("Btn_Trail", colBtn, y + 2, btnW, ctlH, trailBtnTxt, trailBtnClr, clrWhite);

r = 4; y = yContent + r * rowH + 4;
string tp1BeTxt = g_enPartial ? (g_enBe ? "TP1 + DỜI BE" : "TP1: GIỮ SL") : (g_enBe ? "CHỈ DỜI BE" : "TP1 & BE: TẮT");
color tp1BeClr = g_enPartial ? (g_enBe ? C_BTN_ACT : C_BTN_ON) : (g_enBe ? C_TAB_ACTIVE : C_BTN_OFF);
CreateTxt("T2_L5", baseX + 14, y + rowH / 2, "TP1 (R | %Vol) | +Points BE:", clrWhite, false);
CreateEditBox("Ed_PartRR", col3_1, y + 2, smallW, ctlH, DoubleToString(g_partialRR, 1));
CreateEditBox("Ed_PartPct", col3_2, y + 2, smallW, ctlH, DoubleToString(g_partialPct, 0));
CreateEditBox("Ed_BePts", col3_3, y + 2, smallW, ctlH, IntegerToString(g_bePoints), !g_enBe);
CreateBtn("Btn_Be", colBtn, y + 2, btnW, ctlH, tp1BeTxt, tp1BeClr, clrWhite);
}
else // TAB_RISKNEWS
{
int r = 0, y = yContent + r * rowH + 4;
CreateTxt("T3_L1", baseX + 14, y + rowH / 2, "Lỗ tối đa Ngày|Tuần|Tháng (%):", clrWhite, true);
CreateEditBox("Ed_MaxDay", col3_1, y + 2, smallW, ctlH, DoubleToString(g_maxDailyLossPct, 1), g_riskBreached);
CreateEditBox("Ed_MaxWeek", col3_2, y + 2, smallW, ctlH, DoubleToString(g_maxWeeklyLossPct, 1), g_riskBreached);
CreateEditBox("Ed_MaxMonth", col3_3, y + 2, smallW, ctlH, DoubleToString(g_maxMonthlyLossPct, 1), g_riskBreached);
CreateBtn("Btn_RiskGuard", colBtn, y + 2, btnW, ctlH, g_riskBreached ? "ĐANG KHÓA CỨNG" : (g_enRiskGuard ? "BẢO VỆ: BẬT" : "BẢO VỆ: TẮT"),
g_riskBreached ? C_BTN_LOCK : (g_enRiskGuard ? C_BTN_ON : C_BTN_OFF), clrWhite);

r = 1; y = yContent + r * rowH + 4;
CreateTxt("T3_L2", baseX + 14, y + rowH / 2, "Vốn tính Risk ($):", clrWhite, false);
CreateEditBox("Ed_CustomEq", colEdit1, y + 2, editW * 2 + 6, ctlH, DoubleToString(g_customEquity, 0));
CreateBtn("Btn_GetRealEq", colBtn, y + 2, btnW, ctlH, g_useLiveEquity ? "VỐN LIVE" : "VỐN SÀN", C_BTN_MODE, clrWhite);

r = 2; y = yContent + r * rowH + 4;
CreateTxt("T3_L3", baseX + 14, y + rowH / 2, "Phút cấm (Trước | Sau tin):", clrWhite, false);
CreateEditBox("Ed_MinBef", colEdit1, y + 2, editW, ctlH, IntegerToString(g_minBeforeNews));
CreateEditBox("Ed_MinAft", colEdit2, y + 2, editW, ctlH, IntegerToString(g_minAfterNews));
CreateBtn("Btn_News", colBtn, y + 2, btnW, ctlH, g_enNewsFilter ? "LỌC TIN: BẬT" : "LỌC TIN: TẮT", g_enNewsFilter ? C_BTN_ON : C_BTN_OFF, clrWhite);

r = 3; y = yContent + r * rowH + 4;
int wSlotBtn = (int)MathRound(57 * s);
int gapSlot = (int)MathRound(4 * s);
int xS1 = baseX + 12;
int xS2 = xS1 + wSlotBtn + gapSlot;
int xS3 = xS2 + wSlotBtn + gapSlot;

CreateBtn("Btn_EnSlot1", xS1, y + 2, wSlotBtn, ctlH, g_enSlot1 ? "TIN 1" : "TIN 1", g_enSlot1 ? C_BTN_ON : C_BTN_OFF, clrWhite);
CreateBtn("Btn_EnSlot2", xS2, y + 2, wSlotBtn, ctlH, g_enSlot2 ? "TIN 2" : "TIN 2", g_enSlot2 ? C_BTN_ON : C_BTN_OFF, clrWhite);
CreateBtn("Btn_EnSlot3", xS3, y + 2, wSlotBtn, ctlH, g_enSlot3 ? "TIN 3" : "TIN 3", g_enSlot3 ? C_BTN_ON : C_BTN_OFF, clrWhite);

CreateEditBox("Ed_Slot1", col3_1, y + 2, smallW, ctlH, g_newsSlot1, !g_enSlot1);
CreateEditBox("Ed_Slot2", col3_2, y + 2, smallW, ctlH, g_newsSlot2, !g_enSlot2);
CreateEditBox("Ed_Slot3", col3_3, y + 2, smallW, ctlH, g_newsSlot3, !g_enSlot3);
CreateBtn("Btn_NewsTz", colBtn, y + 2, btnW, ctlH, (g_newsTz == TZ_LOCAL_PC) ? "GIỜ MÁY (VN)" : "GIỜ SÀN MT5", C_BTN_MODE, clrWhite);

r = 4; y = yContent + r * rowH + 4;
CreateTxt("T3_L5", baseX + 14, y + rowH / 2, "Hạ nhiệt (giờ) | Lãi phục hồi (%) | PIN:", clrAqua, true);
CreateEditBox("Ed_Cooldown", col3_1, y + 2, smallW, ctlH, DoubleToString(g_cooldownHours, 1), g_riskBreached);
CreateEditBox("Ed_RecTarg", col3_2, y + 2, smallW, ctlH, DoubleToString(g_recoveryTargetPct, 1));
CreateEditBox("Ed_PinCode", col3_3, y + 2, smallW, ctlH, g_enteredPinStr);
CreateBtn("Btn_PinUnlock", colBtn, y + 2, btnW, ctlH, "MỞ KHÓA PIN", C_BTN_LOCK, clrWhite);
}

int yFoot = baseY + rowH * 10 + 22;
int qW = (panelW - 24) / 4;
CreateBtn("Btn_SyncSlTp", baseX + 6, yFoot, qW, ctlH + 4, "ĐỒNG BỘ SL/TP", C_BTN_BUY, clrWhite);
CreateBtn("Btn_NowBE", baseX + 10 + qW, yFoot, qW, ctlH + 4, "DỜI SL VỀ BE", C_BTN_ACT, clrWhite);
CreateBtn("Btn_Close50", baseX + 14 + qW * 2, yFoot, qW, ctlH + 4, "ĐÓNG 50%% LOT", C_BTN_ACT, clrWhite);
CreateBtn("Btn_CloseAll", baseX + 18 + qW * 3, yFoot, qW, ctlH + 4, "ĐÓNG TẤT CẢ", C_BTN_SELL, clrWhite);
}

void UpdateHudAndTabValues(double dayPct, double weekPct, double monthPct,
int openCount, double totalOpenVol, double vwapEntry,
double repSL, double repTP, bool basketIsLong, long anchorId, datetime earliestOpenTime,
double currentR, double netFloatingPnl)
{
if(g_isMinimized)
return;

double slDist, slPts, recLot, dispVol, dispRiskCash, dispRiskPct, dispRewardCash, partLot, remLot;
bool riskKnown = true;
CalculateSizingAndActiveRules(openCount, totalOpenVol, vwapEntry, repSL, repTP, basketIsLong, anchorId, earliestOpenTime,
slDist, slPts, recLot, dispVol, dispRiskCash, dispRiskPct, riskKnown, dispRewardCash, partLot, remLot);

bool algoOn = (TerminalInfoInteger(TERMINAL_TRADE_ALLOWED) && MQLInfoInteger(MQL_TRADE_ALLOWED));
string tfName = GetTfShortName(g_resolvedAtrTf);

string stTxt = algoOn ? (openCount > 0 ? StringFormat("QUẢN LÝ %d LỆNH (TF:%s | %s)", openCount, tfName, (g_mixedPositionFallback ? "TÁCH RIÊNG 2 CHIỀU" : (g_multiMode == MULTI_BASKET_VWAP ? "VWAP" : "RIÊNG")))
: StringFormat("CHỜ LỆNH TAY (ATR TF: %s)", tfName))
: "CHƯA BẬT ALGO TRADING!";
color stClr = algoOn ? ((g_inRecoveryMode && g_enHalfRiskRec) ? clrOrange : (openCount > 0 ? clrLime : clrAqua)) : clrYellow;

if(g_riskBreached || g_manualForceLock)
{
stTxt = g_manualForceLock ? "ĐÃ KHÓA THỦ CÔNG" : g_breachReason;
stClr = clrRed;
}
else if(g_enNewsFilter && g_newsLockedState)
{
stTxt = "TẠM KHÓA (ĐANG TRONG GIỜ TIN)";
stClr = clrOrangeRed;
}
else if(g_enRiskGuard && !g_riskDataAvailable)
{
stTxt = "TẠM DỪNG GỢI Ý LOT (LỊCH SỬ RISK CHƯA TẢI)";
stClr = clrOrangeRed;
}

string hud1 = StringFormat("%s | N:%.1f%% T:%.1f%% Th:%.1f%%", stTxt, dayPct, weekPct, monthPct);
ObjectSetString(0, PREFIX + "Hud_Line1", OBJPROP_TEXT, hud1);
ObjectSetInteger(0, PREFIX + "Hud_Line1", OBJPROP_COLOR, stClr);

if(ObjectFind(0, PREFIX + "Btn_AtrTf") >= 0)
ObjectSetString(0, PREFIX + "Btn_AtrTf", OBJPROP_TEXT, GetAtrTfBtnLabel());

if(ObjectFind(0, PREFIX + "Btn_SyncSlTp") >= 0)
ObjectSetString(0, PREFIX + "Btn_SyncSlTp", OBJPROP_TEXT, (openCount > 0) ? "ĐỒNG BỘ SL/TP" : "TẠO LẠI SETUP");

double activeRisk = GetActiveRiskPercent();
string hud2L = "", hud2R = "";
if(openCount > 0)
{
if(g_mixedPositionFallback)
{
hud2L = StringFormat("HAI CHIỀU: hướng chính %.2f lot (SL %.0f điểm)", dispVol, slPts);
hud2R = StringFormat("Risk hướng chính: %.2f%% | TP1:%.2f / Còn:%.2f", dispRiskPct, partLot, remLot);
}
else
{
hud2L = riskKnown
? StringFormat("Khớp:%.2fL (Gợi ý:%.2f) | SL:%.0fđ | Risk:-$%.1f", dispVol, recLot, slPts, dispRiskCash)
: StringFormat("Khớp:%.2fL (Gợi ý:%.2f) | SL:%.0fđ | Risk:? ", dispVol, recLot, slPts);
hud2R = riskKnown
? StringFormat("Risk thực:%.2f%% (Thêm:%.2fL) | TP1:%.2f/Còn:%.2f", dispRiskPct, g_nextAddOnSuggestedLot, partLot, remLot)
: "Kiểm tra SL / dữ liệu broker; không giả định Risk = 0";
}
}
else
{
if(g_enteredManualLot > 0.0)
{
hud2L = riskKnown
? StringFormat("Gợi ý:%.2fL | Nhập:%.2fL (SL:%.0fđ) | -$%.1f", recLot, dispVol, slPts, dispRiskCash)
: "GỢI Ý: 0 lot | Risk danh mục / SL chưa xác định";
}
else
{
hud2L = riskKnown
? StringFormat("GỢI Ý: %.2f Lot (SL: %.0f điểm) | -$%.1f", recLot, slPts, dispRiskCash)
: "GỢI Ý: 0 lot | Risk danh mục / SL chưa xác định";
}
hud2R = riskKnown
? (InpSplitSetupRiskAcrossOrders
   ? StringFormat("Tổng %.2f%% [L1:%.2f | L2:%.2f | L3:%.2f]", activeRisk, g_leg1SuggestedLot, g_leg2SuggestedLot, g_leg3SuggestedLot)
   : StringFormat("Risk mục tiêu: %.2f%% | TP1:%.2f / Còn:%.2f", activeRisk, partLot, remLot))
: "Không thể bảo đảm mức Risk mục tiêu";
}
ObjectSetString(0, PREFIX + "Hud_Line2L", OBJPROP_TEXT, hud2L);
ObjectSetInteger(0, PREFIX + "Hud_Line2L", OBJPROP_COLOR, (openCount > 0) ? clrLime : clrYellow);
ObjectSetString(0, PREFIX + "Hud_Line2R", OBJPROP_TEXT, hud2R);
ObjectSetInteger(0, PREFIX + "Hud_Line2R", OBJPROP_COLOR, clrAqua);

string hud3L = "", hud3R = "";
color hud3Clr = clrGold;

if(openCount > 0)
{
hud3L = StringFormat("Khớp:%s (KH:%s) | %+.2fR ($%.1f)",
DoubleToString(g_actualFillEntryPrice, _Digits), DoubleToString(g_plannedEntryPrice, _Digits), currentR, netFloatingPnl);
if(g_trailStyle == TRAIL_STYLE_MANUAL_SL)
hud3R = "[SL TAY 100% - THỦ CÔNG]";
else if(g_trailStyle == TRAIL_STYLE_BE_FLOAT || !g_enTrail)
hud3R = g_enPartial && partLot > 0.0
? StringFormat("[CHỜ +%.1fR CẮT %.0f%% & DỜI BE (TP1 ẢO)]", g_partialRR, g_partialPct)
: "[THỦ CÔNG (CHỜ DỜI BE)]";
else if(g_isTrailingArmedNow)
hud3R = StringFormat("[ĐÃ CẮT %.0f%% & TRAIL: %d T1 | %d T2]", g_partialPct, g_tier1SavedCount, g_tier2HalfCutCount);
else if(g_enPartial && partLot <= 0.0)
hud3R = StringFormat("[LOT TỐI THIỂU: Chờ +%.1fR Trail 100%% (Ko chia %.0f%%)]", g_trailStartRR, g_partialPct);
else if(g_enPartial && g_hardTpSuppressedForPartial)
hud3R = StringFormat("[TP1 ẢO (GỠ HARD TP) | +%.1fR cắt %.0f%% & Trail]", g_partialRR, g_partialPct);
else if(g_enPartial)
hud3R = StringFormat("[GIỮ SL | Chờ +%.1fR cắt %.0f%% & Trail]", g_partialRR, g_partialPct);
else
hud3R = StringFormat("[GIỮ SL | Chờ +%.1fR bật ATR Trail]", g_trailStartRR);

hud3Clr = (g_enTrail && g_isTrailingArmedNow) ? clrLime : clrGold;
}
else
{
hud3L = StringFormat("Entry KH(%s): %s | ATR: %s",
tfName, DoubleToString(g_plannedEntryPrice, _Digits), DoubleToString(g_pineTrailingStop, _Digits));
hud3R = g_newsStatusText;
hud3Clr = g_newsLockedState ? clrRed : clrAqua;
}

ObjectSetString(0, PREFIX + "Hud_Line3L", OBJPROP_TEXT, hud3L);
ObjectSetInteger(0, PREFIX + "Hud_Line3L", OBJPROP_COLOR, hud3Clr);
ObjectSetString(0, PREFIX + "Hud_Line3R", OBJPROP_TEXT, hud3R);
ObjectSetInteger(0, PREFIX + "Hud_Line3R", OBJPROP_COLOR, hud3Clr);

ChartRedraw(0);
}

void OnChartEvent(const int id,
const long &lparam,
const double &dparam,
const string &sparam)
{
if(id == CHARTEVENT_MOUSE_MOVE)
{
int mouseX = (int)lparam;
int mouseY = (int)dparam;
uint mouseFlag = (uint)StringToInteger(sparam);
bool leftDown = ((mouseFlag & 1) == 1);

if(leftDown && !g_prevMouseLeftDown)
{
int dragZoneRight = g_panelX + g_panelW - 105;
if(mouseX >= g_panelX && mouseX <= dragZoneRight &&
mouseY >= g_panelY && mouseY <= g_panelY + g_headerH)
{
g_isDraggingPanel = true;
g_dragOffsetX = mouseX - g_panelX;
g_dragOffsetY = mouseY - g_panelY;
ChartSetInteger(0, CHART_MOUSE_SCROLL, false);
RebuildCleanPanel(false);
ChartRedraw(0);
}
}
else if(leftDown && g_isDraggingPanel)
{
int newX = mouseX - g_dragOffsetX;
int newY = mouseY - g_dragOffsetY;
if(MathAbs(newX - g_panelX) >= 2 || MathAbs(newY - g_panelY) >= 2)
{
g_panelX = newX;
g_panelY = newY;
ClampPanelCoordinates();
RebuildCleanPanel(false);
ChartRedraw(0);
}
}
else if(!leftDown && g_isDraggingPanel)
{
g_isDraggingPanel = false;
ChartSetInteger(0, CHART_MOUSE_SCROLL, true);
RebuildCleanPanel(false);
ChartRedraw(0);
}

g_prevMouseLeftDown = leftDown;
return;
}

if(g_accountSwitchHold)
{
if(id == CHARTEVENT_OBJECT_CLICK)
{
ObjectSetInteger(0, sparam, OBJPROP_STATE, false);
if(sparam == PREFIX + "Btn_ForceLock")
{
long activeLogin = AccountInfoInteger(ACCOUNT_LOGIN);
int activeServerHash = GetCurrentServerHash();
if(activeLogin != g_initAccountLogin || activeServerHash != g_initServerHash)
{
Alert("Tài khoản/server vừa thay đổi thêm lần nữa. EA tiếp tục tạm dừng; hãy chờ khởi tạo lại.");
}
else if(!g_accountHoldRiskDataReady || !g_riskDataAvailable)
{
Alert("Lịch sử Risk Guard chưa tải xong. EA vẫn tạm dừng; hãy chờ MT5 đồng bộ rồi xác nhận lại.");
}
else
{
g_accountSwitchHold = false;
RebuildCleanPanel(true);
ProcessCoreLogic();
}
}
else
Alert("EA đang tạm dừng để xác nhận tài khoản/lệnh hiện tại. Hãy kiểm tra vị thế rồi bấm XÁC NHẬN TK để tiếp tục.");
}
return;
}

if(id == CHARTEVENT_CHART_CHANGE)
{
ClampPanelCoordinates();
RebuildCleanPanel(false);
ProcessCoreLogic();
return;
}

if(id == CHARTEVENT_OBJECT_DRAG)
{
if(sparam == DRAG_PREFIX + "ENTRY")
{
g_slMode = SL_MODE_DRAG;
g_pinSizerEntry = true;
g_sizerEntryPrice = ObjectGetDouble(0, sparam, OBJPROP_PRICE, 0);
RebuildCleanPanel(false);
ProcessCoreLogic();
}
else if(sparam == DRAG_PREFIX + "SL")
{
g_slMode = SL_MODE_DRAG;
g_pinSizerEntry = true;
g_sizerSlPrice = ObjectGetDouble(0, sparam, OBJPROP_PRICE, 0);
g_manualSlPts = (int)MathRound(MathAbs(g_sizerEntryPrice - g_sizerSlPrice) / _Point);
if(ObjectFind(0, PREFIX + "Ed_ManSlPts") >= 0)
ObjectSetString(0, PREFIX + "Ed_ManSlPts", OBJPROP_TEXT, IntegerToString(g_manualSlPts));
RebuildCleanPanel(false);
ProcessCoreLogic();
}
else if(sparam == DRAG_PREFIX + "TP")
{
g_slMode = SL_MODE_DRAG;
g_pinSizerEntry = true;
g_sizerTpPrice = ObjectGetDouble(0, sparam, OBJPROP_PRICE, 0);
double slDist = MathAbs(g_sizerEntryPrice - g_sizerSlPrice);
if(slDist > 0.0)
g_targetRR = MathAbs(g_sizerTpPrice - g_sizerEntryPrice) / slDist;
if(ObjectFind(0, PREFIX + "Ed_RR") >= 0)
ObjectSetString(0, PREFIX + "Ed_RR", OBJPROP_TEXT, DoubleToString(g_targetRR, 2));
RebuildCleanPanel(false);
ProcessCoreLogic();
}
return;
}

if(id == CHARTEVENT_OBJECT_ENDEDIT)
{
string rawText = ObjectGetString(0, sparam, OBJPROP_TEXT);
if(sparam == PREFIX + "Ed_PinCode")
{
g_enteredPinStr = rawText;
RebuildCleanPanel(false);
return;
}

string valStr = rawText;
StringReplace(valStr, ",", ".");
double valDbl = StringToDouble(valStr);
int valInt = (int)StringToInteger(valStr);

if(sparam == PREFIX + "Ed_RiskPct" && valDbl > 0.0) g_riskPct = valDbl;
if(sparam == PREFIX + "Ed_RR" && valDbl > 0.0) g_targetRR = valDbl;
if(sparam == PREFIX + "Ed_ManSlPts" && valInt >= 1) { g_manualSlPts = valInt; g_slMode = SL_MODE_POINTS; }
if(sparam == PREFIX + "Ed_BufPts" && valInt >= 0) g_bufferPts = valInt;
if(sparam == PREFIX + "Ed_CommLot" && valDbl >= 0.0) g_commPerLot = valDbl;

if(sparam == PREFIX + "Ed_AtrPer" && valInt >= 1) g_atrLength = valInt;
if(sparam == PREFIX + "Ed_FirstMul" && valDbl > 0.0) g_customValueForFirstDay = valDbl;
if(sparam == PREFIX + "Ed_AtrMul" && valDbl > 0.0) g_atrMultiplier = valDbl;
if(sparam == PREFIX + "Ed_TrailRR" && valDbl >= 0.0) g_trailStartRR = valDbl;
if(sparam == PREFIX + "Ed_TierPct1R" && valDbl >= 5.0 && valDbl <= 90.0) g_tierPctOf1R = valDbl;
if(sparam == PREFIX + "Ed_PartRR" && valDbl > 0.0) g_partialRR = valDbl;
if(sparam == PREFIX + "Ed_PartPct" && valDbl > 0.0 && valDbl < 100.0) g_partialPct = valDbl;
if(sparam == PREFIX + "Ed_BePts" && valInt >= 0) g_bePoints = valInt;

if(!g_riskBreached)
{
if(sparam == PREFIX + "Ed_MaxDay" && valDbl > 0.0) g_maxDailyLossPct = valDbl;
if(sparam == PREFIX + "Ed_MaxWeek" && valDbl > 0.0) g_maxWeeklyLossPct = valDbl;
if(sparam == PREFIX + "Ed_MaxMonth" && valDbl > 0.0) g_maxMonthlyLossPct = valDbl;
if(sparam == PREFIX + "Ed_Cooldown" && valDbl >= 0.0) g_cooldownHours = valDbl;
}
else if(sparam == PREFIX + "Ed_MaxDay" || sparam == PREFIX + "Ed_MaxWeek" || sparam == PREFIX + "Ed_MaxMonth" || sparam == PREFIX + "Ed_Cooldown")
{
Alert("ĐANG KHÓA KỶ LUẬT! Không thể tự ý nới rộng hạn mức lỗ hoặc giảm giờ hạ nhiệt.");
}

if(sparam == PREFIX + "Ed_CustomEq" && valDbl > 0.0)
{
g_customEquity = valDbl;
g_useLiveEquity = false;
}
if(sparam == PREFIX + "Ed_MinBef" && valInt >= 0) g_minBeforeNews = valInt;
if(sparam == PREFIX + "Ed_MinAft" && valInt >= 0) g_minAfterNews = valInt;
if(sparam == PREFIX + "Ed_Slot1") g_newsSlot1 = rawText;
if(sparam == PREFIX + "Ed_Slot2") g_newsSlot2 = rawText;
if(sparam == PREFIX + "Ed_Slot3") g_newsSlot3 = rawText;

if(sparam == PREFIX + "Ed_Yr" || sparam == PREFIX + "Ed_Mo" || sparam == PREFIX + "Ed_Dy")
{
if(valInt <= 0)
{
g_autoSyncDate = true;
SyncAnchorDateFields(g_resolvedAtrTf, 0);
}
else
{
g_autoSyncDate = false;
if(sparam == PREFIX + "Ed_Yr" && valInt >= 1900 && valInt <= 2100) g_entryDateYear = valInt;
if(sparam == PREFIX + "Ed_Mo" && valInt >= 1 && valInt <= 12) g_entryDateMonth = valInt;
if(sparam == PREFIX + "Ed_Dy" && valInt >= 1 && valInt <= 31) g_entryDateDay = valInt;
}
}

if(sparam == PREFIX + "Ed_RecTarg" && valDbl > 0.0) g_recoveryTargetPct = valDbl;

if(sparam == PREFIX + "Ed_RR" || sparam == PREFIX + "Ed_ManSlPts" ||
   sparam == PREFIX + "Ed_AtrPer" || sparam == PREFIX + "Ed_FirstMul" || sparam == PREFIX + "Ed_AtrMul" ||
   sparam == PREFIX + "Ed_Yr" || sparam == PREFIX + "Ed_Mo" || sparam == PREFIX + "Ed_Dy")
{
if(CountPositionsInScope(false) == 0)
ResetStandbySetupLock(g_resolvedAtrTf);
}

RebuildCleanPanel(false);
ProcessCoreLogic();
return;
}

if(id == CHARTEVENT_OBJECT_CLICK)
{
ObjectSetInteger(0, sparam, OBJPROP_STATE, false);

if(sparam == PREFIX + "Tab_Pos")
{ g_activeTab = TAB_POSITION; RebuildCleanPanel(true); ProcessCoreLogic(); return; }
if(sparam == PREFIX + "Tab_Trail")
{ g_activeTab = TAB_TRAILING; RebuildCleanPanel(true); ProcessCoreLogic(); return; }
if(sparam == PREFIX + "Tab_Risk")
{ g_activeTab = TAB_RISKNEWS; RebuildCleanPanel(true); ProcessCoreLogic(); return; }

if(sparam == PREFIX + "Btn_Min")
{
g_isMinimized = !g_isMinimized;
RebuildCleanPanel(true);
ProcessCoreLogic();
return;
}
else if(sparam == PREFIX + "Btn_Area")
{
long chartW = ChartGetInteger(0, CHART_WIDTH_IN_PIXELS);
long chartH = ChartGetInteger(0, CHART_HEIGHT_IN_PIXELS);
g_cornerPresetIdx = (g_cornerPresetIdx + 1) % 4;
if(g_cornerPresetIdx == 0) { g_panelX = 14; g_panelY = 82; }
else if(g_cornerPresetIdx == 1) { g_panelX = (int)chartW - g_panelW - 14; g_panelY = 18; }
else if(g_cornerPresetIdx == 2) { g_panelX = (int)chartW - g_panelW - 14; g_panelY = (int)chartH - g_panelH - 15; }
else { g_panelX = 14; g_panelY = (int)chartH - g_panelH - 15; }
ClampPanelCoordinates();
RebuildCleanPanel(false);
ProcessCoreLogic();
return;
}
else if(sparam == PREFIX + "Btn_ForceLock")
{
g_manualForceLock = !g_manualForceLock;
if(g_manualForceLock)
CloseAllTradesAndOrders("Người dùng bấm nút Khóa ngay");
}
else if(sparam == PREFIX + "Btn_RiskGuard")
{
if(g_riskBreached)
Alert("ĐANG KHÓA KỶ LUẬT! Không thể tắt Bảo vệ khi đang vi phạm.");
else
g_enRiskGuard = !g_enRiskGuard;
}
else if(sparam == PREFIX + "Btn_PinUnlock")
{
TryEmergencyPinUnlock();
return;
}
else if(sparam == PREFIX + "Btn_SlMode")
{
if(g_slMode == SL_MODE_ATR_FIRST) g_slMode = SL_MODE_ATR_LINE;
else if(g_slMode == SL_MODE_ATR_LINE) g_slMode = SL_MODE_POINTS;
else if(g_slMode == SL_MODE_POINTS) g_slMode = SL_MODE_DRAG;
else g_slMode = SL_MODE_ATR_FIRST;
ResetStandbySetupLock(_Period);
}
else if(sparam == PREFIX + "Btn_AtrTf")
{
if(g_atrTfMode == ATR_TF_AUTO_ENTRY) g_atrTfMode = ATR_TF_FIXED_H1;
else if(g_atrTfMode == ATR_TF_FIXED_H1) g_atrTfMode = ATR_TF_FIXED_M15;
else if(g_atrTfMode == ATR_TF_FIXED_M15) g_atrTfMode = ATR_TF_FIXED_M5;
else if(g_atrTfMode == ATR_TF_FIXED_M5) g_atrTfMode = ATR_TF_FIXED_H4;
else if(g_atrTfMode == ATR_TF_FIXED_H4) g_atrTfMode = ATR_TF_FIXED_D1;
else if(g_atrTfMode == ATR_TF_FIXED_D1) g_atrTfMode = ATR_TF_CHART_CUR;
else g_atrTfMode = ATR_TF_AUTO_ENTRY;

g_autoSyncDate = true;
ResetStandbySetupLock(_Period);
}
else if(sparam == PREFIX + "Btn_Journal")
{
g_showJournal = !g_showJournal;
}
else if(sparam == PREFIX + "Btn_VolRule")
{
g_volRule = (g_volRule == RULE_KEEP_DIST_CALC_CASH) ? RULE_SCALE_DIST_BY_VOL : RULE_KEEP_DIST_CALC_CASH;
}
else if(sparam == PREFIX + "Btn_MultiMode")
{
g_multiMode = (g_multiMode == MULTI_BASKET_VWAP) ? MULTI_INDIVIDUAL : MULTI_BASKET_VWAP;
}
else if(sparam == PREFIX + "Btn_SweepMode")
{
if(g_sweepMode == SWEEP_3LAYER_20PCT_1R) g_sweepMode = SWEEP_WAIT_CANDLE_CLOSE;
else if(g_sweepMode == SWEEP_WAIT_CANDLE_CLOSE) g_sweepMode = SWEEP_HARD_SL_ON_LINE;
else g_sweepMode = SWEEP_3LAYER_20PCT_1R;
}
else if(sparam == PREFIX + "Btn_AtrSrc")
{
g_atrSource = (g_atrSource == ATR_SRC_CLOSE_SWING) ? ATR_SRC_HIGH_LOW : ATR_SRC_CLOSE_SWING;
}
else if(sparam == PREFIX + "Btn_Trail")
{
if(g_trailStyle == TRAIL_STYLE_AUTO_ATR) g_trailStyle = TRAIL_STYLE_BE_FLOAT;
else if(g_trailStyle == TRAIL_STYLE_BE_FLOAT) g_trailStyle = TRAIL_STYLE_MANUAL_SL;
else g_trailStyle = TRAIL_STYLE_AUTO_ATR;
ApplyTrailStyleFlags();
}
else if(sparam == PREFIX + "Btn_AutoSlTp") g_autoSlTp = !g_autoSlTp;
else if(sparam == PREFIX + "Btn_ShowSizer") g_showSizer = !g_showSizer;
else if(sparam == PREFIX + "Btn_ShowPlot") g_showAtrPlot = !g_showAtrPlot;
else if(sparam == PREFIX + "Btn_Be")
{
// Cycle between partial TP with original SL, partial TP with BE, and both disabled.
if(g_enPartial && !g_enBe)
{ g_enPartial = true; g_enBe = true; }
else if(g_enPartial && g_enBe)
{ g_enPartial = false; g_enBe = false; }
else
{ g_enPartial = true; g_enBe = false; }
}

else if(sparam == PREFIX + "Btn_GetRealEq")
{
double realEq = AccountInfoDouble(ACCOUNT_EQUITY);
if(realEq > 0.0)
{
g_customEquity = NormalizeDouble(realEq, 0);
g_useLiveEquity = true;
if(ObjectFind(0, PREFIX + "Ed_CustomEq") >= 0)
ObjectSetString(0, PREFIX + "Ed_CustomEq", OBJPROP_TEXT, DoubleToString(g_customEquity, 0));
}
}
else if(sparam == PREFIX + "Btn_News") g_enNewsFilter = !g_enNewsFilter;
else if(sparam == PREFIX + "Btn_EnSlot1") g_enSlot1 = !g_enSlot1;
else if(sparam == PREFIX + "Btn_EnSlot2") g_enSlot2 = !g_enSlot2;
else if(sparam == PREFIX + "Btn_EnSlot3") g_enSlot3 = !g_enSlot3;
else if(sparam == PREFIX + "Btn_NewsTz") g_newsTz = (g_newsTz == TZ_LOCAL_PC) ? TZ_MT5_SERVER : TZ_LOCAL_PC;
else if(sparam == PREFIX + "Btn_SyncSlTp")
{
int symPosCount = CountPositionsInScope(false);
if(symPosCount == 0)
{
// 6. Lúc chờ lệnh: bấm nút "TẠO LẠI SETUP" để cập nhật gợi ý Entry/SL/TP và khóa khung mới theo biểu đồ hiện tại
g_pinSizerEntry = false;
ResetStandbySetupLock(_Period);
ProcessCoreLogic();
Alert(StringFormat("EA PRO [%s]: Đã tạo lại Setup & khóa cố định theo khung %s (Entry KH: %s | SL: %s | TP: %s).",
_Symbol, GetTfShortName(g_resolvedAtrTf),
DoubleToString(g_sizerEntryPrice, _Digits),
DoubleToString(g_sizerSlPrice, _Digits),
DoubleToString(g_sizerTpPrice, _Digits)));
}
else
{
for(int i = PositionsTotal() - 1; i >= 0; i--)
{
ulong t = PositionGetTicket(i);
if(t > 0 && PositionGetString(POSITION_SYMBOL) == _Symbol)
{
long posId = PositionGetInteger(POSITION_IDENTIFIER);
double curVol = PositionGetDouble(POSITION_VOLUME);
double actualE = PositionGetDouble(POSITION_PRICE_OPEN);
bool isBuy = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY);
bool partDone = GlobalVariableCheck(AccountScopedGV("EAP82_PART_" + IntegerToString(posId)));
bool suppressHardTp = ShouldSuppressBrokerHardTpForPartial(curVol, partDone, actualE, g_sizerSlPrice, g_sizerTpPrice, isBuy);
double syncTP = suppressHardTp ? 0.0 : NormalizeDouble(g_sizerTpPrice, _Digits);
ModifyPositionWithConfirmation(t, NormalizeDouble(g_sizerSlPrice, _Digits), syncTP);
}
}
}
}
else if(sparam == PREFIX + "Btn_NowBE")
{
double buyPV = 0.0, buyVol = 0.0, sellPV = 0.0, sellVol = 0.0;
for(int k = PositionsTotal() - 1; k >= 0; k--)
{
ulong tk = PositionGetTicket(k);
if(tk == 0 || PositionGetString(POSITION_SYMBOL) != _Symbol)
continue;
double vol = PositionGetDouble(POSITION_VOLUME);
double price = PositionGetDouble(POSITION_PRICE_OPEN);
if(PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY)
{ buyVol += vol; buyPV += price * vol; }
else
{ sellVol += vol; sellPV += price * vol; }
}

for(int i = PositionsTotal() - 1; i >= 0; i--)
{
ulong t = PositionGetTicket(i);
if(t == 0 || PositionGetString(POSITION_SYMBOL) != _Symbol)
continue;
bool isBuy = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY);
double sideVol = isBuy ? buyVol : sellVol;
double sidePV = isBuy ? buyPV : sellPV;
double sideVwap = (sideVol > 0.0) ? (sidePV / sideVol) : 0.0;
double baseE = (g_multiMode == MULTI_BASKET_VWAP && !g_mixedPositionFallback && sideVwap > 0.0) ? sideVwap : PositionGetDouble(POSITION_PRICE_OPEN);
double tp = PositionGetDouble(POSITION_TP);
double beSL = isBuy ? NormalizeDouble(baseE + g_bePoints * _Point, _Digits) : NormalizeDouble(baseE - g_bePoints * _Point, _Digits);
ModifyPositionWithConfirmation(t, beSL, tp);
}
}
else if(sparam == PREFIX + "Btn_Close50")
{
for(int i = PositionsTotal() - 1; i >= 0; i--)
{
ulong t = PositionGetTicket(i);
if(t > 0 && PositionGetString(POSITION_SYMBOL) == _Symbol)
{
double vol = PositionGetDouble(POSITION_VOLUME);
double half = FloorLotStep(vol * 0.5);
if(half >= SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN))
ClosePositionPartiallyByTicket(t, half);
}
}
}
else if(sparam == PREFIX + "Btn_CloseAll")
{
CloseAllTradesAndOrders("Người dùng bấm nút ĐÓNG TẤT CẢ");
}

RebuildCleanPanel(false);
ProcessCoreLogic();
}
}

void OnTick() { ProcessCoreLogic(); }
void OnTimer() { ProcessCoreLogic(); }
//+------------------------------------------------------------------+



